# config/urls.py
"""根路由配置"""

from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.views.generic import RedirectView


urlpatterns = [
    path('admin/', RedirectView.as_view(url='/admin-panel/', permanent=False)),

    path('admin-panel/', include('admin_panel.urls')),

    path('admin-api/tag/',        include('modules.tag.urls')),
    path('admin-api/template/',   include('modules.template.urls')),
    path('admin-api/config/',     include('modules.config.urls')),
    path('admin-api/permission/', include('modules.permission.urls')),
    path('admin-api/plugin/',     include('modules.plugin.urls')),
    path('admin-api/log/',        include('modules.log.urls')),

    path('', include('frontend.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
