# config/__init__.py
"""
数据库驱动初始化 + Celery 自动加载
"""
import pymysql
pymysql.install_as_MySQLdb()

# Celery app 自动加载
from .celery import app as celery_app
__all__ = ('celery_app',)
