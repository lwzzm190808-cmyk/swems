# config/celery.py
"""
Celery 异步任务配置

通知服务的邮件/短信分发通过 Celery 异步执行，
避免阻塞主请求线程。
"""

import os
from celery import Celery

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')

app = Celery('edu_platform')
app.config_from_object('django.conf:settings', namespace='CELERY')
app.autodiscover_tasks()


@app.task(bind=True, ignore_result=True)
def debug_task(self):
    print(f'Request: {self.request!r}')
