# shared/cache/__init__.py
# 保持空文件
# 使用时：from shared.cache.service import CacheService
