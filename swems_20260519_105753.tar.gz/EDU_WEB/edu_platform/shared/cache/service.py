# shared/cache/service.py
"""
缓存服务

封装 Django 缓存框架，提供领域特定的缓存方法。
所有缓存操作统一经过此服务，便于：
- 统一管理 key 前缀和 TTL
- 集中控制缓存策略
- 后续切换缓存后端无需改动调用方
"""

import json
import logging
from typing import Any, Optional

from django.core.cache import cache

logger = logging.getLogger(__name__)


class CacheService:
    """
    缓存服务

    Key 命名规范：{prefix}:{namespace}:{key}
    """

    # 默认 TTL（秒）
    DEFAULT_TIMEOUT = 300           # 5 分钟
    LABEL_TIMEOUT = 300             # 标签缓存 5 分钟
    TEMPLATE_TIMEOUT = 600          # 模板缓存 10 分钟
    CONFIG_TIMEOUT = 60             # 配置缓存 1 分钟（配置变更需快速生效）
    PERMISSION_TIMEOUT = 300        # 权限缓存 5 分钟

    # Key 前缀
    PREFIX = 'edu'

    @classmethod
    def _build_key(cls, namespace: str, key: str) -> str:
        """构建标准化缓存 key"""
        return f'{cls.PREFIX}:{namespace}:{key}'

    # ----------------------------------------------------------------
    # 基础操作
    # ----------------------------------------------------------------
    @classmethod
    def get(cls, key: str, namespace: str = 'default', default: Any = None) -> Any:
        """
        获取缓存

        Args:
            key: 缓存键
            namespace: 命名空间
            default: 缺省值

        Returns:
            缓存值，不存在返回 default
        """
        full_key = cls._build_key(namespace, key)
        value = cache.get(full_key)
        if value is None:
            return default
        return value

    @classmethod
    def set(cls, key: str, value: Any, timeout: int = None,
            namespace: str = 'default') -> None:
        """
        设置缓存

        Args:
            key: 缓存键
            value: 缓存值
            timeout: TTL（秒），None 使用默认值
            namespace: 命名空间
        """
        if timeout is None:
            timeout = cls.DEFAULT_TIMEOUT
        full_key = cls._build_key(namespace, key)
        cache.set(full_key, value, timeout)

    @classmethod
    def delete(cls, key: str, namespace: str = 'default') -> None:
        """删除指定缓存"""
        full_key = cls._build_key(namespace, key)
        cache.delete(full_key)

    @classmethod
    def clear_namespace(cls, namespace: str) -> None:
        """
        清空指定命名空间的所有缓存

        注意：依赖底层缓存后端支持。Redis 后端通过 scan 批量删除。
        """
        full_prefix = f'{cls.PREFIX}:{namespace}:'
        try:
            # Django Redis 后端支持 delete_pattern
            cache.delete_pattern(f'{full_prefix}*')
            logger.info(f'已清空命名空间缓存: {namespace}')
        except AttributeError:
            # 后端不支持 pattern delete，降级为 clear all
            logger.warning(f'缓存后端不支持 pattern delete，跳过清空: {namespace}')

    # ----------------------------------------------------------------
    # 便捷方法：带默认 TTL 的领域缓存
    # ----------------------------------------------------------------
    @classmethod
    def get_label(cls, tag_code: str) -> Any:
        """获取标签数据缓存"""
        return cls.get(tag_code, namespace='label')

    @classmethod
    def set_label(cls, tag_code: str, value: Any) -> None:
        """设置标签数据缓存"""
        cls.set(tag_code, value, timeout=cls.LABEL_TIMEOUT, namespace='label')

    @classmethod
    def clear_labels(cls) -> None:
        """清空所有标签缓存（标签变更时调用）"""
        cls.clear_namespace('label')

    @classmethod
    def get_config(cls, group: str, key: str) -> Any:
        """获取配置缓存"""
        return cls.get(f'{group}:{key}', namespace='config')

    @classmethod
    def set_config(cls, group: str, key: str, value: Any) -> None:
        """设置配置缓存"""
        cls.set(f'{group}:{key}', value, timeout=cls.CONFIG_TIMEOUT, namespace='config')

    @classmethod
    def clear_config(cls, group: str = None) -> None:
        """清空配置缓存"""
        if group:
            # 只清空指定分组
            cls.clear_namespace(f'config:{group}')
        else:
            cls.clear_namespace('config')

    @classmethod
    def get_permission(cls, username: str) -> Any:
        """获取权限缓存"""
        return cls.get(username, namespace='permission')

    @classmethod
    def set_permission(cls, username: str, value: Any) -> None:
        """设置权限缓存"""
        cls.set(username, value, timeout=cls.PERMISSION_TIMEOUT, namespace='permission')

    @classmethod
    def clear_permission(cls, username: str = None) -> None:
        """清空权限缓存"""
        if username:
            cls.delete(username, namespace='permission')
        else:
            cls.clear_namespace('permission')

    @classmethod
    def get_template(cls, file_path: str) -> Any:
        """获取模板内容缓存"""
        return cls.get(file_path, namespace='template')

    @classmethod
    def set_template(cls, file_path: str, value: Any) -> None:
        """设置模板内容缓存"""
        cls.set(file_path, value, timeout=cls.TEMPLATE_TIMEOUT, namespace='template')

    @classmethod
    def clear_templates(cls) -> None:
        """清空所有模板缓存"""
        cls.clear_namespace('template')
