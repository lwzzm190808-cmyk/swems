# shared/notification/service.py
"""
通知服务

独立的公共服务，任何模块均可调用。
使用示例：

    from shared.notification.service import NotificationService

    # 单条通知
    NotificationService.send(
        recipient=user,
        title="课程审核通过",
        content="您提交的课程《Python入门》已通过审核",
        source_module="course",
    )

    # 批量通知
    NotificationService.send_bulk(
        recipients=[user1, user2],
        title="系统维护通知",
        content="系统将于今晚 22:00 进行维护",
        source_module="system",
    )

    # 向权限组全体成员发通知
    NotificationService.send_to_group(
        group_name="课程管理员",
        title="待审核课程",
        content="有 3 门新课程待审核",
        source_module="course",
    )
"""

import logging
from typing import List, Optional

from core.models import User, Notification

logger = logging.getLogger(__name__)


class NotificationService:
    """通知服务 — 站内信 + 异步外部渠道分发"""

    # ----------------------------------------------------------------
    # 发送
    # ----------------------------------------------------------------
    @classmethod
    def send(
        cls,
        recipient: User,
        title: str,
        content: str,
        channel: str = 'site',
        sender: Optional[User] = None,
        source_module: str = '',
    ) -> Notification:
        """
        发送单条通知

        Args:
            recipient: 接收人
            title: 标题
            content: 内容
            channel: 渠道（site / email / sms）
            sender: 发送人（可选）
            source_module: 来源模块名

        Returns:
            创建的 Notification 对象
        """
        notification = Notification.objects.create(
            recipient=recipient,
            sender=sender,
            title=title,
            content=content,
            channel=channel,
            source_module=source_module,
        )

        logger.info(
            f'通知已创建: [{channel}] {title} -> {recipient.username} '
            f'(来源: {source_module or "系统"})'
        )

        # 外部渠道异步分发
        if channel in ('email', 'sms'):
            cls._dispatch_async(notification)

        return notification

    # ----------------------------------------------------------------
    # 批量发送
    # ----------------------------------------------------------------
    @classmethod
    def send_bulk(
        cls,
        recipients: List[User],
        title: str,
        content: str,
        channel: str = 'site',
        sender: Optional[User] = None,
        source_module: str = '',
    ) -> List[Notification]:
        """
        批量发送通知（高效 bulk_create）

        Args:
            recipients: 接收人列表
            title: 标题
            content: 内容
            channel: 渠道
            sender: 发送人
            source_module: 来源模块

        Returns:
            创建的 Notification 列表
        """
        if not recipients:
            return []

        notifications = [
            Notification(
                recipient=r,
                sender=sender,
                title=title,
                content=content,
                channel=channel,
                source_module=source_module,
            )
            for r in recipients
        ]
        created = Notification.objects.bulk_create(notifications)

        logger.info(
            f'批量通知已创建: [{channel}] {title} -> {len(created)} 人 '
            f'(来源: {source_module or "系统"})'
        )

        # 外部渠道逐条异步分发
        if channel in ('email', 'sms'):
            for n in created:
                cls._dispatch_async(n)

        return created

    # ----------------------------------------------------------------
    # 权限组通知
    # ----------------------------------------------------------------
    @classmethod
    def send_to_group(
        cls,
        group_name: str,
        title: str,
        content: str,
        channel: str = 'site',
        sender: Optional[User] = None,
        source_module: str = '',
    ) -> List[Notification]:
        """
        向权限组全体成员发送通知

        Args:
            group_name: 权限组名称
            其他参数同 send

        Returns:
            创建的 Notification 列表，组不存在返回空列表
        """
        from core.models import PermissionGroup

        group = PermissionGroup.objects.filter(name=group_name).first()
        if not group:
            logger.warning(f'权限组不存在: {group_name}，通知发送失败')
            return []

        recipients = list(group.users.all())
        if not recipients:
            logger.info(f'权限组 {group_name} 无成员，跳过通知')
            return []

        return cls.send_bulk(
            recipients=recipients,
            title=title,
            content=content,
            channel=channel,
            sender=sender,
            source_module=source_module,
        )

    # ----------------------------------------------------------------
    # 查询
    # ----------------------------------------------------------------
    @classmethod
    def get_unread_count(cls, user: User) -> int:
        """获取用户未读通知数"""
        return Notification.objects.filter(
            recipient=user,
            is_read=False,
        ).count()

    @classmethod
    def mark_as_read(cls, notification_ids: List[int], user: User) -> int:
        """
        批量标记已读

        Args:
            notification_ids: 通知 ID 列表
            user: 当前用户（防止越权）

        Returns:
            实际标记数量
        """
        updated = Notification.objects.filter(
            id__in=notification_ids,
            recipient=user,
            is_read=False,
        ).update(is_read=True)
        return updated

    @classmethod
    def mark_all_as_read(cls, user: User) -> int:
        """标记全部已读"""
        updated = Notification.objects.filter(
            recipient=user,
            is_read=False,
        ).update(is_read=True)
        return updated

    # ----------------------------------------------------------------
    # 内部方法
    # ----------------------------------------------------------------
    @classmethod
    def _dispatch_async(cls, notification: Notification):
        """通过 Celery 异步分发外部渠道通知"""
        try:
            from .tasks import dispatch_notification
            dispatch_notification.delay(notification.id)
        except Exception as e:
            # Celery 不可用时降级为同步分发
            logger.warning(f'Celery 不可用，降级同步分发: {e}')
            cls._dispatch_sync(notification)

    @classmethod
    def _dispatch_sync(cls, notification: Notification):
        """同步分发（降级方案）"""
        try:
            if notification.channel == 'email':
                from .backends.email import send_email_notification
                send_email_notification(notification)
            elif notification.channel == 'sms':
                from .backends.sms import send_sms_notification
                send_sms_notification(notification)
        except Exception as e:
            logger.error(f'通知分发失败 [id={notification.id}]: {e}')
