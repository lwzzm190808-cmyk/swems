# shared/notification/__init__.py
# 保持空文件，避免启动时循环导入
# 使用时显式导入：from shared.notification.service import NotificationService
