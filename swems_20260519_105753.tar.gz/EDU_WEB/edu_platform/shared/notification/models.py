# shared/notification/models.py
"""
通知数据模型

通知是独立的公共服务，任何模块都可以调用。
通过 source_module 字符串字段关联来源，不与具体模型建立外键，
保持通知服务的独立性和可复用性。
"""

from django.db import models


class Notification(models.Model):
    """站内通知"""

    CHANNEL_CHOICES = [
        ('site', '站内信'),
        ('email', '邮件'),
        ('sms', '短信'),
    ]

    recipient = models.ForeignKey(
        'core.User',
        on_delete=models.CASCADE,
        related_name='notifications',
        verbose_name='接收人',
    )
    sender = models.ForeignKey(
        'core.User',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='sent_notifications',
        verbose_name='发送人',
    )
    title = models.CharField(
        max_length=200,
        verbose_name='标题',
    )
    content = models.TextField(
        verbose_name='内容',
    )
    channel = models.CharField(
        max_length=10,
        choices=CHANNEL_CHOICES,
        default='site',
        verbose_name='渠道',
    )
    source_module = models.CharField(
        max_length=50,
        blank=True,
        default='',
        db_index=True,
        verbose_name='来源模块',
        help_text='标识通知来自哪个模块，便于溯源',
    )
    is_read = models.BooleanField(
        default=False,
        db_index=True,
        verbose_name='是否已读',
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        db_index=True,
        verbose_name='创建时间',
    )

    class Meta:
        db_table = 'sys_notification'
        verbose_name = '通知'
        verbose_name_plural = verbose_name
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['recipient', 'is_read', '-created_at']),
        ]

    def __str__(self):
        return f'[{self.get_channel_display()}] {self.title}'
