# shared/notification/backends/sms.py
"""
短信通知后端 — 占位实现

实际项目中对接短信服务商（如阿里云短信、腾讯云短信）。
当前写入日志，后续替换为真实发送逻辑即可。
"""

import logging

logger = logging.getLogger(__name__)


def send_sms_notification(notification) -> None:
    """
    发送短信通知

    Args:
        notification: Notification 实例

    TODO: 对接真实短信服务
    """
    recipient_phone = getattr(notification.recipient, 'phone', None)
    if not recipient_phone:
        logger.warning(f'通知 {notification.id} 的接收人无手机号，跳过')
        return

    # --- 占位实现：写日志 ---
    logger.info(
        f'[SMS] -> {recipient_phone} | '
        f'内容: {notification.title}: {notification.content[:60]}'
    )

    # --- 真实实现示例 ---
    # import requests
    # requests.post('https://sms-api.example.com/send', json={
    #     'phone': recipient_phone,
    #     'content': f'{notification.title}: {notification.content}',
    # })
# shared/notification/backends/sms.py
"""
短信通知后端 — 占位实现

实际项目中对接短信服务商（如阿里云短信、腾讯云短信）。
当前写入日志，后续替换为真实发送逻辑即可。
"""

import logging

logger = logging.getLogger(__name__)


def send_sms_notification(notification) -> None:
    """
    发送短信通知

    Args:
        notification: Notification 实例

    TODO: 对接真实短信服务
    """
    recipient_phone = getattr(notification.recipient, 'phone', None)
    if not recipient_phone:
        logger.warning(f'通知 {notification.id} 的接收人无手机号，跳过')
        return

    # --- 占位实现：写日志 ---
    logger.info(
        f'[SMS] -> {recipient_phone} | '
        f'内容: {notification.title}: {notification.content[:60]}'
    )

    # --- 真实实现示例 ---
    # import requests
    # requests.post('https://sms-api.example.com/send', json={
    #     'phone': recipient_phone,
    #     'content': f'{notification.title}: {notification.content}',
    # })
