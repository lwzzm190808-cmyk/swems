# shared/notification/backends/email.py
"""
邮件通知后端 — 占位实现

实际项目中对接 SMTP 或第三方邮件服务（如 SendGrid、阿里云邮件推送）。
当前写入日志，后续替换为真实发送逻辑即可。
"""

import logging

logger = logging.getLogger(__name__)


def send_email_notification(notification) -> None:
    """
    发送邮件通知

    Args:
        notification: Notification 实例

    TODO: 对接真实邮件服务
    """
    recipient_email = getattr(notification.recipient, 'email', None)
    if not recipient_email:
        logger.warning(f'通知 {notification.id} 的接收人无邮箱地址，跳过')
        return

    # --- 占位实现：写日志 ---
    logger.info(
        f'[EMAIL] -> {recipient_email} | '
        f'标题: {notification.title} | '
        f'内容: {notification.content[:100]}'
    )

    # --- 真实实现示例 ---
    # from django.core.mail import send_mail
    # send_mail(
    #     subject=notification.title,
    #     message=notification.content,
    #     from_email='noreply@edu-platform.com',
    #     recipient_list=[recipient_email],
    #     fail_silently=False,
    # )
