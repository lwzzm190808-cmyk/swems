# shared/notification/tasks.py
"""
通知异步分发任务

Celery Worker 执行，负责将站外通知（邮件/短信）实际发送出去。
"""

import logging
from celery import shared_task

from core.models import Notification

logger = logging.getLogger(__name__)


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def dispatch_notification(self, notification_id: int):
    """
    分发单条外部渠道通知

    失败自动重试 3 次，间隔 60 秒。
    """
    try:
        notification = Notification.objects.get(id=notification_id)
    except Notification.DoesNotExist:
        logger.warning(f'通知已不存在: id={notification_id}')
        return

    try:
        if notification.channel == 'email':
            from .backends.email import send_email_notification
            send_email_notification(notification)
        elif notification.channel == 'sms':
            from .backends.sms import send_sms_notification
            send_sms_notification(notification)
        else:
            logger.info(f'通知 {notification_id} 为站内信，无需外部渠道分发')
            return

        logger.info(f'通知分发成功: id={notification_id}, channel={notification.channel}')

    except Exception as e:
        logger.error(f'通知分发失败: id={notification_id}, error={e}')
        raise self.retry(exc=e)
