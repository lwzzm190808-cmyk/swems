# shared/notification/admin.py
"""通知服务后台管理"""

from django.contrib import admin
from .models import Notification


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ['title', 'recipient', 'sender', 'channel', 'is_read', 'created_at']
    list_filter = ['channel', 'is_read']
    search_fields = ['title', 'content', 'recipient__username']
    readonly_fields = ['created_at']
    date_hierarchy = 'created_at'
