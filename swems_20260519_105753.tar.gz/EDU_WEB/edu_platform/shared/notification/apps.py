# shared/notification/apps.py
from django.apps import AppConfig


class NotificationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'shared.notification'
    verbose_name = '通知服务'
