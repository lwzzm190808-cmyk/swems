# shared/sandbox/monitor.py
"""
插件沙盒监控器

提供三级安全策略：
  strict   — 阻断网络、严格限制数据库查询、短超时
  moderate — 记录网络访问、中等限制、默认级别
  permissive — 仅记录、宽松限制

所有事件写入 OperationLog（log_type='security' 或 'runtime'）
"""

import time
import logging
import threading
import re
from urllib.parse import urlparse
from contextlib import contextmanager
from unittest.mock import patch

logger = logging.getLogger('shared.sandbox')


class SandboxViolation(Exception):
    """插件违反沙盒规则"""
    pass


class NetworkGuard:
    """网络访问监控"""

    def __init__(self, whitelist=None, blacklist=None, mode='log'):
        self.whitelist = whitelist or []
        self.blacklist = blacklist or []
        self.mode = mode
        self.access_log = []

    def check(self, host, port=80):
        entry = {
            'host': host,
            'port': port,
            'timestamp': time.time(),
            'allowed': True,
        }

        if self.mode == 'block':
            if self.blacklist and host in self.blacklist:
                entry['allowed'] = False
                self.access_log.append(entry)
                raise SandboxViolation(f'网络访问被拦截（黑名单）: {host}:{port}')
            if self.whitelist and host not in self.whitelist:
                entry['allowed'] = False
                self.access_log.append(entry)
                raise SandboxViolation(f'网络访问被拦截（非白名单）: {host}:{port}')

        self.access_log.append(entry)
        return entry

    def check_url(self, url):
        try:
            parsed = urlparse(url)
            host = parsed.hostname or ''
            port = parsed.port or (443 if parsed.scheme == 'https' else 80)
            return self.check(host, port)
        except SandboxViolation:
            raise
        except Exception:
            pass
        return {'allowed': True}

    def get_summary(self):
        hosts = list(set(e['host'] for e in self.access_log))
        blocked = sum(1 for e in self.access_log if not e['allowed'])
        return {
            'total': len(self.access_log),
            'blocked': blocked,
            'hosts': hosts,
        }


class DatabaseGuard:
    """数据库访问监控"""

    def __init__(self, max_queries=200, allowed_tables=None):
        self.max_queries = max_queries
        self.allowed_tables = allowed_tables or []
        self.query_count = 0
        self.queries = []

    def record(self, sql):
        self.query_count += 1

        if self.query_count > self.max_queries:
            raise SandboxViolation(f'数据库查询数超限: {self.max_queries}')

        if self.allowed_tables:
            sql_upper = sql.upper()
            tables_in_sql = re.findall(r'(?:FROM|INTO|UPDATE|JOIN)\s+[`"\']?(\w+)[`"\']?', sql_upper)
            for table in tables_in_sql:
                if table.lower() not in [t.lower() for t in self.allowed_tables]:
                    raise SandboxViolation(f'数据库表访问被拦截: {table}')

        self.queries.append({
            'sql': sql[:300],
            'timestamp': time.time(),
        })

    def get_summary(self):
        return {
            'total': self.query_count,
            'limit': self.max_queries,
        }


class ResourceGuard:
    """资源使用监控"""

    def __init__(self, max_time=30, max_memory_mb=256):
        self.max_time = max_time
        self.max_memory_mb = max_memory_mb
        self.start_time = None
        self.peak_memory = 0

    def check_timeout(self):
        if self.start_time:
            elapsed = time.time() - self.start_time
            if elapsed > self.max_time:
                raise SandboxViolation(f'执行超时: {self.max_time}s')

    def check_memory(self):
        try:
            import psutil, os
            proc = psutil.Process(os.getpid())
            mem_mb = proc.memory_info().rss / 1024 / 1024
            self.peak_memory = max(self.peak_memory, mem_mb)
            if mem_mb > self.max_memory_mb:
                raise SandboxViolation(f'内存超限: {mem_mb:.0f}MB > {self.max_memory_mb}MB')
        except ImportError:
            pass
        except SandboxViolation:
            raise
        except Exception:
            pass

    def get_summary(self):
        elapsed = time.time() - self.start_time if self.start_time else 0
        return {
            'elapsed': round(elapsed, 3),
            'max_time': self.max_time,
            'peak_memory_mb': round(self.peak_memory, 1),
        }


class PluginSandbox:
    """
    插件执行沙盒

    用法:
        sandbox = PluginSandbox('PLG-001', security_level='moderate')
        result = sandbox.execute(my_function, arg1, arg2)

    或上下文管理器:
        with PluginSandbox('PLG-001') as sandbox:
            result = my_function(arg1, arg2)
    """

    SECURITY_LEVELS = {
        'strict': {
            'network_mode': 'block',
            'max_queries': 50,
            'max_time': 10,
            'max_memory_mb': 128,
        },
        'moderate': {
            'network_mode': 'log',
            'max_queries': 200,
            'max_time': 30,
            'max_memory_mb': 256,
        },
        'permissive': {
            'network_mode': 'allow',
            'max_queries': 1000,
            'max_time': 60,
            'max_memory_mb': 512,
        },
    }

    def __init__(self, plugin_id, security_level='moderate', config=None):
        self.plugin_id = plugin_id
        self.security_level = security_level
        self.plugin_config = config or {}

        level_defaults = self.SECURITY_LEVELS.get(security_level, self.SECURITY_LEVELS['moderate'])
        merged = {**level_defaults, **self.plugin_config.get('sandbox', {})}

        self.network = NetworkGuard(
            whitelist=merged.get('network_whitelist', []),
            blacklist=merged.get('network_blacklist', []),
            mode=merged.get('network_mode', 'log'),
        )
        self.database = DatabaseGuard(
            max_queries=merged.get('max_queries', 200),
            allowed_tables=merged.get('allowed_tables', []),
        )
        self.resource = ResourceGuard(
            max_time=merged.get('max_time', 30),
            max_memory_mb=merged.get('max_memory_mb', 256),
        )

        self.events = []
        self._start_time = None

    def execute(self, func, *args, **kwargs):
        """在沙盒中执行函数"""
        self._start_time = time.time()
        self.resource.start_time = self._start_time

        self._log('start', f'安全级别: {self.security_level}')

        result_box = [None]
        error_box = [None]

        def target():
            try:
                # 拦截网络调用
                with self._patch_network():
                    # 拦截数据库查询
                    with self._patch_database():
                        result_box[0] = func(*args, **kwargs)
            except Exception as e:
                error_box[0] = e

        thread = threading.Thread(target=target, daemon=True)
        thread.start()
        thread.join(timeout=self.resource.max_time)

        if thread.is_alive():
            self._log('timeout', f'超时 {self.resource.max_time}s', severity='error')
            self._save_log()
            raise SandboxViolation(f'插件执行超时: {self.resource.max_time}s')

        if error_box[0]:
            if isinstance(error_box[0], SandboxViolation):
                self._log('violation', str(error_box[0]), severity='error')
            else:
                self._log('error', str(error_box[0]), severity='error')
            self._save_log()
            raise error_box[0]

        self._log('end', '执行完成')
        self._save_log()

        return result_box[0]

    def __enter__(self):
        self._start_time = time.time()
        self.resource.start_time = self._start_time
        self._log('start', f'安全级别: {self.security_level}')
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_val:
            if isinstance(exc_val, SandboxViolation):
                self._log('violation', str(exc_val), severity='error')
            else:
                self._log('error', str(exc_val), severity='error')
        else:
            self._log('end', '执行完成')
        self._save_log()
        return False

    def get_http_client(self):
        """返回沙盒化的 HTTP 客户端函数（供插件通过 SystemAPI 使用）"""
        guard = self.network

        def sandbox_request(method, url, **kwargs):
            guard.check_url(url)
            import requests as req
            return req.request(method, url, **kwargs)

        return sandbox_request

    @contextmanager
    def _patch_network(self):
        """在网络拦截模式下，拦截 socket 连接"""
        if self.network.mode != 'block':
            yield
            return

        import socket
        original_connect = socket.create_connection

        def guarded_connect(address, *args, **kwargs):
            host, port = address[0], address[1] if len(address) > 1 else 80
            self.network.check(host, port)
            return original_connect(address, *args, **kwargs)

        with patch.object(socket, 'create_connection', guarded_connect):
            yield

    @contextmanager
    def _patch_database(self):
        """拦截数据库查询"""
        from django.db import connection

        # 保存查询计数
        initial_count = len(connection.queries_log) if hasattr(connection, 'queries_log') else 0

        yield

        # 计算执行期间的查询数
        if hasattr(connection, 'queries'):
            new_queries = connection.queries[initial_count:]
            for q in new_queries:
                try:
                    self.database.record(q.get('sql', ''))
                except SandboxViolation:
                    self._log('db_violation', str(e), severity='error')
                    raise

    def _log(self, event_type, detail, severity='info'):
        self.events.append({
            'type': event_type,
            'detail': detail,
            'severity': severity,
            'timestamp': time.time(),
        })

    def _save_log(self):
        """保存到 OperationLog"""
        import json
        from core.models import OperationLog

        duration = time.time() - self._start_time if self._start_time else 0
        has_violations = any(e['severity'] == 'error' for e in self.events)

        log_data = {
            'plugin_id': self.plugin_id,
            'security_level': self.security_level,
            'duration': round(duration, 3),
            'events': self.events,
            'network': self.network.get_summary(),
            'database': self.database.get_summary(),
            'resource': self.resource.get_summary(),
            'violations': [e for e in self.events if e['severity'] == 'error'],
        }

        try:
            OperationLog.objects.create(
                log_type='security' if has_violations else 'runtime',
                level='warning' if has_violations else 'info',
                module='sandbox',
                action=f'插件沙盒会话: {self.plugin_id}',
                detail=json.dumps(log_data, ensure_ascii=False, default=str),
            )
        except Exception as e:
            logger.error(f'沙盒日志保存失败: {e}')


    def get_report(self):
        """获取当前会话报告"""
        return {
            'plugin_id': self.plugin_id,
            'security_level': self.security_level,
            'duration': round(time.time() - self._start_time, 3) if self._start_time else 0,
            'events': self.events,
            'network': self.network.get_summary(),
            'database': self.database.get_summary(),
            'resource': self.resource.get_summary(),
            'violations': [e for e in self.events if e['severity'] == 'error'],
        }
