# shared/security/encryption.py
"""
敏感数据加密服务

使用 Fernet（AES-128-CBC + HMAC）对称加密。
密钥从 Django SECRET_KEY 派生，无需额外管理密钥。

用于：数据库密码、API Key 等敏感配置的加密存储。
"""

import base64
import hashlib
import logging

from cryptography.fernet import Fernet, InvalidToken
from django.conf import settings

logger = logging.getLogger(__name__)


def _get_fernet() -> Fernet:
    """基于 Django SECRET_KEY 派生加密器"""
    key = hashlib.sha256(settings.SECRET_KEY.encode()).digest()
    fernet_key = base64.urlsafe_b64encode(key)
    return Fernet(fernet_key)


def encrypt_value(plaintext: str) -> str:
    """
    加密明文

    Args:
        plaintext: 待加密的明文字符串

    Returns:
        加密后的 base64 编码字符串
    """
    if not plaintext:
        return ''
    f = _get_fernet()
    encrypted = f.encrypt(plaintext.encode('utf-8'))
    return encrypted.decode('utf-8')


def decrypt_value(ciphertext: str) -> str:
    """
    解密密文

    Args:
        ciphertext: 加密后的字符串

    Returns:
        解密后的明文，解密失败返回 '[解密失败]'
    """
    if not ciphertext:
        return ''
    try:
        f = _get_fernet()
        decrypted = f.decrypt(ciphertext.encode('utf-8'))
        return decrypted.decode('utf-8')
    except InvalidToken:
        logger.warning('解密失败：密文无效或密钥不匹配')
        return '[解密失败]'
    except Exception as e:
        logger.error(f'解密异常: {e}')
        return '[解密失败]'

