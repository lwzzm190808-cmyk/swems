# shared/security/validator.py
"""
输入校验与安全过滤

集中定义所有输入校验规则，被 core/services、modules、plugins 统一调用。
"""

import re
import logging
from typing import Optional

import bleach

logger = logging.getLogger(__name__)


class InputValidator:
    """
    统一输入校验器

    所有方法均为类方法，无需实例化。
    """

    # ----------------------------------------------------------------
    # SQL 安全
    # ----------------------------------------------------------------
    # 仅在 custom_query 标签的 SQL 校验中使用
    SQL_DANGEROUS_KEYWORDS = frozenset({
        'DROP', 'DELETE', 'TRUNCATE', 'INSERT', 'UPDATE',
        'ALTER', 'CREATE', 'EXEC', 'EXECUTE', 'UNION',
        'GRANT', 'REVOKE', 'REPLACE', 'INTO',
    })

    @classmethod
    def validate_sql_select(cls, sql: str) -> tuple:
        """
        校验 SQL 是否为安全的 SELECT 语句

        Args:
            sql: SQL 语句

        Returns:
            (is_valid, error_message)
        """
        if not sql or not sql.strip():
            return False, 'SQL 语句不能为空'

        normalized = ' '.join(sql.strip().upper().split())

        # 必须以 SELECT 开头
        if not normalized.startswith('SELECT'):
            return False, '仅允许 SELECT 查询语句'

        # 检查危险关键字
        tokens = set(re.findall(r'\b([A-Z]+)\b', normalized))
        dangerous_found = tokens & cls.SQL_DANGEROUS_KEYWORDS
        if dangerous_found:
            return False, f'SQL 包含禁止的关键字: {", ".join(sorted(dangerous_found))}'

        # 禁止分号后跟语句（防止多语句注入）
        statements = [s.strip() for s in sql.split(';') if s.strip()]
        if len(statements) > 1:
            return False, '禁止多语句执行'

        return True, ''

    # ----------------------------------------------------------------
    # 标识符校验
    # ----------------------------------------------------------------
    TAG_CODE_PATTERN = re.compile(r'^[a-zA-Z][a-zA-Z0-9_.]*$')
    PLUGIN_NAME_PATTERN = re.compile(r'^[a-zA-Z_][a-zA-Z0-9_]*$')
    IDENTIFIER_PATTERN = re.compile(r'^[a-zA-Z_][a-zA-Z0-9_]*$')

    @classmethod
    def validate_tag_code(cls, tag_code: str) -> tuple:
        """
        校验标签代码格式

        合法示例: article.title, course.latest, news.top5
        """
        if not tag_code:
            return False, '标签代码不能为空'
        if len(tag_code) > 200:
            return False, '标签代码不能超过 200 字符'
        if not cls.TAG_CODE_PATTERN.match(tag_code):
            return False, '标签代码只允许字母、数字、下划线、点，且必须以字母开头'
        return True, ''

    @classmethod
    def validate_plugin_name(cls, name: str) -> tuple:
        """
        校验插件标识名格式

        合法示例: content_manager, news_widget, course_export
        """
        if not name:
            return False, '插件名不能为空'
        if len(name) > 100:
            return False, '插件名不能超过 100 字符'
        if not cls.PLUGIN_NAME_PATTERN.match(name):
            return False, '插件名只允许字母、数字、下划线，且必须以字母或下划线开头'
        return True, ''

    @classmethod
    def validate_identifier(cls, value: str, field_name: str = '标识符', max_length: int = 100) -> tuple:
        """通用标识符校验"""
        if not value:
            return False, f'{field_name}不能为空'
        if len(value) > max_length:
            return False, f'{field_name}不能超过 {max_length} 字符'
        if not cls.IDENTIFIER_PATTERN.match(value):
            return False, f'{field_name}只允许字母、数字、下划线，且必须以字母或下划线开头'
        return True, ''

    # ----------------------------------------------------------------
    # HTML 清洗
    # ----------------------------------------------------------------
    ALLOWED_TAGS = [
        'p', 'br', 'strong', 'em', 'u', 's',
        'ul', 'ol', 'li',
        'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
        'a', 'img',
        'table', 'thead', 'tbody', 'tr', 'td', 'th',
        'div', 'span', 'pre', 'code', 'blockquote',
        'hr', 'sub', 'sup',
    ]

    ALLOWED_ATTRIBUTES = {
        'a': ['href', 'title', 'target'],
        'img': ['src', 'alt', 'width', 'height'],
        'td': ['colspan', 'rowspan'],
        'th': ['colspan', 'rowspan'],
    }

    @classmethod
    def sanitize_html(cls, html: str) -> str:
        """
        XSS 防护：清洗 HTML 内容

        保留安全标签和属性，移除所有脚本注入。
        """
        if not html:
            return ''
        return bleach.clean(
            html,
            tags=cls.ALLOWED_TAGS,
            attributes=cls.ALLOWED_ATTRIBUTES,
            strip=True,
        )

    # ----------------------------------------------------------------
    # 通用文本校验
    # ----------------------------------------------------------------
    @classmethod
    def validate_required(cls, value, field_name: str) -> tuple:
        """非空校验"""
        if value is None or (isinstance(value, str) and not value.strip()):
            return False, f'{field_name}不能为空'
        return True, ''

    @classmethod
    def validate_length(cls, value: str, field_name: str, min_len: int = 0, max_len: int = 255) -> tuple:
        """长度校验"""
        if len(value) < min_len:
            return False, f'{field_name}长度不能少于 {min_len} 个字符'
        if len(value) > max_len:
            return False, f'{field_name}长度不能超过 {max_len} 个字符'
        return True, ''
# shared/security/validator.py
"""
输入校验与安全过滤

集中定义所有输入校验规则，被 core/services、modules、plugins 统一调用。
"""

import re
import logging
from typing import Optional

import bleach

logger = logging.getLogger(__name__)


class InputValidator:
    """
    统一输入校验器

    所有方法均为类方法，无需实例化。
    """

    # ----------------------------------------------------------------
    # SQL 安全
    # ----------------------------------------------------------------
    # 仅在 custom_query 标签的 SQL 校验中使用
    SQL_DANGEROUS_KEYWORDS = frozenset({
        'DROP', 'DELETE', 'TRUNCATE', 'INSERT', 'UPDATE',
        'ALTER', 'CREATE', 'EXEC', 'EXECUTE', 'UNION',
        'GRANT', 'REVOKE', 'REPLACE', 'INTO',
    })

    @classmethod
    def validate_sql_select(cls, sql: str) -> tuple:
        """
        校验 SQL 是否为安全的 SELECT 语句

        Args:
            sql: SQL 语句

        Returns:
            (is_valid, error_message)
        """
        if not sql or not sql.strip():
            return False, 'SQL 语句不能为空'

        normalized = ' '.join(sql.strip().upper().split())

        # 必须以 SELECT 开头
        if not normalized.startswith('SELECT'):
            return False, '仅允许 SELECT 查询语句'

        # 检查危险关键字
        tokens = set(re.findall(r'\b([A-Z]+)\b', normalized))
        dangerous_found = tokens & cls.SQL_DANGEROUS_KEYWORDS
        if dangerous_found:
            return False, f'SQL 包含禁止的关键字: {", ".join(sorted(dangerous_found))}'

        # 禁止分号后跟语句（防止多语句注入）
        statements = [s.strip() for s in sql.split(';') if s.strip()]
        if len(statements) > 1:
            return False, '禁止多语句执行'

        return True, ''

    # ----------------------------------------------------------------
    # 标识符校验
    # ----------------------------------------------------------------
    TAG_CODE_PATTERN = re.compile(r'^[a-zA-Z][a-zA-Z0-9_.]*$')
    PLUGIN_NAME_PATTERN = re.compile(r'^[a-zA-Z_][a-zA-Z0-9_]*$')
    IDENTIFIER_PATTERN = re.compile(r'^[a-zA-Z_][a-zA-Z0-9_]*$')

    @classmethod
    def validate_tag_code(cls, tag_code: str) -> tuple:
        """
        校验标签代码格式

        合法示例: article.title, course.latest, news.top5
        """
        if not tag_code:
            return False, '标签代码不能为空'
        if len(tag_code) > 200:
            return False, '标签代码不能超过 200 字符'
        if not cls.TAG_CODE_PATTERN.match(tag_code):
            return False, '标签代码只允许字母、数字、下划线、点，且必须以字母开头'
        return True, ''

    @classmethod
    def validate_plugin_name(cls, name: str) -> tuple:
        """
        校验插件标识名格式

        合法示例: content_manager, news_widget, course_export
        """
        if not name:
            return False, '插件名不能为空'
        if len(name) > 100:
            return False, '插件名不能超过 100 字符'
        if not cls.PLUGIN_NAME_PATTERN.match(name):
            return False, '插件名只允许字母、数字、下划线，且必须以字母或下划线开头'
        return True, ''

    @classmethod
    def validate_identifier(cls, value: str, field_name: str = '标识符', max_length: int = 100) -> tuple:
        """通用标识符校验"""
        if not value:
            return False, f'{field_name}不能为空'
        if len(value) > max_length:
            return False, f'{field_name}不能超过 {max_length} 字符'
        if not cls.IDENTIFIER_PATTERN.match(value):
            return False, f'{field_name}只允许字母、数字、下划线，且必须以字母或下划线开头'
        return True, ''

    # ----------------------------------------------------------------
    # HTML 清洗
    # ----------------------------------------------------------------
    ALLOWED_TAGS = [
        'p', 'br', 'strong', 'em', 'u', 's',
        'ul', 'ol', 'li',
        'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
        'a', 'img',
        'table', 'thead', 'tbody', 'tr', 'td', 'th',
        'div', 'span', 'pre', 'code', 'blockquote',
        'hr', 'sub', 'sup',
    ]

    ALLOWED_ATTRIBUTES = {
        'a': ['href', 'title', 'target'],
        'img': ['src', 'alt', 'width', 'height'],
        'td': ['colspan', 'rowspan'],
        'th': ['colspan', 'rowspan'],
    }

    @classmethod
    def sanitize_html(cls, html: str) -> str:
        """
        XSS 防护：清洗 HTML 内容

        保留安全标签和属性，移除所有脚本注入。
        """
        if not html:
            return ''
        return bleach.clean(
            html,
            tags=cls.ALLOWED_TAGS,
            attributes=cls.ALLOWED_ATTRIBUTES,
            strip=True,
        )

    # ----------------------------------------------------------------
    # 通用文本校验
    # ----------------------------------------------------------------
    @classmethod
    def validate_required(cls, value, field_name: str) -> tuple:
        """非空校验"""
        if value is None or (isinstance(value, str) and not value.strip()):
            return False, f'{field_name}不能为空'
        return True, ''

    @classmethod
    def validate_length(cls, value: str, field_name: str, min_len: int = 0, max_len: int = 255) -> tuple:
        """长度校验"""
        if len(value) < min_len:
            return False, f'{field_name}长度不能少于 {min_len} 个字符'
        if len(value) > max_len:
            return False, f'{field_name}长度不能超过 {max_len} 个字符'
        return True, ''
