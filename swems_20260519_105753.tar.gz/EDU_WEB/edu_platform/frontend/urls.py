# frontend/urls.py
"""前台路由"""

from django.urls import path, re_path
from admin_panel.views import FrontendLoginView, FrontendRegisterView
from . import views

app_name = 'frontend'

urlpatterns = [
    path('login/',    FrontendLoginView.as_view(),    name='login'),
    path('register/', FrontendRegisterView.as_view(), name='register'),
    # Catch-all 放最后
    re_path(r'^(?P<path>.*)$', views.FrontendView.as_view(), name='page'),
]
