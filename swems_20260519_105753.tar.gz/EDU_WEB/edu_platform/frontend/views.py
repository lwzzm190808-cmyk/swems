# frontend/views.py
"""
前台页面渲染

核心逻辑：
1. 根据 URL 路径查找对应的模板文件
2. 优先从数据库（Template 模型）查找，其次从磁盘查找
3. 使用 Django 模板引擎渲染，CMS 标签自动解析
4. 404 时尝试加载 404.html 模板

URL 映射规则：
  /                 → home.html
  /courses/         → courses.html
  /course/detail/   → course_detail.html
  /about/           → about.html
  任意路径           → 对应路径.html
"""

import logging
from pathlib import Path
from admin_panel.views import FrontendLoginView, FrontendRegisterView
from django.conf import settings
from django.http import HttpResponse, Http404
from django.template.loader import get_template
from django.template import TemplateDoesNotExist
from django.views import View

logger = logging.getLogger(__name__)


class FrontendView(View):
    """
    前台页面统一视图

    所有前台 URL 最终由这个视图处理。
    它从 templates/ 目录（或数据库）加载对应的 HTML 模板并渲染。
    """

    # 默认模板名映射（特殊路径 → 模板文件）
    URL_TEMPLATE_MAP = {
        '': 'home.html',
        '/': 'home.html',
    }

    def get(self, request, path=''):
        template_name = self._resolve_template(path)

        context = self._build_context(request, path)

        if template_name is None:
            # 模板不存在，渲染自定义 404 页面
            return self._render_404(request)

        try:
            html = self._render_template(template_name, context)
            return HttpResponse(html)
        except TemplateDoesNotExist:
            return self._render_404(request)
        except Exception as e:
            logger.error(f'页面渲染失败 [{path}]: {e}')
            return HttpResponse(f'<!-- 渲染错误: {str(e)} -->', status=500)

    # ----------------------------------------------------------------
    # 模板解析
    # ----------------------------------------------------------------

    def _resolve_template(self, path: str) -> str:
        """
        将 URL 路径解析为模板文件名

        解析顺序：
        1. 查 URL_TEMPLATE_MAP 特殊映射
        2. 直接匹配路径对应的 .html 文件
        3. 匹配路径 + index.html

        Returns:
            模板文件名，找不到返回 None
        """
        path = path.strip('/')

        # 特殊映射
        if path in self.URL_TEMPLATE_MAP:
            return self.URL_TEMPLATE_MAP[path]

        if not path:
            return 'home.html'

        # 直接匹配: courses → courses.html
        candidates = [
            f'{path}.html',
            f'{path}/index.html',
        ]

        for candidate in candidates:
            if self._template_exists(candidate):
                return candidate

        return None

    def _template_exists(self, template_name: str) -> bool:
        """
        检查模板是否存在

        优先检查数据库记录（支持在线编辑的模板），
        然后检查磁盘文件。
        """
        # 检查数据库
        from core.models import Template
        if Template.objects.filter(file_path=template_name).exists():
            return True

        # 检查磁盘
        try:
            get_template(template_name)
            return True
        except TemplateDoesNotExist:
            return False

    # ----------------------------------------------------------------
    # 上下文
    # ----------------------------------------------------------------

    def _build_context(self, request, path: str) -> dict:
        """
        构建模板上下文

        所有页面共享的基础上下文。
        CMS 标签在模板中通过 {% cms_tag %} 解析，
        不需要在上下文中传递。
        """
        return {
            'request': request,
            'user': request.user if hasattr(request, 'user') else None,
            'path': path,
            'site': self._get_site_info(),
        }

    def _get_site_info(self) -> dict:
        """获取站点基本信息（供 base.html 使用）"""
        from core.services.config_service import ConfigService

        return {
            'name': ConfigService.get('site', 'site_name') or '在线教育平台',
            'slogan': ConfigService.get('site', 'site_slogan') or '',
            'logo': ConfigService.get('site', 'site_logo') or '',
            'copyright': ConfigService.get('site', 'copyright') or '© 2025 EduPlatform',
        }

    # ----------------------------------------------------------------
    # 渲染
    # ----------------------------------------------------------------

    def _render_template(self, template_name: str, context: dict) -> str:
        """
        渲染模板

        使用 Django 模板引擎，自动加载 CMS 标签库。
        """
        from django.template.loader import render_to_string
        return render_to_string(template_name, context)

    def _render_404(self, request) -> HttpResponse:
        """渲染 404 页面"""
        try:
            from django.template.loader import render_to_string
            html = render_to_string('404.html', {'request': request})
            return HttpResponse(html, status=404)
        except TemplateDoesNotExist:
            return HttpResponse(
                '<h1>404 - 页面未找到</h1><p>您访问的页面不存在。</p>',
                status=404,
            )
