# manage.py
#!/usr/bin/env python3
"""Django 管理入口"""

import os
import sys


def main():
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "无法导入 Django。请确认：\n"
            "  1. 已安装: pip install -r requirements.txt\n"
            "  2. 已激活虚拟环境"
        ) from exc
    execute_from_command_line(sys.argv)


if __name__ == '__main__':
    main()
