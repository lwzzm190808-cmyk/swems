# modules/log/views.py
"""日志管理 API"""

import logging
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from core.services.log_service import LogService
from core.models import OperationLog

logger = logging.getLogger(__name__)


class LogListView(APIView):
    """日志查询列表"""

    def get(self, request):
        log_type = request.query_params.get('type')
        level = request.query_params.get('level')
        username = request.query_params.get('username')
        module = request.query_params.get('module')
        limit = int(request.query_params.get('limit', 100))
        offset = int(request.query_params.get('offset', 0))

        # 限制单次查询量
        limit = min(limit, 500)

        logs = LogService.query(
            log_type=log_type,
            level=level,
            username=username,
            module=module,
            limit=limit,
            offset=offset,
        )

        total = LogService.count(log_type=log_type)

        return Response({
            'data': logs,
            'total': total,
            'limit': limit,
            'offset': offset,
        })


class LogStatsView(APIView):
    """日志统计"""

    def get(self, request):
        stats = {
            'total': OperationLog.objects.count(),
            'by_type': {},
            'by_level': {},
        }

        # 按类型统计
        from django.db.models import Count
        type_counts = (
            OperationLog.objects
            .values('log_type')
            .annotate(count=Count('id'))
        )
        for item in type_counts:
            stats['by_type'][item['log_type']] = item['count']

        # 按级别统计
        level_counts = (
            OperationLog.objects
            .values('level')
            .annotate(count=Count('id'))
        )
        for item in level_counts:
            stats['by_level'][item['level']] = item['count']

        # 最近 24 小时错误数
        from django.utils import timezone
        from datetime import timedelta
        last_24h = timezone.now() - timedelta(hours=24)
        stats['errors_24h'] = OperationLog.objects.filter(
            level__in=['error', 'critical'],
            created_at__gte=last_24h,
        ).count()

        return Response({'data': stats})


class ServerStatusView(APIView):
    """服务器运行状态"""

    def get(self, request):
        status_data = LogService.get_server_status()
        return Response({'data': status_data})
