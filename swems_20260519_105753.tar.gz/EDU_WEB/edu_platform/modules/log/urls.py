# modules/log/urls.py
"""日志管理路由"""

from django.urls import path
from . import views

app_name = 'log'

urlpatterns = [
    path('', views.LogListView.as_view(), name='list'),
    path('stats/', views.LogStatsView.as_view(), name='stats'),
    path('server/', views.ServerStatusView.as_view(), name='server'),
]
