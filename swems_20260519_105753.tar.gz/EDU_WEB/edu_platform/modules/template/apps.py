# modules/template/apps.py
from django.apps import AppConfig


class TemplateConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'modules.template'
    verbose_name = '模板管理'
