# modules/template/views.py
"""模板管理 API"""

import logging
from pathlib import Path
from django.http import HttpResponse
from django.conf import settings
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from core.services.template_service import TemplateService
from core.models import Template

logger = logging.getLogger(__name__)


class TemplateListCreateView(APIView):
    """模板列表 / 创建"""

    def get(self, request):
        """获取全部模板"""
        templates = TemplateService.get_all_serialized()
        return Response({'data': templates, 'total': len(templates)})

    def post(self, request):
        """创建新模板"""
        data = request.data

        name = data.get('name', '').strip()
        file_path = data.get('file_path', '').strip()
        content = data.get('content', '')

        if not name or not file_path:
            return Response(
                {'error': 'name 和 file_path 为必填项'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # 检查路径安全性（防止路径穿越）
        if '..' in file_path or file_path.startswith('/'):
            return Response(
                {'error': '文件路径不合法'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            template = TemplateService.create(
                name=name,
                file_path=file_path,
                content=content,
                template_type=data.get('template_type', 'page'),
            )
            return Response(
                {'message': '创建成功', 'data': {'id': template.id, 'file_path': file_path}},
                status=status.HTTP_201_CREATED,
            )
        except Exception as e:
            logger.error(f'创建模板失败: {e}')
            return Response({'error': '创建失败'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class TemplateDetailView(APIView):
    """模板详情 / 更新 / 删除"""

    def get(self, request, pk):
        """获取单个模板详情"""
        try:
            template = Template.objects.get(id=pk)
        except Template.DoesNotExist:
            return Response({'error': '模板不存在'}, status=status.HTTP_404_NOT_FOUND)

        return Response({
            'data': {
                'id': template.id,
                'name': template.name,
                'file_path': template.file_path,
                'template_type': template.template_type,
                'is_system': template.is_system,
                'plugin_id': template.plugin_id,
                'updated_at': template.updated_at.strftime('%Y-%m-%d %H:%M:%S'),
            }
        })

    def put(self, request, pk):
        """更新模板信息"""
        data = request.data
        template = TemplateService.update(pk, **data)
        if template is None:
            return Response({'error': '模板不存在'}, status=status.HTTP_404_NOT_FOUND)
        return Response({'message': '更新成功'})

    def delete(self, request, pk):
        """删除模板"""
        success = TemplateService.delete(pk)
        if not success:
            return Response({'error': '模板不存在'}, status=status.HTTP_404_NOT_FOUND)
        return Response({'message': '删除成功'})


class TemplateContentView(APIView):
    """模板文件内容读写（内嵌编辑器使用）"""

    def get(self, request, pk):
        """读取模板文件内容"""
        try:
            template = Template.objects.get(id=pk)
        except Template.DoesNotExist:
            return Response({'error': '模板不存在'}, status=status.HTTP_404_NOT_FOUND)

        content = TemplateService.read_content(template.file_path)
        return Response({
            'file_path': template.file_path,
            'content': content,
        })

    def put(self, request, pk):
        """保存模板文件内容"""
        try:
            template = Template.objects.get(id=pk)
        except Template.DoesNotExist:
            return Response({'error': '模板不存在'}, status=status.HTTP_404_NOT_FOUND)

        content = request.data.get('content', '')
        success = TemplateService.save_content(template.file_path, content)

        if not success:
            return Response({'error': '保存失败'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        return Response({'message': '保存成功', 'file_path': template.file_path})



class TemplatePreviewView(APIView):
    """模板预览 — 支持返回 HTML 页面或 JSON"""

    def get(self, request, pk):
        try:
            template = Template.objects.get(id=pk)
        except Template.DoesNotExist:
            return Response({'error': '模板不存在'}, status=status.HTTP_404_NOT_FOUND)

        html = TemplateService.render(template.file_path, context={})

        # 如果请求 HTML 格式（iframe 预览），直接返回 HTML
        if request.GET.get('_format') == 'html':
            return HttpResponse(html, content_type='text/html')

        # 否则返回 JSON（API 调用）
        return Response({
            'file_path': template.file_path,
            'html': html,
        })

class TemplatePreviewView(APIView):
    """模板预览 — 支持返回 HTML 页面或 JSON"""

    def get(self, request, pk):
        try:
            template = Template.objects.get(id=pk)
        except Template.DoesNotExist:
            return Response({'error': '模板不存在'}, status=status.HTTP_404_NOT_FOUND)

        html = TemplateService.render(template.file_path, context={})

        # 如果请求 HTML 格式（iframe 预览），直接返回 HTML
        if request.GET.get('_format') == 'html':
            return HttpResponse(html, content_type='text/html')

        # 否则返回 JSON（API 调用）
        return Response({
            'file_path': template.file_path,
            'html': html,
        })



class TemplateScanView(APIView):
    """扫描 templates/ 目录，发现未注册的模板文件"""

    def get(self, request):
        """扫描文件系统并对比数据库记录"""
        template_dir = Path(settings.CMS_TEMPLATE_DIR)
        registered = set(Template.objects.values_list('file_path', flat=True))
        found = []

        for f in template_dir.rglob('*.html'):
            rel_path = str(f.relative_to(template_dir))
            found.append({
                'file_path': rel_path,
                'registered': rel_path in registered,
                'size_bytes': f.stat().st_size,
            })

        unregistered = [f for f in found if not f['registered']]
        return Response({
            'total_files': len(found),
            'registered': len(found) - len(unregistered),
            'unregistered': unregistered,
        })