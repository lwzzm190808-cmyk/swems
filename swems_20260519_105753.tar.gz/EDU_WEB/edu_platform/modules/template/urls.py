# modules/template/urls.py
"""模板管理路由"""

from django.urls import path
from . import views

app_name = 'template'

urlpatterns = [
    path('', views.TemplateListCreateView.as_view(), name='list-create'),
    path('<int:pk>/', views.TemplateDetailView.as_view(), name='detail'),
    path('<int:pk>/content/', views.TemplateContentView.as_view(), name='content'),
    path('<int:pk>/preview/', views.TemplatePreviewView.as_view(), name='preview'),
    path('scan/', views.TemplateScanView.as_view(), name='scan'),
]