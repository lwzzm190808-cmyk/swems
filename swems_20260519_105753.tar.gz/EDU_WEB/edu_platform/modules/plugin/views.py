# modules/plugin/views.py
"""插件管理 API"""

import logging
import os
import tempfile
import zipfile

from django.conf import settings
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from core.models import Plugin
from core.api.plugin_bridge import PluginSystemAPI

logger = logging.getLogger(__name__)


def _get_loader():
    """延迟获取 PluginLoader（避免循环导入）"""
    from modules.plugin.loader import PluginLoader
    return PluginLoader


class PluginListView(APIView):
    """插件列表"""

    def get(self, request):
        qs = Plugin.objects.all()
        ps = request.query_params.get('status')
        if ps:
            qs = qs.filter(status=ps)

        plugins = []
        for p in qs:
            plugins.append({
                'plugin_id': p.plugin_id,
                'name': p.name,
                'title': p.title,
                'version': p.version,
                'author': p.author,
                'description': p.description,
                'status': p.status,
                'status_display': p.get_status_display(),
                'installed_at': p.installed_at.strftime('%Y-%m-%d %H:%M:%S'),
            })

        return Response({'data': plugins, 'total': len(plugins)})


class PluginDetailView(APIView):
    """插件详情"""

    def get(self, request, plugin_id):
        try:
            plugin = Plugin.objects.get(plugin_id=plugin_id)
        except Plugin.DoesNotExist:
            return Response({'error': '插件不存在'}, status=status.HTTP_404_NOT_FOUND)

        return Response({
            'data': {
                'plugin_id': plugin.plugin_id,
                'name': plugin.name,
                'title': plugin.title,
                'version': plugin.version,
                'author': plugin.author,
                'description': plugin.description,
                'status': plugin.status,
                'config': plugin.config,
                'config_schema': plugin.config_schema,
                'install_path': plugin.install_path,
                'installed_at': plugin.installed_at.strftime('%Y-%m-%d %H:%M:%S'),
            }
        })

    def delete(self, request, plugin_id):
        """卸载插件"""
        try:
            loader = _get_loader()
            loader.uninstall(plugin_id)
            return Response({'message': f'插件 {plugin_id} 已卸载'})
        except Plugin.DoesNotExist:
            return Response({'error': '插件不存在'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            logger.error(f'卸载插件失败 [{plugin_id}]: {e}')
            return Response({'error': f'卸载失败: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class PluginInstallView(APIView):
    """安装插件（上传插件包）"""

    def post(self, request):
        """
        上传插件包并安装

        支持：
        - file: 上传 zip 包
        - path: 服务器上的插件目录路径
        """
        # 方式一：通过文件上传
        uploaded_file = request.FILES.get('file')
        if uploaded_file:
            try:
                # 保存到临时目录
                with tempfile.TemporaryDirectory() as tmp_dir:
                    zip_path = os.path.join(tmp_dir, 'plugin.zip')
                    with open(zip_path, 'wb') as f:
                        for chunk in uploaded_file.chunks():
                            f.write(chunk)

                    # 解压
                    extract_dir = os.path.join(tmp_dir, 'extracted')
                    with zipfile.ZipFile(zip_path, 'r') as zf:
                        zf.extractall(extract_dir)

                    # 查找 manifest.json 所在目录
                    plugin_dir = _find_plugin_dir(extract_dir)
                    if not plugin_dir:
                        return Response(
                            {'error': '插件包中未找到 manifest.json'},
                            status=status.HTTP_400_BAD_REQUEST,
                        )

                    loader = _get_loader()
                    plugin = loader.install(plugin_dir)

                    return Response({
                        'message': '安装成功',
                        'data': {
                            'plugin_id': plugin.plugin_id,
                            'title': plugin.title,
                            'version': plugin.version,
                        },
                    }, status=status.HTTP_201_CREATED)

            except zipfile.BadZipFile:
                return Response({'error': '无效的 ZIP 文件'}, status=status.HTTP_400_BAD_REQUEST)
            except Exception as e:
                logger.error(f'安装插件失败: {e}')
                return Response({'error': f'安装失败: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        # 方式二：通过服务器路径
        path = request.data.get('path', '').strip()
        if path:
            if not os.path.isdir(path):
                return Response({'error': f'路径不存在: {path}'}, status=status.HTTP_400_BAD_REQUEST)

            try:
                loader = _get_loader()
                plugin = loader.install(path)
                return Response({
                    'message': '安装成功',
                    'data': {
                        'plugin_id': plugin.plugin_id,
                        'title': plugin.title,
                        'version': plugin.version,
                    },
                }, status=status.HTTP_201_CREATED)
            except Exception as e:
                logger.error(f'安装插件失败: {e}')
                return Response({'error': f'安装失败: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        return Response(
            {'error': '请提供 file（ZIP上传）或 path（服务器路径）'},
            status=status.HTTP_400_BAD_REQUEST,
        )


def _find_plugin_dir(base_dir: str) -> str:
    """递归查找包含 manifest.json 的目录"""
    for root, dirs, files in os.walk(base_dir):
        if 'manifest.json' in files:
            return root
    return None


class PluginEnableView(APIView):
    """启用插件"""

    def post(self, request, plugin_id):
        try:
            loader = _get_loader()
            loader.enable(plugin_id)
            return Response({'message': f'插件 {plugin_id} 已启用'})
        except Plugin.DoesNotExist:
            return Response({'error': '插件不存在'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            logger.error(f'启用插件失败 [{plugin_id}]: {e}')
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class PluginDisableView(APIView):
    """停用插件"""

    def post(self, request, plugin_id):
        try:
            loader = _get_loader()
            loader.disable(plugin_id)
            return Response({'message': f'插件 {plugin_id} 已停用'})
        except Plugin.DoesNotExist:
            return Response({'error': '插件不存在'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            logger.error(f'停用插件失败 [{plugin_id}]: {e}')
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class PluginConfigView(APIView):
    """插件配置查看/更新"""

    def get(self, request, plugin_id):
        try:
            plugin = Plugin.objects.get(plugin_id=plugin_id)
        except Plugin.DoesNotExist:
            return Response({'error': '插件不存在'}, status=status.HTTP_404_NOT_FOUND)

        return Response({
            'plugin_id': plugin.plugin_id,
            'config': plugin.config,
            'config_schema': plugin.config_schema,
        })

    def put(self, request, plugin_id):
        try:
            plugin = Plugin.objects.get(plugin_id=plugin_id)
        except Plugin.DoesNotExist:
            return Response({'error': '插件不存在'}, status=status.HTTP_404_NOT_FOUND)

        config = request.data.get('config', {})
        plugin.config = config
        plugin.save(update_fields=['config', 'updated_at'])

        return Response({'message': '配置已更新'})


class PluginCallView(APIView):
    """调用插件 API"""

    def post(self, request, plugin_id):
        api_name = request.data.get('api', '')
        params = request.data.get('params', {})

        if not api_name:
            return Response(
                {'error': 'api 参数必填'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        api = PluginSystemAPI()
        result = api.UsePluginAPI(plugin_id, api_name, **params)

        if isinstance(result, dict) and 'error' in result:
            return Response(result, status=status.HTTP_400_BAD_REQUEST)

        return Response({'data': result})
