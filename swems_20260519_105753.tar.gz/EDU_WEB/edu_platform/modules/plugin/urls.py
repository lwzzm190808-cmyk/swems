# modules/plugin/urls.py
"""插件管理路由"""

from django.urls import path
from . import views

app_name = 'plugin'

urlpatterns = [
    path('', views.PluginListView.as_view(), name='list'),
    path('<str:plugin_id>/', views.PluginDetailView.as_view(), name='detail'),
    path('<str:plugin_id>/enable/', views.PluginEnableView.as_view(), name='enable'),
    path('<str:plugin_id>/disable/', views.PluginDisableView.as_view(), name='disable'),
    path('<str:plugin_id>/config/', views.PluginConfigView.as_view(), name='config'),
    path('<str:plugin_id>/call/', views.PluginCallView.as_view(), name='call'),
    path('install/', views.PluginInstallView.as_view(), name='install'),
]
