# modules/plugin/loader.py
"""
插件生命周期管理器

职责：
- 安装插件：读取 manifest → 分配 ID → 复制文件 → 注册标签/模板 → 执行钩子
- 启用/停用插件：调用生命周期钩子
- 卸载插件：清理标签/模板 → 删除文件 → 执行钩子 → 删除记录
- 调用插件 API：查找已加载实例 → 调用对应函数

加载器是 modules/plugin 模块的内部实现，
对外通过 views.py（管理界面）和 core/api/plugin_bridge.py（系统 API）暴露。
"""

import importlib
import json
import logging
import os
import shutil
import sys
import threading
from datetime import datetime
from typing import Any, Dict, List, Optional

from django.conf import settings

logger = logging.getLogger(__name__)


class PluginLoader:
    """
    插件加载器

    所有方法均为类方法，全局单例。
    使用 _lock 保护 _loaded_plugins 的并发访问。
    """

    # 已加载的插件实例: plugin_id -> plugin_instance
    _loaded_plugins: Dict[str, Any] = {}

    # 插件元数据缓存: plugin_id -> manifest_dict
    _registry: Dict[str, dict] = {}

    # 线程锁
    _lock = threading.Lock()

    # ================================================================
    # 安装
    # ================================================================

    @classmethod
    def install(cls, plugin_package_path: str):
        """
        安装插件

        Args:
            plugin_package_path: 插件包目录路径（包含 manifest.json）

        Returns:
            Plugin 数据库实例

        Raises:
            FileNotFoundError: manifest.json 不存在
            ValueError: 插件已存在或格式错误
        """
        from core.models import Plugin

        # 1. 读取 manifest
        manifest = cls._read_manifest(plugin_package_path)
        plugin_name = manifest['name']

        # 2. 检查是否已安装
        if Plugin.objects.filter(name=plugin_name).exists():
            raise ValueError(f'插件已安装: {plugin_name}')

        # 3. 生成唯一编号
        plugin_id = cls._generate_plugin_id(plugin_name)

        # 4. 确定安装路径并复制
        install_path = os.path.join(settings.PLUGINS_DIR, plugin_name)
        if os.path.exists(install_path):
            shutil.rmtree(install_path)
        shutil.copytree(plugin_package_path, install_path)

        # 5. 创建数据库记录（在执行钩子之前，保证记录存在）
        plugin_record = Plugin.objects.create(
            plugin_id=plugin_id,
            name=plugin_name,
            title=manifest.get('title', plugin_name),
            version=manifest.get('version', '1.0.0'),
            author=manifest.get('author', ''),
            description=manifest.get('description', ''),
            config=manifest.get('default_config', {}),
            config_schema=manifest.get('config_schema', {}),
            install_path=install_path,
            status='installed',
        )

        # 6. 加载插件类并实例化
        try:
            instance = cls._instantiate_plugin(install_path, manifest, plugin_id)
        except Exception as e:
            # 加载失败，回滚
            plugin_record.delete()
            if os.path.exists(install_path):
                shutil.rmtree(install_path)
            raise ValueError(f'插件加载失败: {e}')

        # 7. 执行安装钩子
        try:
            instance.on_install()
        except Exception as e:
            logger.error(f'插件安装钩子执行失败 [{plugin_id}]: {e}')
            # 不回滚，插件已记录，可能需要手动处理

        # 8. 注册插件标签
        cls._register_labels(plugin_id, instance)

        # 9. 注册插件模板
        cls._register_templates(plugin_id, instance, install_path)

        # 10. 缓存实例和元数据
        with cls._lock:
            cls._loaded_plugins[plugin_id] = instance
            cls._registry[plugin_id] = manifest

        logger.info(f'插件安装成功: [{plugin_id}] {plugin_record.title} v{plugin_record.version}')
        return plugin_record

    # ================================================================
    # 启用
    # ================================================================

    @classmethod
    def enable(cls, plugin_id: str) -> None:
        """
        启用插件

        Args:
            plugin_id: 插件编号

        Raises:
            Plugin.DoesNotExist: 插件不存在
        """
        from core.models import Plugin

        plugin_record = Plugin.objects.get(plugin_id=plugin_id)

        if plugin_record.status == 'enabled':
            logger.info(f'插件已处于启用状态: {plugin_id}')
            return

        # 加载实例（如果未加载）
        instance = cls._ensure_loaded(plugin_record)

        # 执行启用钩子
        try:
            instance.on_enable()
        except Exception as e:
            logger.error(f'插件启用钩子执行失败 [{plugin_id}]: {e}')
            raise

        # 更新状态
        plugin_record.status = 'enabled'
        plugin_record.save(update_fields=['status', 'updated_at'])

        logger.info(f'插件已启用: [{plugin_id}] {plugin_record.title}')

    # ================================================================
    # 停用
    # ================================================================

    @classmethod
    def disable(cls, plugin_id: str) -> None:
        """
        停用插件

        Args:
            plugin_id: 插件编号

        Raises:
            Plugin.DoesNotExist: 插件不存在
        """
        from core.models import Plugin

        plugin_record = Plugin.objects.get(plugin_id=plugin_id)

        if plugin_record.status == 'disabled':
            logger.info(f'插件已处于停用状态: {plugin_id}')
            return

        instance = cls._ensure_loaded(plugin_record)

        # 执行停用钩子
        try:
            instance.on_disable()
        except Exception as e:
            logger.error(f'插件停用钩子执行失败 [{plugin_id}]: {e}')
            raise

        plugin_record.status = 'disabled'
        plugin_record.save(update_fields=['status', 'updated_at'])

        logger.info(f'插件已停用: [{plugin_id}] {plugin_record.title}')

    # ================================================================
    # 卸载
    # ================================================================

    @classmethod
    def uninstall(cls, plugin_id: str) -> None:
        """
        卸载插件

        完整流程：停用 → 清理钩子 → 删除标签 → 删除模板 → 删除文件 → 删除记录

        Args:
            plugin_id: 插件编号
        """
        from core.models import Plugin, Label, Template

        plugin_record = Plugin.objects.get(plugin_id=plugin_id)

        # 如果已启用，先停用
        if plugin_record.status == 'enabled':
            cls.disable(plugin_id)

        instance = cls._ensure_loaded(plugin_record)

        # 执行卸载钩子
        try:
            instance.on_uninstall()
        except Exception as e:
            logger.error(f'插件卸载钩子执行失败 [{plugin_id}]: {e}')
            # 继续卸载，不中断

        # 清除插件注册的标签
        deleted_labels = Label.objects.filter(plugin_id=plugin_id).delete()[0]

        # 清除插件注册的模板
        deleted_templates = Template.objects.filter(plugin_id=plugin_id).delete()[0]

        # 删除插件文件
        install_path = plugin_record.install_path
        if os.path.exists(install_path):
            shutil.rmtree(install_path)

        # 从缓存移除
        with cls._lock:
            cls._loaded_plugins.pop(plugin_id, None)
            cls._registry.pop(plugin_id, None)

        # 删除数据库记录
        plugin_title = plugin_record.title
        plugin_record.delete()

        logger.info(
            f'插件已卸载: [{plugin_id}] {plugin_title} '
            f'(清理: {deleted_labels} 标签, {deleted_templates} 模板)'
        )

    # ================================================================
    # 调用插件 API
    # ================================================================

    @staticmethod
    def call_plugin_api(plugin_id: str, api_name: str, params: dict = None) -> Any:
        """
        调用插件 API（带沙盒监控）
        """
        try:
            plugin_record = Plugin.objects.get(plugin_id=plugin_id, status='enabled')
        except Plugin.DoesNotExist:
            raise ValueError(f'插件未安装或未启用: {plugin_id}')

        instance = PluginLoader._ensure_loaded(plugin_record)

        func = instance.get_api(api_name)
        if func is None:
            raise ValueError(f'插件 {plugin_id} 没有 API: {api_name}')

        # 获取插件沙盒配置
        from shared.sandbox import PluginSandbox
        sandbox_config = plugin_record.config or {}
        security_level = sandbox_config.get('sandbox', {}).get('security_level', 'moderate')

        sandbox = PluginSandbox(
            plugin_id=plugin_id,
            security_level=security_level,
            config=sandbox_config,
        )

        try:
            result = sandbox.execute(func, **(params or {}))
            return result
        except Exception as e:
            logger.error(f'插件 API 调用失败 [{plugin_id}.{api_name}]: {e}')
            raise

    # ================================================================
    # 查询
    # ================================================================

    @classmethod
    def get_loaded_plugins(cls) -> Dict[str, Any]:
        """获取所有已加载的插件实例"""
        with cls._lock:
            return dict(cls._loaded_plugins)

    @classmethod
    def is_loaded(cls, plugin_id: str) -> bool:
        """检查插件是否已加载到内存"""
        with cls._lock:
            return plugin_id in cls._loaded_plugins

    @classmethod
    def is_installed(cls, plugin_id: str) -> bool:
        """检查插件是否已安装（查数据库）"""
        from core.models import Plugin
        return Plugin.objects.filter(plugin_id=plugin_id).exists()

    # ================================================================
    # 内部方法
    # ================================================================

    @classmethod
    def _generate_plugin_id(cls, name: str) -> str:
        """
        生成唯一插件编号

        格式: PLG-YYYYMMDD-NNN
        """
        from core.models import Plugin

        today = datetime.now().strftime('%Y%m%d')
        prefix = f'PLG-{today}'

        # 查询当天已有的最大序号
        existing = Plugin.objects.filter(
            plugin_id__startswith=prefix
        ).values_list('plugin_id', flat=True)

        max_seq = 0
        for pid in existing:
            try:
                seq = int(pid.split('-')[-1])
                max_seq = max(max_seq, seq)
            except (ValueError, IndexError):
                continue

        return f'{prefix}-{max_seq + 1:03d}'

    @classmethod
    def _read_manifest(cls, path: str) -> dict:
        """
        读取插件 manifest.json

        Args:
            path: 插件目录路径

        Returns:
            manifest 字典

        Raises:
            FileNotFoundError: manifest.json 不存在
            ValueError: JSON 格式错误
        """
        manifest_path = os.path.join(path, 'manifest.json')

        if not os.path.exists(manifest_path):
            raise FileNotFoundError(f'插件目录中缺少 manifest.json: {path}')

        with open(manifest_path, 'r', encoding='utf-8') as f:
            try:
                manifest = json.load(f)
            except json.JSONDecodeError as e:
                raise ValueError(f'manifest.json 格式错误: {e}')

        # 必填字段校验
        required = ['name', 'entry_module', 'entry_class']
        missing = [f for f in required if not manifest.get(f)]
        if missing:
            raise ValueError(f'manifest.json 缺少必填字段: {", ".join(missing)}')

        return manifest

    @classmethod
    def _instantiate_plugin(cls, install_path: str, manifest: dict, plugin_id: str):
        """
        动态加载并实例化插件类

        Args:
            install_path: 插件安装目录
            manifest: manifest 字典
            plugin_id: 分配的插件编号

        Returns:
            插件实例
        """
        from core.api.plugin_bridge import PluginSystemAPI

        entry_module = manifest['entry_module']
        entry_class = manifest['entry_class']

        # 将插件目录加入 sys.path（临时）
        if install_path not in sys.path:
            sys.path.insert(0, install_path)

        # 动态导入
        try:
            module = importlib.import_module(entry_module)
        except ImportError as e:
            raise ValueError(f'无法导入插件模块 {entry_module}: {e}')

        # 获取插件类
        if not hasattr(module, entry_class):
            raise ValueError(f'插件模块 {entry_module} 中未找到类 {entry_class}')

        plugin_class = getattr(module, entry_class)

        # 实例化
        system_api = PluginSystemAPI()
        instance = plugin_class(plugin_id=plugin_id, system_api=system_api)

        return instance

    @classmethod
    def _ensure_loaded(cls, plugin_record) -> Any:
        """
        确保插件实例已加载到内存

        如果未加载（如 Django 重启后），重新加载。

        Args:
            plugin_record: Plugin 数据库实例

        Returns:
            插件实例
        """
        plugin_id = plugin_record.plugin_id

        with cls._lock:
            if plugin_id in cls._loaded_plugins:
                return cls._loaded_plugins[plugin_id]

        # 需要重新加载
        manifest = cls._read_manifest(plugin_record.install_path)
        instance = cls._instantiate_plugin(
            plugin_record.install_path, manifest, plugin_id
        )

        with cls._lock:
            cls._loaded_plugins[plugin_id] = instance
            cls._registry[plugin_id] = manifest

        logger.info(f'插件已重新加载: {plugin_id}')
        return instance

    @classmethod
    def _register_labels(cls, plugin_id: str, instance) -> None:
        """注册插件提供的标签到数据库"""
        from core.models import Label

        try:
            labels = instance.get_labels()
        except Exception as e:
            logger.warning(f'获取插件标签失败 [{plugin_id}]: {e}')
            return

        for label_data in (labels or []):
            try:
                Label.objects.update_or_create(
                    tag_code=label_data['tag_code'],
                    defaults={
                        'name': label_data.get('name', label_data['tag_code']),
                        'source_type': label_data.get('source_type', 'plugin_data'),
                        'source_config': label_data.get('source_config', {}),
                        'description': label_data.get('description', ''),
                        'plugin_id': plugin_id,
                        'is_system': False,
                    },
                )
                logger.debug(f'标签已注册: {label_data["tag_code"]}')
            except Exception as e:
                logger.error(f'标签注册失败 [{plugin_id}]: {e}')

    @classmethod
    def _register_templates(cls, plugin_id: str, instance, install_path: str) -> None:
        """注册插件提供的模板到数据库"""
        from core.models import Template

        try:
            templates = instance.get_templates()
        except Exception as e:
            logger.warning(f'获取插件模板失败 [{plugin_id}]: {e}')
            return

        for tpl_data in (templates or []):
            tpl_file = tpl_data.get('file', '')
            tpl_path = os.path.join(install_path, tpl_file)

            if not os.path.exists(tpl_path):
                logger.warning(f'插件模板文件不存在: {tpl_path}')
                continue

            try:
                with open(tpl_path, 'r', encoding='utf-8') as f:
                    content = f.read()

                Template.objects.update_or_create(
                    file_path=f'plugin/{plugin_id}/{tpl_file}',
                    defaults={
                        'name': tpl_data.get('name', tpl_file),
                        'content': content,
                        'template_type': 'plugin',
                        'plugin_id': plugin_id,
                        'is_system': False,
                    },
                )
                logger.debug(f'模板已注册: plugin/{plugin_id}/{tpl_file}')
            except Exception as e:
                logger.error(f'模板注册失败 [{plugin_id}]: {e}')
