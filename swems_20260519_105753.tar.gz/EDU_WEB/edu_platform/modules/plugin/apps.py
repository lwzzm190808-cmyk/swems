# modules/plugin/apps.py
from django.apps import AppConfig


class PluginConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'modules.plugin'
    verbose_name = '插件管理'

    def ready(self):
        """
        Django 启动时执行。

        只做注入（不查数据库），插件延迟加载。
        """
        try:
            self._register_resolvers()
        except Exception:
            pass  # 首次 migrate 前可能失败，忽略

    def _register_resolvers(self):
        """将 PluginLoader 的能力注入 core 层（纯内存操作，不查库）"""
        from modules.plugin.loader import PluginLoader
        from core.services.label_service import LabelService
        from core.api.plugin_bridge import PluginSystemAPI

        LabelService.set_plugin_api_resolver(PluginLoader.call_plugin_api)
        PluginSystemAPI.register_plugin_caller(PluginLoader.call_plugin_api)
