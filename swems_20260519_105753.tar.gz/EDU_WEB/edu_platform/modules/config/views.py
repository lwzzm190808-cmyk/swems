# modules/config/views.py
"""配置管理 API"""

import logging
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from core.services.config_service import ConfigService
from core.models import SystemConfig

logger = logging.getLogger(__name__)


class ConfigListView(APIView):
    """获取全部配置（按分组聚合）"""

    def get(self, request):
        groups = dict(SystemConfig.GROUP_CHOICES)
        result = {}

        for group_code, group_name in groups.items():
            configs = ConfigService.get_group(group_code)
            if configs:
                result[group_code] = {
                    'label': group_name,
                    'items': configs,
                }

        return Response({'data': result})


class ConfigGroupView(APIView):
    """按分组查看/更新配置"""

    def get(self, request, group):
        """获取某分组的全部配置"""
        configs = SystemConfig.objects.filter(group=group)
        if not configs.exists():
            return Response({'error': f'配置分组不存在: {group}'}, status=status.HTTP_404_NOT_FOUND)

        items = []
        for c in configs:
            items.append({
                'key': c.key,
                'value': '******' if c.is_encrypted else c.value,
                'description': c.description,
                'is_encrypted': c.is_encrypted,
                'updated_at': c.updated_at.strftime('%Y-%m-%d %H:%M:%S'),
            })

        return Response({'group': group, 'items': items})

    def put(self, request, group):
        """批量更新某分组的配置"""
        items = request.data.get('items', [])
        if not items:
            return Response({'error': 'items 不能为空'}, status=status.HTTP_400_BAD_REQUEST)

        updated_count = 0
        for item in items:
            key = item.get('key')
            value = item.get('value')
            if not key:
                continue

            ConfigService.set(
                group=group,
                key=key,
                value=value,
                description=item.get('description', ''),
                is_encrypted=item.get('is_encrypted', False),
            )
            updated_count += 1

        return Response({'message': f'已更新 {updated_count} 项配置'})


class ConfigDetailView(APIView):
    """单个配置项 CRUD"""

    def get(self, request, group, key):
        """获取单个配置"""
        result = ConfigService.get(group, key)
        if result is None:
            return Response({'error': '配置不存在'}, status=status.HTTP_404_NOT_FOUND)
        return Response({'group': group, 'key': key, 'value': result})

    def put(self, request, group, key):
        """创建/更新配置"""
        from core.services.log_service import LogService

        data = request.data
        config = ConfigService.set(
            group=group,
            key=key,
            value=data.get('value'),
            description=data.get('description', ''),
            is_encrypted=data.get('is_encrypted', False),
        )

        # 记录操作日志
        LogService.log(
            log_type='operation',
            level='info',
            module='config',
            action=f'更新配置: {group}.{key}',
            details={'group': group, 'key': key},
            user=request.user if request.user.is_authenticated else None,
            request=request,
        )

        return Response({'message': '保存成功'})

    def delete(self, request, group, key):
        """删除配置"""
        from core.services.log_service import LogService

        success = ConfigService.delete(group, key)
        if not success:
            return Response({'error': '配置不存在'}, status=status.HTTP_404_NOT_FOUND)

        LogService.log(
            log_type='operation',
            level='warning',
            module='config',
            action=f'删除配置: {group}.{key}',
            details={'group': group, 'key': key},
            user=request.user if request.user.is_authenticated else None,
            request=request,
        )

        return Response({'message': '删除成功'})
