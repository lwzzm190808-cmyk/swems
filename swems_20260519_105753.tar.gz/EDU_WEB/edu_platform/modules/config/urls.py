# modules/config/urls.py
"""配置管理路由"""

from django.urls import path
from . import views

app_name = 'config'

urlpatterns = [
    path('', views.ConfigListView.as_view(), name='list'),
    path('<str:group>/', views.ConfigGroupView.as_view(), name='group'),
    path('<str:group>/<str:key>/', views.ConfigDetailView.as_view(), name='detail'),
]
