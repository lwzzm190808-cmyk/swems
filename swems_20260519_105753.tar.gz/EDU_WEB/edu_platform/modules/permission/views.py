# modules/permission/views.py
"""权限管理 API"""

import logging
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from core.services.permission_service import PermissionService
from core.models import PermissionGroup, User

logger = logging.getLogger(__name__)


class GroupListCreateView(APIView):
    """权限组列表 / 创建"""

    def get(self, request):
        """获取全部权限组"""
        scope = request.query_params.get('scope')
        qs = PermissionGroup.objects.all()
        if scope:
            qs = qs.filter(scope=scope)

        groups = []
        for g in qs:
            groups.append({
                'id': g.id,
                'name': g.name,
                'scope': g.scope,
                'scope_display': g.get_scope_display(),
                'description': g.description,
                'permissions': g.permissions,
                'is_default': g.is_default,
                'user_count': g.users.count(),
                'created_at': g.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            })

        return Response({'data': groups, 'total': len(groups)})

    def post(self, request):
        """创建权限组"""
        data = request.data

        name = data.get('name', '').strip()
        scope = data.get('scope', '').strip()

        if not name or not scope:
            return Response(
                {'error': 'name 和 scope 为必填项'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        if scope not in ('admin', 'frontend'):
            return Response(
                {'error': 'scope 必须是 admin 或 frontend'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        group = PermissionService.create_group(
            name=name,
            scope=scope,
            permissions=data.get('permissions', {}),
            description=data.get('description', ''),
            is_default=data.get('is_default', False),
        )

        return Response(
            {'message': '创建成功', 'data': {'id': group.id, 'name': group.name}},
            status=status.HTTP_201_CREATED,
        )


class GroupDetailView(APIView):
    """权限组详情 / 更新 / 删除"""

    def get(self, request, pk):
        try:
            group = PermissionGroup.objects.get(id=pk)
        except PermissionGroup.DoesNotExist:
            return Response({'error': '权限组不存在'}, status=status.HTTP_404_NOT_FOUND)

        users = list(group.users.values('id', 'username', 'user_type'))
        return Response({
            'data': {
                'id': group.id,
                'name': group.name,
                'scope': group.scope,
                'description': group.description,
                'permissions': group.permissions,
                'is_default': group.is_default,
                'users': users,
            }
        })

    def put(self, request, pk):
        """更新权限组"""
        data = request.data
        group = PermissionService.update_group(pk, **data)
        if group is None:
            return Response({'error': '权限组不存在'}, status=status.HTTP_404_NOT_FOUND)
        return Response({'message': '更新成功'})

    def delete(self, request, pk):
        """删除权限组"""
        try:
            group = PermissionGroup.objects.get(id=pk)
            group.delete()
            PermissionService.clear_cache()
            return Response({'message': '删除成功'})
        except PermissionGroup.DoesNotExist:
            return Response({'error': '权限组不存在'}, status=status.HTTP_404_NOT_FOUND)


class GroupUsersView(APIView):
    """权限组成员管理"""

    def get(self, request, pk):
        """获取组内成员"""
        try:
            group = PermissionGroup.objects.get(id=pk)
        except PermissionGroup.DoesNotExist:
            return Response({'error': '权限组不存在'}, status=status.HTTP_404_NOT_FOUND)

        users = list(group.users.values('id', 'username', 'email', 'user_type'))
        return Response({'group': group.name, 'users': users, 'total': len(users)})

    def put(self, request, pk):
        """设置组成员（覆盖）"""
        user_ids = request.data.get('user_ids', [])
        if not isinstance(user_ids, list):
            return Response(
                {'error': 'user_ids 必须是列表'},
                status=status.HTTP_400_BAD_REQUEST,
            )

        group = PermissionService.set_group_users(pk, user_ids)
        if group is None:
            return Response({'error': '权限组不存在'}, status=status.HTTP_404_NOT_FOUND)

        return Response({'message': f'已设置 {len(user_ids)} 名成员'})

    def post(self, request, pk):
        """添加成员到组"""
        user_ids = request.data.get('user_ids', [])
        try:
            group = PermissionGroup.objects.get(id=pk)
        except PermissionGroup.DoesNotExist:
            return Response({'error': '权限组不存在'}, status=status.HTTP_404_NOT_FOUND)

        group.users.add(*user_ids)
        PermissionService.clear_cache()
        return Response({'message': f'已添加 {len(user_ids)} 名成员'})

    def delete(self, request, pk):
        """从组中移除成员"""
        user_ids = request.data.get('user_ids', [])
        try:
            group = PermissionGroup.objects.get(id=pk)
        except PermissionGroup.DoesNotExist:
            return Response({'error': '权限组不存在'}, status=status.HTTP_404_NOT_FOUND)

        group.users.remove(*user_ids)
        PermissionService.clear_cache()
        return Response({'message': f'已移除 {len(user_ids)} 名成员'})


class AdminPermissionView(APIView):
    """后台管理员权限查询"""

    def get(self, request):
        username = request.query_params.get('username')
        result = PermissionService.get_admin_permissions(username)
        return Response({'data': result})


class UserPermissionView(APIView):
    """前台用户权限查询"""

    def get(self, request):
        username = request.query_params.get('username', '')
        if not username:
            return Response(
                {'error': 'username 参数必填'},
                status=status.HTTP_400_BAD_REQUEST,
            )
        result = PermissionService.get_user_permissions(username)
        if 'error' in result:
            return Response(result, status=status.HTTP_404_NOT_FOUND)
        return Response({'data': result})
