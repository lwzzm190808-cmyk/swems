# modules/permission/apps.py
from django.apps import AppConfig


class PermissionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'modules.permission'
    verbose_name = '权限管理'

