# modules/permission/urls.py
"""权限管理路由"""

from django.urls import path
from . import views

app_name = 'permission'

urlpatterns = [
    path('groups/', views.GroupListCreateView.as_view(), name='group-list-create'),
    path('groups/<int:pk>/', views.GroupDetailView.as_view(), name='group-detail'),
    path('groups/<int:pk>/users/', views.GroupUsersView.as_view(), name='group-users'),
    path('admin/', views.AdminPermissionView.as_view(), name='admin-permission'),
    path('user/', views.UserPermissionView.as_view(), name='user-permission'),
]
