# modules/tag/apps.py
from django.apps import AppConfig


class TagConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'modules.tag'
    verbose_name = '标签管理'
# modules/tag/apps.py
from django.apps import AppConfig


class TagConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'modules.tag'
    verbose_name = '标签管理'
