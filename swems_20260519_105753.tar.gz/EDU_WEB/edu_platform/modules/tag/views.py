# modules/tag/views.py
"""标签管理 API"""

import logging
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from core.services.label_service import LabelService
from shared.security.validator import InputValidator
from core.models import Label

logger = logging.getLogger(__name__)


class LabelListCreateView(APIView):
    """标签列表 / 创建"""

    def get(self, request):
        """获取全部标签"""
        labels = LabelService.get_all_serialized()
        return Response({'data': labels, 'total': len(labels)})

    def post(self, request):
        """创建标签"""
        data = request.data

        # 校验
        tag_code = data.get('tag_code', '')
        is_valid, error = InputValidator.validate_tag_code(tag_code)
        if not is_valid:
            return Response({'error': error}, status=status.HTTP_400_BAD_REQUEST)

        required = ['name', 'tag_code', 'source_type']
        for field in required:
            if not data.get(field):
                return Response(
                    {'error': f'缺少必填字段: {field}'},
                    status=status.HTTP_400_BAD_REQUEST,
                )

        try:
            label = LabelService.create(
                name=data['name'],
                tag_code=data['tag_code'],
                source_type=data['source_type'],
                source_config=data.get('source_config', {}),
                description=data.get('description', ''),
                is_system=data.get('is_system', True),
                plugin_id=data.get('plugin_id'),
            )
            return Response(
                {'message': '创建成功', 'data': {'id': label.id, 'tag_code': label.tag_code}},
                status=status.HTTP_201_CREATED,
            )
        except ValueError as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logger.error(f'创建标签失败: {e}')
            return Response({'error': '创建失败'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class LabelDetailView(APIView):
    """标签详情 / 更新 / 删除"""

    def get(self, request, pk):
        """获取单个标签"""
        label = LabelService.get_by_code(str(pk))
        if label is None:
            from core.models import Label
            try:
                label = Label.objects.get(id=pk)
            except Label.DoesNotExist:
                return Response({'error': '标签不存在'}, status=status.HTTP_404_NOT_FOUND)

        return Response({
            'data': {
                'id': label.id,
                'name': label.name,
                'tag_code': label.tag_code,
                'source_type': label.source_type,
                'source_config': label.source_config,
                'description': label.description,
                'is_system': label.is_system,
                'plugin_id': label.plugin_id,
            }
        })

    def put(self, request, pk):
        """更新标签"""
        data = request.data

        if 'tag_code' in data:
            is_valid, error = InputValidator.validate_tag_code(data['tag_code'])
            if not is_valid:
                return Response({'error': error}, status=status.HTTP_400_BAD_REQUEST)

        label = LabelService.update(pk, **data)
        if label is None:
            return Response({'error': '标签不存在'}, status=status.HTTP_404_NOT_FOUND)

        return Response({'message': '更新成功'})

    def delete(self, request, pk):
        """删除标签"""
        success = LabelService.delete(pk)
        if not success:
            return Response({'error': '标签不存在'}, status=status.HTTP_404_NOT_FOUND)
        return Response({'message': '删除成功'})


class LabelResolveView(APIView):
    """标签解析（预览标签数据）"""

    def get(self, request, pk):
        """解析标签，返回实际数据"""
        from core.models import Label
        try:
            label = Label.objects.get(id=pk)
        except Label.DoesNotExist:
            return Response({'error': '标签不存在'}, status=status.HTTP_404_NOT_FOUND)

        # 清除缓存，确保预览的是最新数据
        LabelService.clear_cache()
        data = LabelService.resolve(label.tag_code)
        return Response({'tag_code': label.tag_code, 'data': data})

class TagParseView(APIView):
    """标签解析测试"""

    def post(self, request):
        tag_code = request.data.get('tag_code', '').strip()
        if not tag_code:
            return Response({'error': '请输入标签编码'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            label = Label.objects.get(tag_code=tag_code)
        except Label.DoesNotExist:
            return Response({'error': f'标签不存在: {tag_code}'}, status=status.HTTP_404_NOT_FOUND)

        try:
            source_type = label.source_type
            config = label.source_config or {}

            if source_type == 'model_field':
                result = self._resolve_model(config)
            elif source_type == 'custom_query':
                result = self._resolve_sql(config)
            elif source_type == 'plugin_data':
                result = self._resolve_plugin(config)
            else:
                return Response({'error': f'不支持的数据源: {source_type}'}, status=status.HTTP_400_BAD_REQUEST)

            return Response({
                'tag_code': tag_code,
                'source_type': source_type,
                'result': result,
            })
        except Exception as e:
            logger.error(f'标签解析失败 [{tag_code}]: {e}')
            return Response({'error': f'解析失败: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def _resolve_model(self, config):
        from django.apps import apps

        model_path = config.get('model', '')
        if '.' not in model_path:
            raise ValueError(f'模型路径格式错误: {model_path}')

        app_label, model_name = model_path.rsplit('.', 1)

        try:
            model = apps.get_model(app_label, model_name)
        except LookupError:
            raise ValueError(f'模型不存在: {model_path}')

        qs = model.objects.all()

        filters = config.get('filter', {})
        if filters:
            qs = qs.filter(**filters)

        if config.get('count'):
            return qs.count()

        field = config.get('field', 'pk')
        obj = qs.first()
        return getattr(obj, field, None) if obj else None

    def _resolve_sql(self, config):
        from django.db import connection

        sql = config.get('sql', '')
        if not sql:
            raise ValueError('SQL 查询为空')

        if not sql.strip().upper().startswith('SELECT'):
            raise ValueError('仅允许 SELECT 查询')

        with connection.cursor() as cursor:
            cursor.execute(sql)
            row = cursor.fetchone()
            if row is None:
                return None
            return row[0] if len(row) == 1 else list(row)

    def _resolve_plugin(self, config):
        from modules.plugin.loader import PluginLoader

        plugin_id = config.get('plugin_id', '')
        api_name = config.get('api', '')
        params = config.get('params', {})

        if not plugin_id or not api_name:
            raise ValueError('plugin_id 或 api 未配置')

        return PluginLoader.call_plugin_api(plugin_id, api_name, params)
