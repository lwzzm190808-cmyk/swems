# modules/tag/urls.py
"""标签管理路由"""

from django.urls import path
from . import views

app_name = 'tag'

urlpatterns = [
    path('', views.LabelListCreateView.as_view(), name='list-create'),
    path('parse/', views.TagParseView.as_view()),
    path('<int:pk>/', views.LabelDetailView.as_view(), name='detail'),
    path('<int:pk>/resolve/', views.LabelResolveView.as_view(), name='resolve'),
]