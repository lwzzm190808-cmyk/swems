# admin_panel/context_processors.py
"""后台模板上下文处理器"""


def admin_context(request):
    """为后台模板提供插件侧边栏等上下文数据"""
    if not request.path.startswith('/admin-panel/'):
        return {}

    if not hasattr(request, 'user') or not request.user.is_authenticated:
        return {}

    from core.models import Plugin
    from modules.plugin.loader import PluginLoader

    plugin_sidebar_items = []

    try:
        enabled_plugins = Plugin.objects.filter(status='enabled')
        for plugin_record in enabled_plugins:
            try:
                instance = PluginLoader._ensure_loaded(plugin_record)
                items = instance.sidebar_items
                if items:
                    for item in items:
                        item.setdefault('icon', '◆')
                    plugin_sidebar_items.extend(items)
            except Exception:
                continue
    except Exception:
        pass

    return {
        'plugin_sidebar_items': plugin_sidebar_items,
    }
