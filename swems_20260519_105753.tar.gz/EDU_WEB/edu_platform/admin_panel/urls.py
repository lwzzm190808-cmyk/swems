
from django.urls import path
from . import views

app_name = 'admin_panel'

urlpatterns = [
    # 认证
    path('login/',  views.AdminLoginView.as_view(),  name='login'),
    path('logout/', views.AdminLogoutView.as_view(), name='logout'),

    # 网站信息
    path('', views.AdminDashboardView.as_view(), name='dashboard'),

    # 管理模块
    path('users/',       views.AdminUsersView.as_view(),       name='users'),
    path('tags/',        views.AdminTagsView.as_view(),        name='tags'),
    path('templates/',   views.AdminTemplatesView.as_view(),   name='templates'),
    path('config/',      views.AdminConfigView.as_view(),      name='config'),
    path('permissions/', views.AdminPermissionsView.as_view(), name='permissions'),
    path('plugins/',     views.AdminPluginsView.as_view(),     name='plugins'),
    path('logs/',        views.AdminLogsView.as_view(),        name='logs'),

    # 个人资料
    path('profile/',     views.AdminProfileView.as_view(),     name='profile'),

    # 系统设置
    path('settings/',    views.AdminSettingsView.as_view(),    name='settings'),
    path('site-update/', views.AdminSiteUpdateView.as_view(), name='site-update'),

    # 插件开发文档
    path('plugin-docs/', views.AdminPluginDocsView.as_view(), name='plugin_docs'),

    # 插件沙盒
    path('sandbox/', views.AdminSandboxView.as_view(), name='sandbox'),

    # 插件权限审批
    path('plugin-permissions/', views.AdminPluginPermissionsView.as_view(), name='plugin_permissions'),

    # 日志详情
    path('log/<int:pk>/', views.AdminLogDetailView.as_view(), name='log-detail'),

    # 模板
    path('template/<int:pk>/preview/', views.AdminTemplatePreviewView.as_view(), name='template-preview'),
    path('template/<int:pk>/content/', views.AdminTemplateContentView.as_view(), name='template-content'),
]
