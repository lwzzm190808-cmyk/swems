# admin_panel/views.py
"""
后台管理面板视图

独立于 Django 内置 Admin，是项目的自定义后台。
所有视图通过 AdminAccessMixin 检查后台访问权限。
"""

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse, JsonResponse
from django.views import View
from django.views.decorators.clickjacking import xframe_options_exempt
from django.utils.decorators import method_decorator
import json as _json

from core.models import (
    User, PermissionGroup, Label, Template,
    SystemConfig, Plugin, OperationLog,
)
from core.services.log_service import LogService


# ============================================================
# 权限检查 Mixin
# ============================================================

class AdminAccessMixin:
    """后台访问权限检查"""

    def dispatch(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect('/admin-panel/login/')
        if not self._has_admin_access(request.user):
            return redirect('/admin-panel/login/?error=no_permission')
        return super().dispatch(request, *args, **kwargs)

    @staticmethod
    def _has_admin_access(user):
        """
        判断用户是否有后台管理权限

        - superuser → 有权限
        - user_type='admin' → 有权限
        - user_type='frontend' + 属于 admin 权限组 → 有权限
        """
        if user.is_superuser or user.user_type == 'admin':
            return True
        return user.permission_groups.filter(scope='admin').exists()


# ============================================================
# 登录 / 登出
# ============================================================
class AdminLoginView(View):
    """后台登录"""

    def get(self, request):
        # 已登录的 admin 用户直接跳转
        if request.user.is_authenticated and self._can_access_admin(request.user):
            return redirect('/admin-panel/')
        return render(request, 'admin/login.html')

    def post(self, request):
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')

        if not username or not password:
            return render(request, 'admin/login.html', {'error': '请输入用户名和密码'})

        user = authenticate(request, username=username, password=password)

        # 统一错误信息，不暴露账号类型
        if user is None or not user.is_active:
            return render(request, 'admin/login.html', {'error': '账号或密码错误'})

        # 必须是后台用户
        if not self._can_access_admin(user):
            return render(request, 'admin/login.html', {'error': '账号或密码错误'})

        login(request, user)
        return redirect('/admin-panel/')

    def _can_access_admin(self, user):
        if user.is_superuser:
            return True
        if user.user_type == 'admin':
            return True
        if user.permission_groups.filter(scope='admin').exists():
            return True
        return False

class AdminLogoutView(View):
    """后台登出"""

    def get(self, request):
        logout(request)
        return redirect('/admin-panel/login/')

    def post(self, request):
        logout(request)
        return redirect('/admin-panel/login/')


# ============================================================
# 仪表盘
# ============================================================
class AdminDashboardView(AdminAccessMixin, View):
    """网站信息"""

    def get(self, request):
        from core.services.config_service import ConfigService

        context = {
            'active_section': 'dashboard',
            'site_info': {
                'name': ConfigService.get('site', 'site_name') or 'SWEMS',
                'slogan': ConfigService.get('site', 'site_slogan') or '',
                'copyright': ConfigService.get('site', 'copyright') or '',
                'domain': ConfigService.get('site', 'domain') or 'localhost',
            },
            'stats': {
                'total_users': User.objects.count(),
                'admin_users': User.objects.filter(user_type='admin').count(),
                'frontend_users': User.objects.filter(user_type='frontend').count(),
                'active_plugins': Plugin.objects.filter(status='enabled').count(),
                'total_plugins': Plugin.objects.count(),
                'total_labels': Label.objects.count(),
                'total_templates': Template.objects.count(),
                'total_groups': PermissionGroup.objects.count(),
            },
            'server_status': LogService.get_server_status(),
            'recent_logs': LogService.query(limit=5),
        }
        return render(request, 'admin/site_info.html', context)


class AdminPluginDocsView(AdminAccessMixin, View):
    """插件开发文档 — 动态生成"""

    def get(self, request):
        from modules.plugin.loader import PluginLoader

        # 加载所有已启用的插件，获取其 API 文档
        plugins_docs = []
        enabled_plugins = Plugin.objects.filter(status='enabled')

        for plugin_record in enabled_plugins:
            try:
                instance = PluginLoader._ensure_loaded(plugin_record)
                api_docs = instance.get_api_docs() if hasattr(instance, 'get_api_docs') else {}
                labels_docs = instance.get_labels_docs() if hasattr(instance, 'get_labels_docs') else []
                api_names = list(api_docs.keys()) if api_docs else instance.get_api_names() if hasattr(instance, 'get_api_names') else []
            except Exception:
                api_docs = {}
                labels_docs = []
                api_names = []

            plugins_docs.append({
                'plugin_id': plugin_record.plugin_id,
                'title': plugin_record.title,
                'name': plugin_record.name,
                'version': plugin_record.version,
                'description': plugin_record.description,
                'api_docs': api_docs,
                'api_names': api_names,
                'labels_docs': labels_docs,
                'config_schema': plugin_record.config_schema,
                'config': plugin_record.config,
            })

        # 已安装但未启用的插件（只显示基本信息）
        disabled_plugins = Plugin.objects.exclude(status='enabled')

        context = {
            'active_section': 'plugin_docs',
            'plugins_docs': plugins_docs,
            'disabled_plugins': disabled_plugins,
            'system_api_list': [
                {'name': 'GetSystemoption', 'params': '配置项名称', 'returns': '配置数据 JSON'},
                {'name': 'GetSystemLog', 'params': '日志类型', 'returns': '日志列表'},
                {'name': 'GetSystemPlugins', 'params': '插件状态', 'returns': '插件集合 JSON'},
                {'name': 'GetSystemLabels', 'params': '无', 'returns': '标签集合 JSON'},
                {'name': 'GetSystemTemplate', 'params': '无', 'returns': '模板集合 JSON'},
                {'name': 'GetSystemPermission', 'params': '用户名(可选)', 'returns': '后台权限信息'},
                {'name': 'GetUserPermission', 'params': '用户名', 'returns': '前台权限信息'},
                {'name': 'UsePluginAPI', 'params': '插件ID, API名, 参数', 'returns': '插件API返回值'},
            ],
        }
        return render(request, 'admin/plugin_docs.html', context)


# ============================================================
# 用户管理
# ============================================================
class AdminUsersView(AdminAccessMixin, View):
    """用户管理 — 增删改查"""

    def get(self, request):
        from django.core.paginator import Paginator
        from django.db.models import Q

        filter_type = request.GET.get('type', '')
        search_query = request.GET.get('q', '')

        qs = User.objects.all().order_by('-date_joined')

        if filter_type:
            qs = qs.filter(user_type=filter_type)
        if search_query:
            qs = qs.filter(Q(username__icontains=search_query) | Q(email__icontains=search_query))

        paginator = Paginator(qs, 20)
        page_obj = paginator.get_page(request.GET.get('page', 1))

        groups = PermissionGroup.objects.all().order_by('scope', 'name')

        return render(request, 'admin/users.html', {
            'active_section': 'users',
            'users_page': page_obj,
            'permission_groups': groups,
            'filter_type': filter_type,
            'search_query': search_query,
        })

    def post(self, request):
        """创建用户"""
        action = request.POST.get('action', '')

        if action == 'create':
            username = request.POST.get('username', '').strip()
            email = request.POST.get('email', '').strip()
            password = request.POST.get('password', '')
            user_type = request.POST.get('user_type', 'frontend')
            is_superuser = request.POST.get('is_superuser') == 'on'
            group_ids = request.POST.getlist('permission_groups')

            if not username or not password:
                return redirect('/admin-panel/users/?error=用户名和密码不能为空')
            if User.objects.filter(username=username).exists():
                return redirect('/admin-panel/users/?error=用户名已存在')
            if len(password) < 8:
                return redirect('/admin-panel/users/?error=密码长度至少8位')

            user = User.objects.create_user(
                username=username,
                email=email,
                password=password,
                user_type=user_type,
                is_superuser=is_superuser,
            )

            for gid in group_ids:
                try:
                    group = PermissionGroup.objects.get(id=gid)
                    group.users.add(user)
                except PermissionGroup.DoesNotExist:
                    pass

            OperationLog.objects.create(
                log_type='operation', level='info',
                module='users',
                action=f'创建用户: {username} ({user_type})',
                user=request.user,
                ip_address=request.META.get('REMOTE_ADDR', ''),
            )

        elif action == 'update':
            user_id = request.POST.get('user_id')
            try:
                user = User.objects.get(id=user_id)
            except User.DoesNotExist:
                return redirect('/admin-panel/users/?error=用户不存在')

            user.email = request.POST.get('email', user.email).strip()
            user_type = request.POST.get('user_type', '')
            if user_type:
                user.user_type = user_type
            user.is_active = request.POST.get('is_active') == 'on'
            user.is_superuser = request.POST.get('is_superuser') == 'on'
            user.save()

            # 更新权限组
            group_ids = request.POST.getlist('permission_groups')
            user.permission_groups.clear()
            for gid in group_ids:
                try:
                    group = PermissionGroup.objects.get(id=gid)
                    group.users.add(user)
                except PermissionGroup.DoesNotExist:
                    pass

            # 重置密码（可选）
            new_password = request.POST.get('new_password', '').strip()
            if new_password:
                if len(new_password) < 8:
                    return redirect('/admin-panel/users/?error=新密码长度至少8位')
                user.set_password(new_password)
                user.save()

            OperationLog.objects.create(
                log_type='operation', level='info',
                module='users',
                action=f'更新用户: {user.username}',
                user=request.user,
                ip_address=request.META.get('REMOTE_ADDR', ''),
            )

        elif action == 'delete':
            user_id = request.POST.get('user_id')
            try:
                user = User.objects.get(id=user_id)
            except User.DoesNotExist:
                return redirect('/admin-panel/users/?error=用户不存在')

            if user.is_superuser and User.objects.filter(is_superuser=True).count() <= 1:
                return redirect('/admin-panel/users/?error=不能删除最后一个超级管理员')

            username = user.username
            user.delete()

            OperationLog.objects.create(
                log_type='operation', level='warning',
                module='users',
                action=f'删除用户: {username}',
                user=request.user,
                ip_address=request.META.get('REMOTE_ADDR', ''),
            )

        return redirect('/admin-panel/users/')

# ============================================================
# 标签管理
# ============================================================

class AdminTagsView(AdminAccessMixin, View):
    """标签管理"""

    def get(self, request):
        labels = Label.objects.all().order_by('name')
        return render(request, 'admin/tags.html', {
            'active_section': 'tags',
            'labels': labels,
            'source_type_choices': dict(Label.SOURCE_TYPE_CHOICES),
        })


# ============================================================
# 模板管理
# ============================================================
class AdminTemplatesView(AdminAccessMixin, View):
    """模板管理"""

    def get(self, request):
        templates = Template.objects.all().order_by('file_path')
        context = {
            'active_section': 'templates',
            'templates': templates,
        }
        return render(request, 'admin/templates_manage.html', context)

    def post(self, request):
        """上传模板文件"""
        file = request.FILES.get('file')
        if not file:
            return HttpResponse('请选择文件', status=400)

        if not file.name.endswith(('.html', '.htm')):
            return HttpResponse('仅支持 HTML 文件', status=400)

        from django.conf import settings
        filepath = settings.CMS_TEMPLATE_DIR / file.name
        filepath.parent.mkdir(parents=True, exist_ok=True)

        content = file.read().decode('utf-8')
        filepath.write_text(content, encoding='utf-8')

        file_path = f'templates/{file.name}'
        name = file.name.replace('.html', '').replace('.htm', '')

        tpl, created = Template.objects.update_or_create(
            file_path=file_path,
            defaults={
                'name': name,
                'content': content,
                'template_type': 'page',
                'is_system': False,
            },
        )

        LogService.log_operation(
            user=request.user, module='template',
            action=f'上传模板: {tpl.file_path}',
            ip_address=request.META.get('REMOTE_ADDR', ''),
        )


# ============================================================
# 配置管理
# ============================================================

class AdminConfigView(AdminAccessMixin, View):
    """自定义配置管理"""

    def get(self, request):
        configs = SystemConfig.objects.filter(group='custom').order_by('key')
        context = {
            'active_section': 'config',
            'grouped_configs': {'custom': configs},
        }
        return render(request, 'admin/config.html', context)

    def post(self, request):
        """创建新自定义配置"""
        key = request.POST.get('key', '').strip()
        value = request.POST.get('value', '').strip()
        description = request.POST.get('description', '').strip()

        if not key:
            return redirect('/admin-panel/config/')

        if not SystemConfig.objects.filter(group='custom', key=key).exists():
            SystemConfig.objects.create(
                group='custom', key=key, value=value, description=description,
            )
            LogService.log_operation(
                user=request.user, module='config',
                action=f'创建自定义配置: custom.{key}',
                ip_address=request.META.get('REMOTE_ADDR', ''),
            )
# admin_panel/views.py — 替换 AdminConfigView

class AdminConfigView(AdminAccessMixin, View):
    """自定义配置管理"""

    def get(self, request):
        configs = SystemConfig.objects.filter(group='custom').order_by('key')
        context = {
            'active_section': 'config',
            'grouped_configs': {'custom': configs},
        }
        return render(request, 'admin/config.html', context)

    def post(self, request):
        """创建新自定义配置"""
        key = request.POST.get('key', '').strip()
        value = request.POST.get('value', '').strip()
        description = request.POST.get('description', '').strip()

        if not key:
            return redirect('/admin-panel/config/')

        if not SystemConfig.objects.filter(group='custom', key=key).exists():
            SystemConfig.objects.create(
                group='custom', key=key, value=value, description=description,
            )
            LogService.log_operation(
                user=request.user, module='config',
                action=f'创建自定义配置: custom.{key}',
                ip_address=request.META.get('REMOTE_ADDR', ''),
            )


# ============================================================
# 权限管理
# ============================================================

class AdminPermissionsView(AdminAccessMixin, View):
    """权限管理"""

    # 核心模块（静态）
    CORE_MODULES = {
        'users': {'name': '用户管理', 'actions': ['use', 'modify', 'delete']},
        'tag': {'name': '标签管理', 'actions': ['use', 'modify', 'delete']},
        'template': {'name': '模板管理', 'actions': ['use', 'modify', 'delete']},
        'config': {'name': '配置管理', 'actions': ['use', 'modify', 'delete']},
        'permission': {'name': '权限管理', 'actions': ['use', 'modify', 'delete']},
        'log': {'name': '日志管理', 'actions': ['use', 'delete']},
    }

    def get_available_modules(self):
        """动态生成可用模块列表（核心 + 已安装插件）"""
        modules = {}

        # 核心模块
        for code, info in self.CORE_MODULES.items():
            modules[code] = {
                'name': info['name'],
                'actions': info['actions'],
                'is_plugin': False,
            }

        # 插件模块（动态）
        installed_plugins = Plugin.objects.all().order_by('plugin_id')
        for plugin in installed_plugins:
            code = f'plugin:{plugin.plugin_id}'
            modules[code] = {
                'name': plugin.title or plugin.plugin_id,
                'actions': ['execute'],
                'is_plugin': True,
                'plugin_id': plugin.plugin_id,
                'plugin_status': plugin.status,
            }

        return modules

    def get(self, request):
        import json as _json

        groups = PermissionGroup.objects.all().order_by('scope', 'name')
        available_modules = self.get_available_modules()

        for group in groups:
            group.permissions_json = _json.dumps(
                group.permissions or {}, ensure_ascii=False
            )
            # 标记系统权限组
            if not hasattr(group, 'is_system') or group.is_system is None:
                group.is_system = False

        return render(request, 'admin/permissions.html', {
            'active_section': 'permissions',
            'groups': groups,
            'available_modules': available_modules,
        })

    def post(self, request):
        action = request.POST.get('action', '')
        available_modules = self.get_available_modules()

        if action == 'create':
            name = request.POST.get('name', '').strip()
            scope = request.POST.get('scope', 'admin')
            description = request.POST.get('description', '').strip()
            is_default = request.POST.get('is_default') == 'on'

            permissions = {}
            for mod_code, mod_info in available_modules.items():
                if request.POST.get(f'module_{mod_code}'):
                    perms = {}
                    for act in mod_info['actions']:
                        perms[act] = request.POST.get(f'perm_{mod_code}_{act}') == 'on'
                    permissions[mod_code] = perms

            if name:
                PermissionGroup.objects.create(
                    name=name, scope=scope, description=description,
                    is_default=is_default, is_system=False,
                    permissions=permissions,
                )

        elif action == 'update':
            group_id = request.POST.get('group_id')
            try:
                group = PermissionGroup.objects.get(id=group_id)
            except PermissionGroup.DoesNotExist:
                return redirect('/admin-panel/permissions/')

            group.name = request.POST.get('name', group.name).strip()
            group.description = request.POST.get('description', '').strip()

            permissions = {}
            for mod_code, mod_info in available_modules.items():
                if request.POST.get(f'module_{mod_code}'):
                    perms = {}
                    for act in mod_info['actions']:
                        perms[act] = request.POST.get(f'perm_{mod_code}_{act}') == 'on'
                    permissions[mod_code] = perms

            group.permissions = permissions
            group.save()

        elif action == 'delete':
            group_id = request.POST.get('group_id')
            try:
                group = PermissionGroup.objects.get(id=group_id)
                if group.is_system:
                    return redirect('/admin-panel/permissions/')
                group.delete()
            except PermissionGroup.DoesNotExist:
                pass

        return redirect('/admin-panel/permissions/')

# ============================================================
# 插件管理
# ============================================================

class AdminPluginsView(AdminAccessMixin, View):
    """插件管理"""

    def get(self, request):
        plugins = Plugin.objects.all().order_by('-installed_at')
        return render(request, 'admin/plugins.html', {
            'active_section': 'plugins',
            'plugins': plugins,
            'status_choices': dict(Plugin.STATUS_CHOICES),
        })


# ============================================================
# 日志管理
# ============================================================

class AdminLogsView(AdminAccessMixin, View):
    """日志管理"""

    def get(self, request):
        from django.core.paginator import Paginator
        from django.db.models import Count, Q
        from django.utils import timezone

        filter_type = request.GET.get('type', '')
        filter_level = request.GET.get('level', '')
        search_query = request.GET.get('q', '')

        qs = OperationLog.objects.select_related('user').order_by('-created_at')

        if filter_type:
            qs = qs.filter(log_type=filter_type)
        if filter_level:
            qs = qs.filter(level=filter_level)
        if search_query:
            qs = qs.filter(
                Q(action__icontains=search_query) |
                Q(module__icontains=search_query)
            )

        paginator = Paginator(qs, 30)
        page_obj = paginator.get_page(request.GET.get('page', 1))

        # 统计
        all_logs = OperationLog.objects.all()
        level_stats = list(
            all_logs.values('level').annotate(count=Count('id')).order_by('-count')
        )
        module_stats = list(
            all_logs.values('module').annotate(count=Count('id')).order_by('-count')[:10]
        )
        level_stats_total = sum(s['count'] for s in level_stats)
        today_logs_count = all_logs.filter(created_at__date=timezone.now().date()).count()

        context = {
            'active_section': 'logs',
            'logs': page_obj,
            'server_status': LogService.get_server_status(),
            'level_stats': level_stats,
            'module_stats': module_stats,
            'level_stats_total': level_stats_total,
            'today_logs_count': today_logs_count,
            'filter_type': filter_type,
            'filter_level': filter_level,
            'search_query': search_query,
        }
        return render(request, 'admin/logs.html', context)


class AdminLogDetailView(AdminAccessMixin, View):
    """单条日志详情"""

    def get(self, request, pk):
        try:
            log = OperationLog.objects.select_related('user').get(id=pk)
        except OperationLog.DoesNotExist:
            return JsonResponse({'error': '日志不存在'}, status=404)

        details = {}
        if log.detail:
            try:
                details = _json.loads(log.detail)
            except (ValueError, TypeError):
                details = {'raw': log.detail}

        return JsonResponse({
            'id': log.id,
            'log_type': log.log_type,
            'level': log.level,
            'module': log.module,
            'action': log.action,
            'user': {'username': log.user.username} if log.user else None,
            'ip_address': log.ip_address,
            'details': details,
            'created_at': log.created_at.strftime('%Y-%m-%d %H:%M:%S'),
        })



class AdminProfileView(AdminAccessMixin, View):
    """个人资料"""

    def get(self, request):
        context = {
            'active_section': 'profile',
            'profile_user': request.user,
        }
        return render(request, 'admin/profile.html', context)

    def post(self, request):
        from django.contrib.auth import update_session_auth_hash

        user = request.user
        action = request.POST.get('action', '')

        if action == 'update_info':
            email = request.POST.get('email', '').strip()
            user.email = email
            user.save()
            LogService.log_operation(
                user=user, module='user',
                action='更新个人信息',
                ip_address=request.META.get('REMOTE_ADDR', ''),
            )
            return render(request, 'admin/profile.html', {
                'active_section': 'profile',
                'profile_user': user,
                'success': '信息已更新',
            })

        elif action == 'change_password':
            old_pw = request.POST.get('old_password', '')
            new_pw = request.POST.get('new_password', '')
            confirm_pw = request.POST.get('confirm_password', '')

            if not user.check_password(old_pw):
                return render(request, 'admin/profile.html', {
                    'active_section': 'profile',
                    'profile_user': user,
                    'error': '当前密码错误',
                })
            if new_pw != confirm_pw:
                return render(request, 'admin/profile.html', {
                    'active_section': 'profile',
                    'profile_user': user,
                    'error': '两次输入的密码不一致',
                })
            if len(new_pw) < 8:
                return render(request, 'admin/profile.html', {
                    'active_section': 'profile',
                    'profile_user': user,
                    'error': '密码长度至少 8 位',
                })

            user.set_password(new_pw)
            user.save()
            update_session_auth_hash(request, user)

            LogService.log_security(
                user=user, action='修改登录密码',
                ip_address=request.META.get('REMOTE_ADDR', ''),
            )
            return render(request, 'admin/profile.html', {
                'active_section': 'profile',
                'profile_user': user,
                'success': '密码已修改',
            })

        return redirect('/admin-panel/profile/')

class AdminSettingsView(AdminAccessMixin, View):
    """系统设置 — MySQL/Redis/站点等核心配置"""

    def get(self, request):
        from core.services.config_service import ConfigService

        context = {
            'active_section': 'settings',
            'groups': ['database', 'redis', 'site', 'backup', 'email'],
            'grouped_configs': {},
        }

        for group in context['groups']:
            configs = SystemConfig.objects.filter(group=group).order_by('key')
            context['grouped_configs'][group] = list(configs.values(
                'id', 'group', 'key', 'value', 'description', 'is_encrypted', 'updated_at'
            ))

        return render(request, 'admin/settings.html', context)

class AdminSiteUpdateView(AdminAccessMixin, View):
    """站点更新 — 扫描模板 + 清除缓存"""

    def post(self, request):
        from django.conf import settings
        from django.core.cache import cache

        template_dir = settings.CMS_TEMPLATE_DIR
        created = 0
        updated = 0

        if template_dir.exists():
            for filepath in template_dir.rglob('*.html'):
                relative = filepath.relative_to(settings.BASE_DIR)
                file_path = str(relative).replace('\\', '/')
                content = filepath.read_text(encoding='utf-8')
                name = filepath.stem

                _, is_created = Template.objects.update_or_create(
                    file_path=file_path,
                    defaults={
                        'name': name,
                        'content': content,
                        'template_type': 'page',
                        'is_system': True,
                    },
                )
                if is_created:
                    created += 1
                else:
                    updated += 1

        cache.clear()

        LogService.log_operation(
            user=request.user, module='system',
            action=f'站点更新: 模板扫描({created}新增/{updated}更新), 缓存已清除',
            ip_address=request.META.get('REMOTE_ADDR', ''),
        )
        return redirect('/admin-panel/settings/?updated=1')


class AdminSandboxView(AdminAccessMixin, View):
    """插件沙盒监控"""

    def get(self, request):
        from django.db.models import Q

        sandbox_logs = OperationLog.objects.filter(
            Q(module='sandbox') | Q(module='plugin_install')
        ).order_by('-created_at')[:100]

        plugin_summaries = {}
        for log in sandbox_logs:
            details = {}
            if log.detail:
                try:
                    details = _json.loads(log.detail)
                except (ValueError, TypeError):
                    details = {}

            pid = details.get('plugin_id', log.module)
            if pid not in plugin_summaries:
                plugin_summaries[pid] = {
                    'plugin_id': pid,
                    'total_sessions': 0,
                    'violations': 0,
                    'total_network': 0,
                    'total_queries': 0,
                    'last_activity': None,
                }
            plugin_summaries[pid]['total_sessions'] += 1
            if details.get('violations'):
                plugin_summaries[pid]['violations'] += len(details['violations'])
            plugin_summaries[pid]['total_network'] += details.get('network', {}).get('total', 0)
            plugin_summaries[pid]['total_queries'] += details.get('database', {}).get('total', 0)
            if not plugin_summaries[pid]['last_activity']:
                plugin_summaries[pid]['last_activity'] = log.created_at

        all_plugins = list(Plugin.objects.values(
            'plugin_id', 'title', 'status', 'config'
        ))

        # 解析 sandbox 配置
        for p in all_plugins:
            cfg = p.get('config') or {}
            p['sandbox_config'] = cfg.get('sandbox', {})

        context = {
            'active_section': 'sandbox',
            'sandbox_logs': sandbox_logs[:50],
            'plugin_summaries': list(plugin_summaries.values()),
            'all_plugins': all_plugins,
            'filter_plugin_id': request.GET.get('plugin_id', ''),
        }
        return render(request, 'admin/sandbox.html', context)

    def post(self, request):
        plugin_id = request.POST.get('plugin_id', '')
        security_level = request.POST.get('security_level', 'moderate')
        network_whitelist = request.POST.get('network_whitelist', '')

        try:
            plugin = Plugin.objects.get(plugin_id=plugin_id)
        except Plugin.DoesNotExist:
            return redirect('/admin-panel/sandbox/')

        config = plugin.config or {}
        if 'sandbox' not in config:
            config['sandbox'] = {}

        config['sandbox']['security_level'] = security_level
        if network_whitelist.strip():
            config['sandbox']['network_whitelist'] = [
                h.strip() for h in network_whitelist.split(',') if h.strip()
            ]
        else:
            config['sandbox']['network_whitelist'] = []

        plugin.config = config
        plugin.save()

        OperationLog.objects.create(
            log_type='operation', level='info',
            module='sandbox',
            action=f'更新插件沙盒配置: {plugin_id}',
            user=request.user,
            ip_address=request.META.get('REMOTE_ADDR', ''),
        )

        return redirect(f'/admin-panel/sandbox/?plugin_id={plugin_id}')

class AdminPluginPermissionsView(AdminAccessMixin, View):
    """插件权限审批"""

    def get(self, request):
        # 待审批：status=disabled 且 config 中有 requested_permissions
        pending_plugins = []
        all_plugins = Plugin.objects.all().order_by('-installed_at')

        for p in all_plugins:
            cfg = p.config or {}
            perms = cfg.get('requested_permissions', {})
            if perms:
                pending_plugins.append({
                    'plugin': p,
                    'permissions': perms,
                    'status_display': '待审核' if p.status == 'disabled' else p.get_status_display(),
                })

        # 已审批记录
        approval_logs = OperationLog.objects.filter(
            module='plugin_approval'
        ).order_by('-created_at')[:50]

        approval_log_list = []
        for log in approval_logs:
            details = {}
            if log.detail:
                try:
                    details = _json.loads(log.detail)
                except (ValueError, TypeError):
                    pass
            approval_log_list.append({
                'log': log,
                'details': details,
            })

        context = {
            'active_section': 'plugin_permissions',
            'pending_plugins': pending_plugins,
            'approval_logs': approval_log_list,
        }
        return render(request, 'admin/plugin_permissions.html', context)

    def post(self, request):
        plugin_id = request.POST.get('plugin_id', '')
        action = request.POST.get('approval_action', '')

        try:
            plugin = Plugin.objects.get(plugin_id=plugin_id)
        except Plugin.DoesNotExist:
            return redirect('/admin-panel/plugin-permissions/')

        if action == 'approve':
            plugin.status = 'enabled'
            plugin.save()
            log_action = f'批准插件权限: {plugin.title} ({plugin_id})'
            log_level = 'info'
        elif action == 'reject':
            cfg = plugin.config or {}
            cfg.pop('requested_permissions', None)
            plugin.config = cfg
            plugin.status = 'disabled'
            plugin.save()
            log_action = f'拒绝插件权限: {plugin.title} ({plugin_id})'
            log_level = 'warning'
        elif action == 'revoke':
            plugin.status = 'disabled'
            plugin.save()
            log_action = f'撤销插件启用: {plugin.title} ({plugin_id})'
            log_level = 'warning'
        else:
            return redirect('/admin-panel/plugin-permissions/')

        OperationLog.objects.create(
            log_type='operation',
            level=log_level,
            module='plugin_approval',
            action=log_action,
            user=request.user,
            ip_address=request.META.get('REMOTE_ADDR', ''),
            detail=_json.dumps({
                'plugin_id': plugin_id,
                'plugin_title': plugin.title,
                'action': action,
                'permissions': (plugin.config or {}).get('requested_permissions', {}),
            }, ensure_ascii=False),
        )

        return redirect('/admin-panel/plugin-permissions/')



class AdminTemplatePreviewView(AdminAccessMixin, View):
    """模板预览 — 渲染真实 CMS 数据"""

    @method_decorator(xframe_options_exempt)
    def get(self, request, pk):
        try:
            tpl = Template.objects.get(id=pk)
        except Template.DoesNotExist:
            return HttpResponse('模板不存在', status=404)

        from django.template.loader import render_to_string
        from core.services.config_service import ConfigService

        # 数据库中的路径形如 templates/home.html，模板引擎需要 home.html
        template_name = tpl.file_path
        if template_name.startswith('templates/'):
            template_name = template_name[len('templates/'):]

        context = {
            'request': request,
            'user': request.user,
            'site': {
                'name': ConfigService.get('site', 'site_name') or 'SWEMS',
                'slogan': ConfigService.get('site', 'site_slogan') or '',
                'copyright': ConfigService.get('site', 'copyright') or '',
                'domain': ConfigService.get('site', 'domain') or 'localhost',
            },
        }

        try:
            html = render_to_string(template_name, context, request=request)
        except Exception:
            # 降级：读取原始文件内容
            from django.conf import settings
            filepath = settings.BASE_DIR / tpl.file_path
            if filepath.exists():
                html = filepath.read_text(encoding='utf-8')
            else:
                html = tpl.content or f'<p>模板文件不存在: {tpl.file_path}</p>'

        # 注入禁用点击的样式和脚本
        inject = """
<style>
    a, button[type="submit"], input[type="submit"] {
        pointer-events: none !important;
        cursor: default !important;
        text-decoration: none !important;
    }
    form { pointer-events: none !important; }
</style>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // 禁用所有链接跳转
    document.querySelectorAll('a').forEach(function(a) {
        a.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
        }, true);
    });
    // 禁用所有表单提交
    document.querySelectorAll('form').forEach(function(f) {
        f.addEventListener('submit', function(e) {
            e.preventDefault();
            e.stopPropagation();
        }, true);
    });
});
</script>
"""

        # 插入到 </head> 之前（确保样式优先加载）
        if '</head>' in html:
            html = html.replace('</head>', inject + '</head>')
        elif '</body>' in html:
            html = html.replace('</body>', inject + '</body>')
        else:
            html = inject + html

        return HttpResponse(html, content_type='text/html')

    def post(self, request, pk):
        """编辑器内实时预览"""
        import json
        try:
            data = json.loads(request.body)
        except json.JSONDecodeError:
            return JsonResponse({'error': '无效数据'}, status=400)

        content = data.get('content', '')

        # 对编辑器中的原始 HTML 做 CMS 标签替换
        import re
        rendered = content
        rendered = re.sub(r'\{%\s*load\s+cms_tags\s*%\}', '', rendered)
        rendered = re.sub(r'\{%\s*extends\s+"[^"]+"\s*%\}', '', rendered)
        rendered = re.sub(r'\{%\s*block\s+\w+\s*%\}', '', rendered)
        rendered = re.sub(r'\{%\s*endblock\s*%\}', '', rendered)

        # 替换 CMS 标签为实际数据
        from core.models import SystemConfig
        def replace_cms_tag(match):
            tag_code = match.group(1)
            # 先查配置表
            parts = tag_code.split('.', 1)
            if len(parts) == 2:
                try:
                    cfg = SystemConfig.objects.get(group=parts[0], key=parts[1])
                    return cfg.value
                except SystemConfig.DoesNotExist:
                    pass
            return f'[{tag_code}]'

        rendered = re.sub(r'\{%\s*cms_tag\s+"([^"]+)"\s*%\}', replace_cms_tag, rendered)
        rendered = re.sub(r'\{%\s*cms_block\s+"([^"]+)"\s+"([^"]+)"\s*%\}', r'<!-- 区块: \1 -->', rendered)

        # 禁用点击
        inject = """<style>a,button{pointer-events:none!important;cursor:default!important}form{pointer-events:none!important}</style>"""
        if '</head>' in rendered:
            rendered = rendered.replace('</head>', inject + '</head>')
        else:
            rendered = inject + rendered

        return JsonResponse({'html': rendered})


class AdminTemplateContentView(AdminAccessMixin, View):
    """模板内容 API"""

    def get(self, request, pk):
        try:
            tpl = Template.objects.get(id=pk)
        except Template.DoesNotExist:
            return JsonResponse({'error': '模板不存在'}, status=404)

        return JsonResponse({
            'id': tpl.id,
            'file_path': tpl.file_path,
            'name': tpl.name or '',
            'content': tpl.content or '',
        })

    def put(self, request, pk):
        import json
        try:
            tpl = Template.objects.get(id=pk)
        except Template.DoesNotExist:
            return JsonResponse({'error': '模板不存在'}, status=404)

        try:
            data = json.loads(request.body)
        except json.JSONDecodeError:
            return JsonResponse({'error': '无效 JSON'}, status=400)

        content = data.get('content', '')

        # 保存到磁盘
        from django.conf import settings
        filepath = settings.BASE_DIR / tpl.file_path
        filepath.parent.mkdir(parents=True, exist_ok=True)
        filepath.write_text(content, encoding='utf-8')

        # 更新数据库
        tpl.content = content
        if 'name' in data and data['name']:
            tpl.name = data['name']
        tpl.save()

        LogService.log_operation(
            user=request.user, module='template',
            action=f'保存模板: {tpl.file_path}',
            ip_address=request.META.get('REMOTE_ADDR', ''),
        )
        return JsonResponse({'success': True})


# ============================================================
# 前台登录 / 注册
# ============================================================

class FrontendLoginView(View):
    """前台用户登录"""

    def get(self, request):
        if request.GET.get('action') == 'logout':
            logout(request)
            return redirect('/')

        if request.user.is_authenticated:
            # admin 用户不允许在前台停留
            if self._is_admin_user(request.user):
                logout(request)
                return render(request, 'frontend/login.html')
            return redirect('/')
        return render(request, 'frontend/login.html')

    def post(self, request):
        if request.GET.get('action') == 'logout':
            logout(request)
            return redirect('/')

        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')

        if not username or not password:
            return render(request, 'frontend/login.html', {'error': '请输入用户名和密码'})

        user = authenticate(request, username=username, password=password)

        if user is None or not user.is_active:
            return render(request, 'frontend/login.html', {
                'error': '账号不存在或密码错误',
                'username': username,
            })

        # admin 用户也不能通过前台登录
        if self._is_admin_user(user):
            return render(request, 'frontend/login.html', {
                'error': '账号不存在或密码错误',
                'username': username,
            })

        login(request, user)
        next_url = request.GET.get('next', '/')
        return redirect(next_url)

    def _is_admin_user(self, user):
        if user.is_superuser or user.user_type == 'admin':
            return True
        if user.permission_groups.filter(scope='admin').exists():
            return True
        return False

class FrontendRegisterView(View):
    """前台用户注册"""

    def get(self, request):
        if request.user.is_authenticated:
            return redirect('/')
        return render(request, 'frontend/register.html')

    def post(self, request):
        username = request.POST.get('username', '').strip()
        email = request.POST.get('email', '').strip()
        password = request.POST.get('password', '')
        password2 = request.POST.get('password2', '')

        errors = []
        if not username:
            errors.append('请输入用户名')
        if not password:
            errors.append('请输入密码')
        if password != password2:
            errors.append('两次密码输入不一致')
        if len(password) < 8:
            errors.append('密码长度至少 8 位')
        if User.objects.filter(username=username).exists():
            # 不暴露"用户名已存在"，改为通用提示
            errors.append('注册失败，请更换用户名后重试')

        if errors:
            return render(request, 'frontend/register.html', {
                'errors': errors,
                'username': username,
                'email': email,
            })

        user = User.objects.create_user(
            username=username,
            email=email,
            password=password,
            user_type='frontend',
        )

        default_groups = PermissionGroup.objects.filter(
            scope='frontend', is_default=True
        )
        for group in default_groups:
            group.users.add(user)

        login(request, user)
        return redirect('/')