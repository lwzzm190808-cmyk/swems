# plugins/__init__.py
"""
插件包

plugins/ 目录存放：
1. base.py — 插件基类（不移动）
2. 各插件子目录（安装时由 PluginLoader 自动创建）

注意：此目录下的插件由 PluginLoader 管理，
不要手动创建插件目录，应通过后台"安装插件"功能操作。
"""
