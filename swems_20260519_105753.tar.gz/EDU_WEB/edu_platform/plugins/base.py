# plugins/base.py
"""
插件开发基类

所有插件必须继承 PluginBase 并实现以下内容：

五核心属性：
  1. plugin_id   — 系统自动注入，无需实现
  2. title       — 插件标题（必须）
  3. template    — 前后台 UI 模板文件路径（必须）
  4. config      — 默认配置（必须）
  5. labels      — 插件提供的数据标签列表（必须）

生命周期钩子：
  on_install()   — 安装时触发（可建表、初始化数据）
  on_enable()    — 启用时触发
  on_disable()   — 停用时触发
  on_uninstall() — 卸载时触发（可清理数据）

API 接口：
  get_api(api_name) — 返回指定名称的 API 函数，供外部调用

使用示例：
    from plugins.base import PluginBase

    class MyPlugin(PluginBase):

        @property
        def title(self):
            return "我的插件"

        @property
        def template(self):
            return "templates/admin.html"

        @property
        def config(self):
            return {"items_per_page": 20}

        @property
        def labels(self):
            return [{"name": "文章", "tag_code": "article.title", ...}]

        def on_install(self):
            from django.core.management import call_command
            call_command('migrate', 'my_plugin')

        def on_enable(self):
            pass

        def on_disable(self):
            pass

        def on_uninstall(self):
            pass

        def get_api(self, api_name):
            return {"get_data": self._get_data}.get(api_name)

        def _get_data(self, **kwargs):
            return {"result": "ok"}
"""

from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, List, Optional


class PluginBase(ABC):
    """
    插件基类

    所有插件必须继承此类。插件的完整生命周期：
    1. 系统读取 manifest.json，加载插件类
    2. 实例化时注入 plugin_id 和 system_api
    3. 调用 on_install()（首次安装）
    4. 调用 on_enable()（启用）
    5. 运行期间通过 get_api() 提供服务
    6. 调用 on_disable()（停用）
    7. 调用 on_uninstall()（卸载）
    """

    def __init__(self, plugin_id: str, system_api):
        """
        初始化插件实例

        Args:
            plugin_id: 系统分配的唯一编号（如 PLG-20250514-001）
            system_api: PluginSystemAPI 实例，插件与系统交互的唯一通道
        """
        self._plugin_id = plugin_id
        self._system_api = system_api

    # ================================================================
    # 属性
    # ================================================================

    @property
    def plugin_id(self) -> str:
        """插件唯一编号（系统注入，不可覆盖）"""
        return self._plugin_id

    @property
    def system_api(self):
        """系统 API 接口（系统注入，不可覆盖）"""
        return self._system_api

    @property
    @abstractmethod
    def title(self) -> str:
        """
        插件标题

        Returns:
            人类可读的插件名称
        """
        ...

    @property
    @abstractmethod
    def template(self) -> str:
        """
        插件模板文件路径

        相对于插件安装目录的路径，如 "templates/admin.html"

        Returns:
            模板文件路径
        """
        ...

    @property
    @abstractmethod
    def config(self) -> dict:
        """
        插件默认配置

        插件首次安装时使用此配置，用户可在后台修改。

        Returns:
            默认配置字典
        """
        ...

    @property
    @abstractmethod
    def labels(self) -> List[dict]:
        """
        插件提供的数据标签列表

        每个标签字典包含：
        - name: 标签名称（如 "文章标题"）
        - tag_code: 标签代码（如 "article.title"）
        - source_type: 数据源类型（通常为 "plugin_data"）
        - source_config: 数据源配置

        Returns:
            标签定义列表
        """
        ...

    # ================================================================
    # 生命周期钩子
    # ================================================================

    @abstractmethod
    def on_install(self):
        """
        安装时触发

        在此执行一次性初始化：
        - 创建插件数据表
        - 插入初始数据
        - 注册系统标签
        """
        ...

    @abstractmethod
    def on_enable(self):
        """
        启用时触发

        在此执行启用逻辑：
        - 激活定时任务
        - 注册信号处理器
        """
        ...

    @abstractmethod
    def on_disable(self):
        """
        停用时触发

        在此执行停用逻辑：
        - 停止定时任务
        - 注销信号处理器
        """
        ...

    @abstractmethod
    def on_uninstall(self):
        """
        卸载时触发

        在此执行清理逻辑：
        - 删除插件数据表（可选）
        - 清理临时文件
        """
        ...

    # ================================================================
    # API 接口
    # ================================================================

    @abstractmethod
    def get_api(self, api_name: str) -> Optional[Callable]:
        """
        获取插件提供的 API 函数

        系统通过 UsePluginAPI(plugin_id, api_name, params) 调用时，
        会通过此方法获取对应的函数并执行。

        Args:
            api_name: API 名称

        Returns:
            对应的可调用函数，不存在返回 None
        """
        ...

    # ================================================================
    # 便捷方法（可选覆盖）
    # ================================================================

    def get_labels(self) -> List[dict]:
        """
        获取插件标签列表（供加载器注册使用）

        默认直接返回 labels 属性。
        需要动态生成标签的插件可覆盖此方法。
        """
        return self.labels

    def get_templates(self) -> List[dict]:
        """
        获取插件模板列表（供加载器注册使用）

        默认返回 template 属性指向的单个模板。
        多模板插件可覆盖此方法。

        Returns:
            [{"name": "模板名", "file": "相对路径"}]
        """
        return [{"name": self.title, "file": self.template}]

    def get_api_names(self) -> List[str]:
        """
        获取插件提供的所有 API 名称（用于调试和文档生成）

        默认遍历 get_api 返回非 None 的名称。
        可覆盖以返回固定列表。
        """
        return []

    def get_api_docs(self) -> dict:
        """
        返回插件所有 API 的文档（供后台插件文档页动态生成）

        覆盖此方法为插件 API 提供文档说明。

        Returns:
            {
                "api_name": {
                    "description": "功能描述",
                    "params": {
                        "param_name": {
                            "type": "str",
                            "required": True,
                            "description": "参数说明"
                        }
                    },
                    "returns": "返回值说明",
                    "example": "调用示例"
                }
            }
        """
        return {}

    @property
    def sidebar_items(self) -> list:
        """
        插件注册常驻侧边栏项目。

        覆盖此方法，返回列表即可在后台侧边栏中显示。
        插件停用后自动移除。

        Returns:
            [
                {
                    'label': '内容管理',       # 显示名称
                    'icon': '◆',              # 图标字符
                    'url': '/admin-panel/plugin/my-plugin/',  # 跳转地址
                }
            ]

        示例:
            @property
            def sidebar_items(self):
                return [
                    {'label': '文章管理', 'icon': '✎', 'url': '/admin-panel/plugin/articles/'},
                    {'label': '分类管理', 'icon': '☰', 'url': '/admin-panel/plugin/categories/'},
                ]
        """
        return []


    def get_labels_docs(self) -> list:
        """
        返回插件标签的文档说明

        Returns:
            [
                {
                    "tag_code": "article.title",
                    "description": "标签说明",
                    "usage": "{% cms_tag \"article.title\" %}"
                }
            ]
        """
        return []
