# core/admin.py
"""
Django 后台管理注册

所有核心模型的 admin 注册集中在此。
管理 API（DRF 视图）在各 modules/ 中独立实现，与此互不干扰。
"""

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import (
    User,
    PermissionGroup,
    Label,
    Template,
    SystemConfig,
    Plugin,
    OperationLog,
)


# =====================================================================
# 用户
# =====================================================================
@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ['username', 'email', 'user_type', 'phone', 'is_active', 'date_joined']
    list_filter = ['user_type', 'is_active', 'is_staff']
    search_fields = ['username', 'email', 'phone']
    fieldsets = BaseUserAdmin.fieldsets + (
        ('扩展信息', {'fields': ('user_type', 'phone', 'avatar')}),
    )
    add_fieldsets = BaseUserAdmin.add_fieldsets + (
        ('扩展信息', {'fields': ('user_type', 'phone')}),
    )


# =====================================================================
# 权限组
# =====================================================================
@admin.register(PermissionGroup)
class PermissionGroupAdmin(admin.ModelAdmin):
    list_display = ['name', 'scope', 'is_default', 'user_count', 'created_at']
    list_filter = ['scope', 'is_default']
    search_fields = ['name', 'description']
    filter_horizontal = ['users']
    readonly_fields = ['created_at', 'updated_at']

    def user_count(self, obj):
        return obj.users.count()
    user_count.short_description = '用户数'


# =====================================================================
# 标签
# =====================================================================
@admin.register(Label)
class LabelAdmin(admin.ModelAdmin):
    list_display = ['name', 'tag_code', 'source_type', 'is_system', 'plugin_id']
    list_filter = ['source_type', 'is_system']
    search_fields = ['name', 'tag_code']
    readonly_fields = ['created_at']


# =====================================================================
# 模板
# =====================================================================
@admin.register(Template)
class TemplateAdmin(admin.ModelAdmin):
    list_display = ['name', 'file_path', 'template_type', 'is_system', 'updated_at']
    list_filter = ['template_type', 'is_system']
    search_fields = ['name', 'file_path']
    readonly_fields = ['created_at', 'updated_at']


# =====================================================================
# 系统配置
# =====================================================================
@admin.register(SystemConfig)
class SystemConfigAdmin(admin.ModelAdmin):
    list_display = ['group', 'key', 'is_encrypted', 'short_value', 'updated_at']
    list_filter = ['group', 'is_encrypted']
    search_fields = ['key', 'description']
    readonly_fields = ['updated_at']

    def short_value(self, obj):
        if obj.is_encrypted:
            return '******'
        val = str(obj.value)
        return val[:60] + '...' if len(val) > 60 else val
    short_value.short_description = '配置值'


# =====================================================================
# 插件
# =====================================================================
@admin.register(Plugin)
class PluginAdmin(admin.ModelAdmin):
    list_display = ['plugin_id', 'title', 'name', 'version', 'status', 'installed_at']
    list_filter = ['status']
    search_fields = ['plugin_id', 'title', 'name']
    readonly_fields = ['plugin_id', 'installed_at', 'updated_at']


# =====================================================================
# 操作日志
# =====================================================================
@admin.register(OperationLog)
class OperationLogAdmin(admin.ModelAdmin):
    list_display = ['created_at', 'log_type', 'level', 'user', 'module', 'action_short']
    list_filter = ['log_type', 'level', 'module']
    search_fields = ['action', 'detail', 'user__username']
    readonly_fields = [
        'log_type', 'level', 'user', 'module', 'action',
        'detail', 'ip_address', 'created_at',
    ]
    date_hierarchy = 'created_at'

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def action_short(self, obj):
        return obj.action[:80] + '...' if len(obj.action) > 80 else obj.action
    action_short.short_description = '操作'
