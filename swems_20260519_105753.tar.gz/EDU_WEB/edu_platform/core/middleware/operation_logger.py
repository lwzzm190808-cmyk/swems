# core/middleware/operation_logger.py
"""
操作日志自动记录中间件

自动记录后台管理 API 的所有写操作和访问，
用于审计追踪和问题排查。
"""

import json
import logging
import time

from django.utils.deprecation import MiddlewareMixin

from core.services.log_service import LogService

logger = logging.getLogger(__name__)


class OperationLogMiddleware(MiddlewareMixin):
    """
    操作日志中间件

    记录策略：
    - 所有 /admin-api/ 的请求（后台管理操作）
    - 所有 POST/PUT/PATCH/DELETE 请求（写操作）
    - 登录失败（安全日志）
    - 跳过：静态文件、健康检查、OPTIONS 预检请求
    """

    # 不记录日志的路径前缀
    IGNORE_PATHS = (
        '/static/',
        '/media/',
        '/health/',
        '/favicon.ico',
    )

    # 敏感字段（记录时脱敏）
    SENSITIVE_FIELDS = frozenset({
        'password', 'new_password', 'old_password',
        'token', 'secret', 'api_key', 'credit_card',
    })

    # 日志详情最大长度
    MAX_DETAIL_LENGTH = 2000

    def process_request(self, request):
        """记录请求开始时间"""
        request._log_start_time = time.time()

    def process_response(self, request, response):
        """请求完成后记录日志"""

        # 跳过忽略路径
        path = request.path
        if any(path.startswith(p) for p in self.IGNORE_PATHS):
            return response

        # 跳过 OPTIONS 预检请求
        if request.method == 'OPTIONS':
            return response

        # 判断是否需要记录
        is_admin_api = path.startswith('/admin-api/')
        is_write_method = request.method in ('POST', 'PUT', 'PATCH', 'DELETE')
        is_login_failure = path.endswith('/login/') and response.status_code in (401, 403)

        if not (is_admin_api or is_write_method or is_login_failure):
            return response

        # 计算耗时
        duration_ms = 0
        start_time = getattr(request, '_log_start_time', None)
        if start_time:
            duration_ms = round((time.time() - start_time) * 1000, 2)

        # 确定日志类型和级别
        if is_login_failure:
            log_type = 'security'
            level = 'warning'
        elif response.status_code >= 500:
            log_type = 'error'
            level = 'error'
        elif response.status_code >= 400:
            log_type = 'operation'
            level = 'warning'
        else:
            log_type = 'operation'
            level = 'info'

        # 构建详情
        detail = self._build_detail(request, response, duration_ms)

        # 获取 IP
        ip_address = self._get_client_ip(request)

        # 获取用户
        user = request.user if hasattr(request, 'user') and request.user.is_authenticated else None

        # 获取模块名
        module = self._extract_module(path)

        # 记录日志
        try:
            LogService.create(
                log_type=log_type,
                level=level,
                user=user,
                module=module,
                action=f'{request.method} {path}',
                detail=detail,
                ip_address=ip_address,
            )
        except Exception as e:
            # 日志记录本身不能影响正常请求
            logger.error(f'日志记录失败: {e}')

        return response

    # ----------------------------------------------------------------
    # 内部方法
    # ----------------------------------------------------------------
    def _build_detail(self, request, response, duration_ms: float) -> str:
        """构建日志详情"""
        detail = {
            'status': response.status_code,
            'duration_ms': duration_ms,
        }

        # GET 请求记录查询参数
        if request.GET:
            detail['query_params'] = dict(request.GET)

        # 写请求记录请求体（脱敏）
        if request.method in ('POST', 'PUT', 'PATCH'):
            body = self._sanitize_body(request)
            if body:
                detail['body'] = body

        detail_str = json.dumps(detail, ensure_ascii=False)
        if len(detail_str) > self.MAX_DETAIL_LENGTH:
            detail_str = detail_str[:self.MAX_DETAIL_LENGTH] + '...[截断]'

        return detail_str

    def _sanitize_body(self, request) -> dict:
        """获取并脱敏请求体"""
        try:
            content_type = request.content_type or ''

            if 'application/json' in content_type:
                body = json.loads(request.body)
            elif 'multipart/form-data' in content_type:
                # 文件上传只记录字段名，不记录内容
                return {k: '[文件]' if hasattr(v, 'read') else str(v)[:100]
                        for k, v in request.POST.items()}
            else:
                body = dict(request.POST)

        except Exception:
            return {}

        # 脱敏
        return self._mask_sensitive(body)

    def _mask_sensitive(self, data) -> dict:
        """递归脱敏敏感字段"""
        if not isinstance(data, dict):
            return {}

        masked = {}
        for key, value in data.items():
            if key in self.SENSITIVE_FIELDS:
                masked[key] = '******'
            elif isinstance(value, dict):
                masked[key] = self._mask_sensitive(value)
            elif isinstance(value, str) and len(value) > 200:
                masked[key] = value[:200] + '...[截断]'
            else:
                masked[key] = value
        return masked

    @staticmethod
    def _get_client_ip(request) -> str:
        """获取客户端真实 IP"""
        x_forwarded = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded:
            return x_forwarded.split(',')[0].strip()
        return request.META.get('REMOTE_ADDR', '')

    @staticmethod
    def _extract_module(path: str) -> str:
        """从 URL 路径提取模块名"""
        # /admin-api/tag/list/ → tag
        parts = path.strip('/').split('/')
        if len(parts) >= 2 and parts[0] == 'admin-api':
            return parts[1]
        return 'unknown'
