
import logging
from django.http import JsonResponse, HttpResponseRedirect
from django.conf import settings

logger = logging.getLogger('core.middleware')

EXEMPT_PATHS = [
    '/admin-panel/login/',
    '/admin-panel/logout/',
    '/login/',
    '/register/',
    '/static/',
    '/media/',
    '/favicon.ico',
]

PLUGIN_API_PREFIX = '/admin-api/'


class PermissionMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        path = request.path

        # 豁免路径
        for exempt in EXEMPT_PATHS:
            if path.startswith(exempt):
                return self.get_response(request)

        # 后台区域：必须是 admin 用户
        if path.startswith('/admin-panel/') or path.startswith('/admin-api/'):
            if not request.user.is_authenticated:
                if path.startswith('/admin-api/'):
                    return JsonResponse({'error': '请先登录'}, status=401)
                return HttpResponseRedirect('/admin-panel/login/')

            # 不是后台用户 → 踢回前台
            if not self._is_admin_user(request.user):
                if path.startswith('/admin-api/'):
                    return JsonResponse({'error': '无后台访问权限'}, status=403)
                return HttpResponseRedirect('/')

            # 超级管理员放行
            if request.user.is_superuser:
                return self.get_response(request)

            # 插件 API 调用
            if path.startswith(PLUGIN_API_PREFIX + 'plugin/') and '/call-api/' in path:
                return self.get_response(request)

            # 检查模块级权限
            module = self._get_module(path)
            if module:
                action = self._get_action(request.method)
                from core.services.permission_service import PermissionService
                if not PermissionService.check_permission(request.user, module, action):
                    if path.startswith('/admin-api/'):
                        return JsonResponse({'error': f'无权限: {module}.{action}'}, status=403)
                    # return HttpResponseRedirect('/admin-panel/')

            return self.get_response(request)

        return self.get_response(request)

    def _is_admin_user(self, user):
        """判断是否为后台用户"""
        if user.is_superuser:
            return True
        if user.user_type == 'admin':
            return True
        if user.permission_groups.filter(scope='admin').exists():
            return True
        return False

    def _is_frontend_user(self, user):
        """判断是否为前台用户"""
        if user.user_type == 'frontend':
            return True
        if user.permission_groups.filter(scope='frontend').exists():
            return True
        return False

    def _get_module(self, path):
        if path.startswith('/admin-panel/'):
            parts = path.strip('/').split('/')
            if len(parts) >= 2:
                module_map = {
                    'users': 'users', 'tags': 'tag', 'templates': 'template',
                    'config': 'config', 'permissions': 'permission',
                    'plugins': 'plugin', 'logs': 'log', 'plugin-docs': 'plugin',
                    'template': 'template',
                }
                return module_map.get(parts[1])
        elif path.startswith('/admin-api/'):
            parts = path.strip('/').split('/')
            if len(parts) >= 2:
                return parts[1]
        return None

    def _get_action(self, method):
        return {'GET': 'view', 'POST': 'add', 'PUT': 'change',
                'PATCH': 'change', 'DELETE': 'delete'}.get(method, 'view')
