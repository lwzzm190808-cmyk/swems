# core/services/config_service.py
"""
系统配置服务

职责：
- 配置项 CRUD（含加密字段自动加解密）
- 按分组查询配置
- 配置缓存管理
"""

import json
import logging
from typing import Any, Dict, Optional

from django.db import IntegrityError

from core.models import SystemConfig
from shared.security.encryption import encrypt_value, decrypt_value
from shared.cache.service import CacheService

logger = logging.getLogger(__name__)


class ConfigService:
    """系统配置服务"""

    # ----------------------------------------------------------------
    # 读取
    # ----------------------------------------------------------------
    @classmethod
    def get(cls, group: str, key: str) -> Optional[Any]:
        """
        获取单个配置项的值（带缓存）

        Args:
            group: 配置分组
            key: 配置键

        Returns:
            配置值（已解密），不存在返回 None
        """
        # 先查缓存
        cached = CacheService.get_config(group, key)
        if cached is not None:
            return cached

        try:
            config = SystemConfig.objects.get(group=group, key=key)
        except SystemConfig.DoesNotExist:
            return None

        value = config.value
        if config.is_encrypted:
            value = decrypt_value(value)

        CacheService.set_config(group, key, value)
        return value

    @classmethod
    def get_by_key(cls, key: str) -> Dict:
        """
        按 key 模糊查询（PluginSystemAPI 调用）

        返回包含 group、key、value 的字典
        """
        config = SystemConfig.objects.filter(key__iexact=key).first()
        if not config:
            return {"error": f"配置项 '{key}' 不存在"}

        value = config.value
        if config.is_encrypted:
            value = decrypt_value(value)

        return {
            "group": config.group,
            "key": config.key,
            "value": value,
            "description": config.description,
        }

    @classmethod
    def get_group(cls, group: str) -> Dict[str, Any]:
        """
        获取某分组下的全部配置

        Returns:
            {key: value, ...}，敏感字段返回 '******'
        """
        configs = SystemConfig.objects.filter(group=group)
        result = {}
        for c in configs:
            if c.is_encrypted:
                result[c.key] = '******'
            else:
                result[c.key] = c.value
        return result

    # ----------------------------------------------------------------
    # 写入
    # ----------------------------------------------------------------
    @classmethod
    def set(
        cls,
        group: str,
        key: str,
        value: Any,
        description: str = '',
        is_encrypted: bool = False,
    ) -> SystemConfig:
        """
        设置配置项（创建或更新）

        Args:
            group: 配置分组
            key: 配置键
            value: 配置值
            description: 描述
            is_encrypted: 是否加密存储

        Returns:
            SystemConfig 实例
        """
        stored_value = encrypt_value(value) if is_encrypted else value

        config, created = SystemConfig.objects.update_or_create(
            group=group,
            key=key,
            defaults={
                'value': stored_value,
                'description': description,
                'is_encrypted': is_encrypted,
            },
        )

        # 清除缓存
        CacheService.delete(f'{group}:{key}', namespace='config')

        action = '创建' if created else '更新'
        logger.info(f'配置{action}: {group}.{key}')
        return config

    # ----------------------------------------------------------------
    # 删除
    # ----------------------------------------------------------------
    @classmethod
    def delete(cls, group: str, key: str) -> bool:
        """删除配置项"""
        deleted, _ = SystemConfig.objects.filter(group=group, key=key).delete()
        if deleted:
            CacheService.delete(f'{group}:{key}', namespace='config')
            logger.info(f'配置已删除: {group}.{key}')
        return deleted > 0

    # ----------------------------------------------------------------
    # 缓存
    # ----------------------------------------------------------------
    @classmethod
    def clear_cache(cls, group: str = None):
        """清除配置缓存"""
        CacheService.clear_config(group)
        logger.info(f'配置缓存已清除: {group or "全部"}')
