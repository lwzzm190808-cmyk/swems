# core/services/__init__.py
# 保持空文件
# 使用时：from core.services.config_service import ConfigService
