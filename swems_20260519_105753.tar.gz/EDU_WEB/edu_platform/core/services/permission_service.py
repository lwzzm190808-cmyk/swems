# core/services/permission_service.py
"""
权限服务

职责：
- 后台权限检查（管理员对各模块的操作权限）
- 前台权限检查（前台用户的访问范围）
- 权限组 CRUD
- 权限信息查询（供 API 使用）
- 权限缓存管理
"""

import logging
from typing import Any, Dict, List, Optional

from django.http import HttpRequest

from core.models import PermissionGroup, User
from shared.cache.service import CacheService

logger = logging.getLogger(__name__)


# 模块名 → URL 前缀的映射
MODULE_URL_MAP = {
    'tag': '/admin-api/tag/',
    'template': '/admin-api/template/',
    'config': '/admin-api/config/',
    'permission': '/admin-api/permission/',
    'plugin': '/admin-api/plugin/',
    'log': '/admin-api/log/',
}

# HTTP 方法 → 操作名
METHOD_ACTION_MAP = {
    'GET': 'view',
    'POST': 'add',
    'PUT': 'edit',
    'PATCH': 'edit',
    'DELETE': 'delete',
}

# 不需要权限检查的路径
WHITELIST_PATHS = [
    '/admin/',
    '/admin-api/auth/',
    '/api/token/',
    '/api/token/refresh/',
    '/health/',
]


class PermissionService:
    """权限服务"""

    # ----------------------------------------------------------------
    # 权限检查（中间件调用）
    # ----------------------------------------------------------------
    @classmethod
    def check_admin_permission(cls, user: User, module: str, action: str) -> bool:
        """
        检查后台管理员是否有指定模块的操作权限

        Args:
            user: 用户对象
            module: 模块名（如 "tag", "template"）
            action: 操作名（view / add / edit / delete）

        Returns:
            是否有权限
        """
        if not user.is_authenticated:
            return False

        # 超级管理员拥有全部权限
        if user.is_superuser:
            return True

        # 必须是后台管理员
        if user.user_type != 'admin':
            return False

        # 查缓存
        cache_key = f'{user.username}:admin:{module}:{action}'
        cached = CacheService.get_permission(cache_key)
        if cached is not None:
            return cached

        # 查询用户所属的后台权限组
        groups = PermissionGroup.objects.filter(
            users=user,
            scope='admin',
        )

        has_perm = False
        for group in groups:
            module_perms = group.permissions.get(module, [])
            if action in module_perms:
                has_perm = True
                break

        CacheService.set_permission(cache_key, has_perm)
        return has_perm

    @classmethod
    def check_frontend_permission(cls, user: User, resource: str, action: str) -> bool:
        """
        检查前台用户是否有指定资源的操作权限

        Args:
            user: 前台用户
            resource: 资源名（如 "course", "homework"）
            action: 操作名（view / enroll / submit 等）

        Returns:
            是否有权限
        """
        if not user.is_authenticated:
            return False

        cache_key = f'{user.username}:frontend:{resource}:{action}'
        cached = CacheService.get_permission(cache_key)
        if cached is not None:
            return cached

        groups = PermissionGroup.objects.filter(
            users=user,
            scope='frontend',
        )

        has_perm = False
        for group in groups:
            resource_perms = group.permissions.get(resource, [])
            if action in resource_perms:
                has_perm = True
                break

        CacheService.set_permission(cache_key, has_perm)
        return has_perm

    # ----------------------------------------------------------------
    # URL 解析
    # ----------------------------------------------------------------
    @classmethod
    def resolve_request(cls, request: HttpRequest) -> tuple:
        """
        从请求中解析出模块名和操作类型

        Returns:
            (module_name, action) — 无法解析返回 (None, None)
        """
        path = request.path

        # 白名单路径跳过
        if any(path.startswith(p) for p in WHITELIST_PATHS):
            return None, None

        # 从 URL 前缀匹配模块
        module = None
        for mod, prefix in MODULE_URL_MAP.items():
            if path.startswith(prefix):
                module = mod
                break

        if module is None:
            return None, None

        action = METHOD_ACTION_MAP.get(request.method, 'view')
        return module, action

    # ----------------------------------------------------------------
    # 权限查询（API 使用）
    # ----------------------------------------------------------------
    @classmethod
    def get_admin_permissions(cls, username: Optional[str] = None) -> Any:
        """
        获取后台管理员权限信息

        Args:
            username: 指定用户名，None 返回所有后台用户权限

        Returns:
            权限信息字典或列表
        """
        if username:
            user = User.objects.filter(username=username, user_type='admin').first()
            if not user:
                return {"error": f"后台用户 '{username}' 不存在"}
            return cls._build_permission_info(user, scope='admin')
        else:
            users = User.objects.filter(user_type='admin', is_active=True)
            return [cls._build_permission_info(u, scope='admin') for u in users]

    @classmethod
    def get_user_permissions(cls, username: str) -> Dict:
        """
        获取前台用户权限信息

        Args:
            username: 用户名（不允许为空）

        Returns:
            权限信息字典
        """
        if not username:
            return {"error": "用户名不能为空"}

        user = User.objects.filter(username=username, user_type='frontend').first()
        if not user:
            return {"error": f"前台用户 '{username}' 不存在"}

        return cls._build_permission_info(user, scope='frontend')

    @classmethod
    def _build_permission_info(cls, user: User, scope: str) -> Dict:
        """构建单个用户的权限信息"""
        groups = user.permission_groups.filter(scope=scope)
        return {
            "username": user.username,
            "user_type": user.user_type,
            "groups": [
                {
                    "id": g.id,
                    "name": g.name,
                    "permissions": g.permissions,
                }
                for g in groups
            ],
        }

    # ----------------------------------------------------------------
    # 权限组管理
    # ----------------------------------------------------------------
    @classmethod
    def create_group(cls, name: str, scope: str, permissions: dict,
                     description: str = '', is_default: bool = False) -> PermissionGroup:
        """创建权限组"""
        group = PermissionGroup.objects.create(
            name=name,
            scope=scope,
            permissions=permissions,
            description=description,
            is_default=is_default,
        )
        cls.clear_cache()
        logger.info(f'权限组已创建: [{scope}] {name}')
        return group

    @classmethod
    def update_group(cls, group_id: int, **kwargs) -> Optional[PermissionGroup]:
        """更新权限组"""
        try:
            group = PermissionGroup.objects.get(id=group_id)
        except PermissionGroup.DoesNotExist:
            return None

        for k, v in kwargs.items():
            if hasattr(group, k):
                setattr(group, k, v)
        group.save()
        cls.clear_cache()
        return group

    @classmethod
    def set_group_users(cls, group_id: int, user_ids: List[int]) -> Optional[PermissionGroup]:
        """设置权限组成员"""
        try:
            group = PermissionGroup.objects.get(id=group_id)
        except PermissionGroup.DoesNotExist:
            return None

        group.users.set(user_ids)
        cls.clear_cache()
        return group

    # ----------------------------------------------------------------
    # 缓存管理
    # ----------------------------------------------------------------
    @classmethod
    def clear_cache(cls, username: str = None):
        """清除权限缓存"""
        CacheService.clear_permission(username)
