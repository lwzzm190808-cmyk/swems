# core/services/log_service.py
"""
日志服务

职责：
- 日志记录创建（操作日志、运行日志、错误日志、安全日志）
- 日志查询（支持多条件过滤）
- 服务器状态监控（CPU / 内存 / 磁盘）
"""

import json
import logging
from typing import Any, Dict, List, Optional

from core.models import OperationLog, User

logger = logging.getLogger(__name__)


class LogService:
    """日志服务"""

    # ----------------------------------------------------------------
    # 记录日志
    # ----------------------------------------------------------------
    @classmethod
    def create(
        cls,
        log_type: str = 'operation',
        level: str = 'info',
        user: Optional[User] = None,
        module: str = '',
        action: str = '',
        detail: str = '',
        ip_address: str = None,
    ) -> OperationLog:
        """
        创建日志记录

        Args:
            log_type: 日志类型（operation / runtime / error / security）
            level: 级别（info / warning / error / critical）
            user: 操作用户
            module: 模块名
            action: 操作描述
            detail: 详情
            ip_address: IP 地址

        Returns:
            OperationLog 实例
        """
        return OperationLog.objects.create(
            log_type=log_type,
            level=level,
            user=user,
            module=module,
            action=action,
            detail=detail,
            ip_address=ip_address,
        )

    # ----------------------------------------------------------------
    # 查询日志
    # ----------------------------------------------------------------
    @classmethod
    def query(
        cls,
        log_type: Optional[str] = None,
        level: Optional[str] = None,
        user: Optional[User] = None,
        username: Optional[str] = None,
        module: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict]:
        """
        查询日志

        Args:
            log_type: 日志类型过滤
            level: 级别过滤
            user: 用户对象过滤
            username: 用户名过滤
            module: 模块名过滤
            limit: 返回数量
            offset: 偏移量

        Returns:
            日志列表（字典格式）
        """
        qs = OperationLog.objects.all()

        if log_type:
            qs = qs.filter(log_type=log_type)
        if level:
            qs = qs.filter(level=level)
        if user:
            qs = qs.filter(user=user)
        if username:
            qs = qs.filter(user__username=username)
        if module:
            qs = qs.filter(module=module)

        qs = qs.order_by('-created_at')[offset:offset + limit]

        return [
            {
                "id": log.id,
                "log_type": log.log_type,
                "level": log.level,
                "user": log.user.username if log.user else None,
                "module": log.module,
                "action": log.action,
                "detail": log.detail,
                "ip_address": log.ip_address,
                "created_at": log.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            }
            for log in qs
        ]

    @classmethod
    def count(cls, log_type: Optional[str] = None) -> int:
        """统计日志数量"""
        qs = OperationLog.objects.all()
        if log_type:
            qs = qs.filter(log_type=log_type)
        return qs.count()

    # ----------------------------------------------------------------
    # 服务器状态
    # ----------------------------------------------------------------
    @classmethod
    def get_server_status(cls) -> Dict:
        """
        获取服务器运行状态

        Returns:
            CPU / 内存 / 磁盘使用信息
        """
        import psutil

        cpu_percent = psutil.cpu_percent(interval=0.5)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')

        return {
            'cpu': {
                'percent': cpu_percent,
                'count': psutil.cpu_count(),
                'count_logical': psutil.cpu_count(logical=True),
            },
            'memory': {
                'total_gb': round(memory.total / (1024 ** 3), 2),
                'used_gb': round(memory.used / (1024 ** 3), 2),
                'available_gb': round(memory.available / (1024 ** 3), 2),
                'percent': memory.percent,
            },
            'disk': {
                'total_gb': round(disk.total / (1024 ** 3), 2),
                'used_gb': round(disk.used / (1024 ** 3), 2),
                'free_gb': round(disk.free / (1024 ** 3), 2),
                'percent': disk.percent,
            },
        }

    # ----------------------------------------------------------------
    # 便捷方法
    # ----------------------------------------------------------------
    @classmethod
    def log_operation(cls, user, module, action, detail='', ip_address=None):
        """快捷记录操作日志"""
        return cls.create(
            log_type='operation', level='info',
            user=user, module=module, action=action,
            detail=detail, ip_address=ip_address,
        )

    @classmethod
    def log_error(cls, module, action, detail='', user=None):
        """快捷记录错误日志"""
        return cls.create(
            log_type='error', level='error',
            user=user, module=module, action=action,
            detail=detail,
        )

    @classmethod
    def log_security(cls, user, action, detail='', ip_address=None):
        """快捷记录安全日志"""
        return cls.create(
            log_type='security', level='warning',
            user=user, module='auth', action=action,
            detail=detail, ip_address=ip_address,
        )
# core/services/log_service.py
"""
日志服务

职责：
- 日志记录创建（操作日志、运行日志、错误日志、安全日志）
- 日志查询（支持多条件过滤）
- 服务器状态监控（CPU / 内存 / 磁盘）
"""

import json
import logging
from typing import Any, Dict, List, Optional

from core.models import OperationLog, User

logger = logging.getLogger(__name__)


class LogService:
    """日志服务"""

    # ----------------------------------------------------------------
    # 记录日志
    # ----------------------------------------------------------------
    @classmethod
    def create(
        cls,
        log_type: str = 'operation',
        level: str = 'info',
        user: Optional[User] = None,
        module: str = '',
        action: str = '',
        detail: str = '',
        ip_address: str = None,
    ) -> OperationLog:
        """
        创建日志记录

        Args:
            log_type: 日志类型（operation / runtime / error / security）
            level: 级别（info / warning / error / critical）
            user: 操作用户
            module: 模块名
            action: 操作描述
            detail: 详情
            ip_address: IP 地址

        Returns:
            OperationLog 实例
        """
        return OperationLog.objects.create(
            log_type=log_type,
            level=level,
            user=user,
            module=module,
            action=action,
            detail=detail,
            ip_address=ip_address,
        )

    # ----------------------------------------------------------------
    # 查询日志
    # ----------------------------------------------------------------
    @classmethod
    def query(
        cls,
        log_type: Optional[str] = None,
        level: Optional[str] = None,
        user: Optional[User] = None,
        username: Optional[str] = None,
        module: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict]:
        """
        查询日志

        Args:
            log_type: 日志类型过滤
            level: 级别过滤
            user: 用户对象过滤
            username: 用户名过滤
            module: 模块名过滤
            limit: 返回数量
            offset: 偏移量

        Returns:
            日志列表（字典格式）
        """
        qs = OperationLog.objects.all()

        if log_type:
            qs = qs.filter(log_type=log_type)
        if level:
            qs = qs.filter(level=level)
        if user:
            qs = qs.filter(user=user)
        if username:
            qs = qs.filter(user__username=username)
        if module:
            qs = qs.filter(module=module)

        qs = qs.order_by('-created_at')[offset:offset + limit]

        return [
            {
                "id": log.id,
                "log_type": log.log_type,
                "level": log.level,
                "user": log.user.username if log.user else None,
                "module": log.module,
                "action": log.action,
                "detail": log.detail,
                "ip_address": log.ip_address,
                "created_at": log.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            }
            for log in qs
        ]

    @classmethod
    def count(cls, log_type: Optional[str] = None) -> int:
        """统计日志数量"""
        qs = OperationLog.objects.all()
        if log_type:
            qs = qs.filter(log_type=log_type)
        return qs.count()

    # ----------------------------------------------------------------
    # 服务器状态
    # ----------------------------------------------------------------
    @classmethod
    def get_server_status(cls) -> Dict:
        """
        获取服务器运行状态

        Returns:
            CPU / 内存 / 磁盘使用信息
        """
        import psutil

        cpu_percent = psutil.cpu_percent(interval=0.5)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')

        return {
            'cpu': {
                'percent': cpu_percent,
                'count': psutil.cpu_count(),
                'count_logical': psutil.cpu_count(logical=True),
            },
            'memory': {
                'total_gb': round(memory.total / (1024 ** 3), 2),
                'used_gb': round(memory.used / (1024 ** 3), 2),
                'available_gb': round(memory.available / (1024 ** 3), 2),
                'percent': memory.percent,
            },
            'disk': {
                'total_gb': round(disk.total / (1024 ** 3), 2),
                'used_gb': round(disk.used / (1024 ** 3), 2),
                'free_gb': round(disk.free / (1024 ** 3), 2),
                'percent': disk.percent,
            },
        }

    # ----------------------------------------------------------------
    # 便捷方法
    # ----------------------------------------------------------------
    @classmethod
    def log_operation(cls, user, module, action, detail='', ip_address=None):
        """快捷记录操作日志"""
        return cls.create(
            log_type='operation', level='info',
            user=user, module=module, action=action,
            detail=detail, ip_address=ip_address,
        )

    @classmethod
    def log_error(cls, module, action, detail='', user=None):
        """快捷记录错误日志"""
        return cls.create(
            log_type='error', level='error',
            user=user, module=module, action=action,
            detail=detail,
        )

    @classmethod
    def log_security(cls, user, action, detail='', ip_address=None):
        """快捷记录安全日志"""
        return cls.create(
            log_type='security', level='warning',
            user=user, module='auth', action=action,
            detail=detail, ip_address=ip_address,
        )
