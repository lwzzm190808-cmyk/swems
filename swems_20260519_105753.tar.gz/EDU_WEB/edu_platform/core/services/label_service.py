# core/services/label_service.py
"""
CMS 标签服务

职责：
- 标签 CRUD
- 标签数据解析（将 tag_code 解析为实际数据）
- 支持三种数据源：model_field、custom_query、plugin_data
- 插件数据解析通过 DI 注入（避免 core → modules 依赖）
"""

import logging
from typing import Any, Dict, List, Optional

from core.models import Label
from shared.cache.service import CacheService
from shared.security.validator import InputValidator

logger = logging.getLogger(__name__)


class LabelService:
    """
    标签服务

    插件数据解析器通过 set_plugin_api_resolver() 注入，
    由 modules/plugin 在 Django 启动时注册。
    """

    _plugin_api_resolver = None  # Callable[[plugin_id, api_name, **params], result]

    # ----------------------------------------------------------------
    # DI：插件解析器注册
    # ----------------------------------------------------------------
    @classmethod
    def set_plugin_api_resolver(cls, resolver):
        """
        注册插件 API 解析器

        在 modules/plugin/apps.py 的 ready() 中调用：
            LabelService.set_plugin_api_resolver(PluginLoader.call_plugin_api)
        """
        cls._plugin_api_resolver = resolver
        logger.info('标签服务：插件数据解析器已注册')

    # ----------------------------------------------------------------
    # 查询
    # ----------------------------------------------------------------
    @classmethod
    def get_all(cls) -> List[Label]:
        """获取全部标签"""
        return list(Label.objects.all())

    @classmethod
    def get_all_serialized(cls) -> List[Dict]:
        """获取全部标签的序列化数据（API 使用）"""
        return list(
            Label.objects.all().values(
                'id', 'name', 'tag_code', 'source_type',
                'source_config', 'description', 'is_system', 'plugin_id',
            )
        )

    @classmethod
    def get_by_code(cls, tag_code: str) -> Optional[Label]:
        """按 tag_code 获取标签"""
        try:
            return Label.objects.get(tag_code=tag_code)
        except Label.DoesNotExist:
            return None

    # ----------------------------------------------------------------
    # 数据解析
    # ----------------------------------------------------------------
    @classmethod
    def resolve(cls, tag_code: str) -> Any:
        """
        将标签代码解析为实际数据

        优先查缓存，缓存未命中则查库 + 执行数据源解析。

        Args:
            tag_code: 标签代码，如 "article.title"

        Returns:
            解析后的数据（str / list / dict / 错误信息字符串）
        """
        # 查缓存
        cached = CacheService.get_label(tag_code)
        if cached is not None:
            return cached

        # 查标签定义
        label = cls.get_by_code(tag_code)
        if label is None:
            return f'[标签不存在: {tag_code}]'

        # 根据 source_type 分派解析
        config = label.source_config or {}
        source_type = label.source_type

        if source_type == 'model_field':
            value = cls._resolve_model_field(config)
        elif source_type == 'custom_query':
            value = cls._resolve_custom_query(config)
        elif source_type == 'plugin_data':
            value = cls._resolve_plugin_data(config, label.plugin_id)
        else:
            value = f'[未知数据源类型: {source_type}]'

        # 写入缓存
        CacheService.set_label(tag_code, value)
        return value

    # ----------------------------------------------------------------
    # CRUD
    # ----------------------------------------------------------------
    @classmethod
    def create(cls, **kwargs) -> Label:
        """创建标签"""
        tag_code = kwargs.get('tag_code', '')
        is_valid, error = InputValidator.validate_tag_code(tag_code)
        if not is_valid:
            raise ValueError(error)

        label = Label.objects.create(**kwargs)
        CacheService.clear_labels()
        logger.info(f'标签已创建: {label.tag_code}')
        return label

    @classmethod
    def update(cls, label_id: int, **kwargs) -> Optional[Label]:
        """更新标签"""
        try:
            label = Label.objects.get(id=label_id)
        except Label.DoesNotExist:
            return None

        for k, v in kwargs.items():
            if hasattr(label, k):
                setattr(label, k, v)
        label.save()
        CacheService.clear_labels()
        logger.info(f'标签已更新: {label.tag_code}')
        return label

    @classmethod
    def delete(cls, label_id: int) -> bool:
        """删除标签"""
        deleted, _ = Label.objects.filter(id=label_id).delete()
        if deleted:
            CacheService.clear_labels()
        return deleted > 0

    # ----------------------------------------------------------------
    # 缓存
    # ----------------------------------------------------------------
    @classmethod
    def clear_cache(cls):
        """清除全部标签缓存"""
        CacheService.clear_labels()

    # ----------------------------------------------------------------
    # 内部解析方法
    # ----------------------------------------------------------------
    @classmethod
    def _resolve_model_field(cls, config: dict) -> Any:
        """
        从 Django Model 中取值

        config 示例:
            字段取值: {"model": "courses.Course", "field": "title", "filter": {...}}
            计数模式: {"model": "core.User", "count": true, "filter": {...}}
        """
        try:
            from django.apps import apps

            model_path = config.get('model', '')
            field = config.get('field')
            filters = config.get('filter', {})
            limit = config.get('limit')
            ordering = config.get('ordering')
            count = config.get('count', False)

            if not model_path:
                return '[配置错误: model 为空]'

            app_label, model_name = model_path.rsplit('.', 1)
            model = apps.get_model(app_label, model_name)

            queryset = model.objects.filter(**filters)

            if ordering:
                queryset = queryset.order_by(ordering)

            # 计数模式：返回整数
            if count:
                return queryset.count()

            if limit:
                queryset = queryset[:limit]

            if field:
                return list(queryset.values_list(field, flat=True))
            return list(queryset.values())

        except ValueError:
            return f'[配置错误: model 格式不正确 "{model_path}"]'
        except LookupError:
            return f'[模型不存在: {model_path}]'
        except Exception as e:
            logger.error(f'模型字段解析失败: {e}')
            return f'[解析失败: {str(e)}]'

    @classmethod
    def _resolve_custom_query(cls, config: dict) -> Any:
        """
        执行自定义 SQL 查询（仅 SELECT）

        config 示例:
            {"sql": "SELECT title FROM courses_course WHERE status=%s LIMIT %s", "params": ["published", 10]}
        """
        from django.db import connection

        sql = config.get('sql', '')
        params = config.get('params', [])

        is_valid, error = InputValidator.validate_sql_select(sql)
        if not is_valid:
            return f'[SQL 安全检查失败: {error}]'

        try:
            with connection.cursor() as cursor:
                cursor.execute(sql, params)
                if cursor.description:
                    columns = [col[0] for col in cursor.description]
                    return [dict(zip(columns, row)) for row in cursor.fetchall()]
                return []
        except Exception as e:
            logger.error(f'SQL 执行失败: {e}')
            return f'[查询失败: {str(e)}]'

    @classmethod
    def _resolve_plugin_data(cls, config: dict, plugin_id: str) -> Any:
        """
        通过插件 API 获取数据

        config 示例:
            {"method": "get_articles", "params": {"limit": 10}}
        """
        if cls._plugin_api_resolver is None:
            return '[插件系统未就绪]'

        method = config.get('method', 'get_data')
        params = config.get('params', {})

        try:
            return cls._plugin_api_resolver(plugin_id, method, **params)
        except Exception as e:
            logger.error(f'插件数据获取失败 [{plugin_id}.{method}]: {e}')
            return f'[插件数据获取失败: {str(e)}]'
