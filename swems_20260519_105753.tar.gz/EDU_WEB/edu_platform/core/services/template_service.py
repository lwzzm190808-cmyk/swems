# core/services/template_service.py
"""
模板管理服务

职责：
- 模板 CRUD（数据库记录 + 磁盘文件同步）
- 模板内容读写（通过内嵌编辑器修改）
- 模板渲染（使用 Django 模板引擎加载磁盘文件）
- 模板预览数据准备
"""

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from django.conf import settings

from core.models import Template
from shared.cache.service import CacheService

logger = logging.getLogger(__name__)


class TemplateService:
    """
    模板管理服务

    模板文件存储在磁盘（templates/ 目录），由 Django 模板引擎加载渲染。
    数据库记录用于管理界面（名称、类型、编辑等）。
    """

    # ----------------------------------------------------------------
    # 查询
    # ----------------------------------------------------------------
    @classmethod
    def get_all(cls) -> List[Template]:
        """获取全部模板"""
        return list(Template.objects.all())

    @classmethod
    def get_all_serialized(cls) -> List[Dict]:
        """获取全部模板的序列化数据（API 使用）"""
        return list(
            Template.objects.all().values(
                'id', 'name', 'file_path', 'template_type',
                'is_system', 'plugin_id', 'updated_at',
            )
        )

    @classmethod
    def get_by_path(cls, file_path: str) -> Optional[Template]:
        """按文件路径获取模板"""
        try:
            return Template.objects.get(file_path=file_path)
        except Template.DoesNotExist:
            return None

    # ----------------------------------------------------------------
    # 渲染
    # ----------------------------------------------------------------
    @classmethod
    def render(cls, file_path: str, context: dict = None) -> str:
        """
        渲染模板

        使用 Django 模板引擎从磁盘加载模板文件并渲染。
        模板中的 {% load cms_tags %} 和 {% cms_tag %} 标签会被正确处理。

        Args:
            file_path: 相对于 templates/ 的文件路径，如 "home.html"
            context: 模板上下文数据

        Returns:
            渲染后的 HTML 字符串
        """
        from django.template.loader import render_to_string

        try:
            return render_to_string(file_path, context or {})
        except Exception as e:
            logger.error(f'模板渲染失败 [{file_path}]: {e}')
            return f'<!-- 模板渲染错误: {str(e)} -->'

    # ----------------------------------------------------------------
    # 文件操作
    # ----------------------------------------------------------------
    @classmethod
    def read_content(cls, file_path: str) -> str:
        """
        读取模板文件内容（供内嵌编辑器使用）

        Args:
            file_path: 相对于 templates/ 的文件路径

        Returns:
            文件内容，文件不存在返回空字符串
        """
        full_path = cls._get_full_path(file_path)
        if not full_path.exists():
            return ''
        try:
            return full_path.read_text(encoding='utf-8')
        except Exception as e:
            logger.error(f'模板文件读取失败 [{file_path}]: {e}')
            return ''

    @classmethod
    def save_content(cls, file_path: str, content: str) -> bool:
        """
        保存模板内容到磁盘并同步数据库记录

        Args:
            file_path: 相对于 templates/ 的文件路径
            content: 模板内容

        Returns:
            是否保存成功
        """
        full_path = cls._get_full_path(file_path)

        try:
            # 确保目录存在
            full_path.parent.mkdir(parents=True, exist_ok=True)

            # 写入磁盘
            full_path.write_text(content, encoding='utf-8')

            # 同步数据库记录
            Template.objects.update_or_create(
                file_path=file_path,
                defaults={
                    'name': file_path,  # 默认用文件路径作为名称
                    'content': content,
                },
            )

            # 清除缓存
            CacheService.delete(file_path, namespace='template')

            logger.info(f'模板文件已保存: {file_path}')
            return True

        except Exception as e:
            logger.error(f'模板文件保存失败 [{file_path}]: {e}')
            return False

    @classmethod
    def delete_file(cls, file_path: str) -> bool:
        """
        删除模板文件和数据库记录

        Args:
            file_path: 相对于 templates/ 的文件路径

        Returns:
            是否删除成功
        """
        full_path = cls._get_full_path(file_path)

        try:
            if full_path.exists():
                full_path.unlink()

            Template.objects.filter(file_path=file_path).delete()
            CacheService.delete(file_path, namespace='template')

            logger.info(f'模板文件已删除: {file_path}')
            return True

        except Exception as e:
            logger.error(f'模板文件删除失败 [{file_path}]: {e}')
            return False

    # ----------------------------------------------------------------
    # CRUD（数据库记录）
    # ----------------------------------------------------------------
    @classmethod
    def create(cls, name: str, file_path: str, content: str = '',
               template_type: str = 'page', **kwargs) -> Template:
        """创建模板记录"""
        template = Template.objects.create(
            name=name,
            file_path=file_path,
            content=content,
            template_type=template_type,
            **kwargs,
        )

        # 如果有内容且文件不存在，写入磁盘
        if content:
            cls.save_content(file_path, content)

        logger.info(f'模板已创建: {name} ({file_path})')
        return template

    @classmethod
    def update(cls, template_id: int, **kwargs) -> Optional[Template]:
        """更新模板记录"""
        try:
            template = Template.objects.get(id=template_id)
        except Template.DoesNotExist:
            return None

        content = kwargs.pop('content', None)

        for k, v in kwargs.items():
            if hasattr(template, k):
                setattr(template, k, v)
        template.save()

        # 如果更新了内容，同步到磁盘
        if content is not None:
            template.content = content
            template.save(update_fields=['content'])
            cls.save_content(template.file_path, content)

        return template

    @classmethod
    def delete(cls, template_id: int) -> bool:
        """删除模板"""
        try:
            template = Template.objects.get(id=template_id)
            cls.delete_file(template.file_path)
            return True
        except Template.DoesNotExist:
            return False

    # ----------------------------------------------------------------
    # 内部方法
    # ----------------------------------------------------------------
    @classmethod
    def _get_full_path(cls, file_path: str) -> Path:
        """将相对路径转为绝对路径（基于 CMS_TEMPLATE_DIR）"""
        return Path(settings.CMS_TEMPLATE_DIR) / file_path
