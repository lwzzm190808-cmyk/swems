# core/api/plugin_bridge.py
"""
插件系统 API 桥接层

这是插件与后台系统交互的唯一入口。
插件的所有系统调用都通过 PluginSystemAPI 的实例完成。

注入模式：
- UsePluginAPI 的底层实现由 modules/plugin 在启动时注入，
  保持 core → modules 的单向依赖关系。
"""

import logging
from typing import Any, Optional

from core.models import Plugin
from core.services.config_service import ConfigService
from core.services.label_service import LabelService
from core.services.template_service import TemplateService
from core.services.permission_service import PermissionService
from core.services.log_service import LogService

logger = logging.getLogger(__name__)


class PluginSystemAPI:
    """
    插件系统 API

    插件开发者通过此接口与系统交互，禁止直接操作数据库或导入系统内部模块。

    实例由插件管理器在安装/启用插件时传入插件：
        plugin_instance = MyPlugin(plugin_id=xxx, system_api=PluginSystemAPI())
    """

    # 插件调用器（由 modules/plugin/apps.py 在启动时注册）
    _plugin_caller = None  # Callable[[plugin_id, api_name, **params], result]

    @classmethod
    def register_plugin_caller(cls, caller):
        """
        注册插件调用器

        由 modules/plugin/apps.py 的 ready() 调用：
            PluginSystemAPI.register_plugin_caller(PluginLoader.call_plugin_api)
        """
        cls._plugin_caller = caller
        logger.info('PluginSystemAPI: 插件调用器已注册')

    # ================================================================
    # 系统 API（插件可调用的接口）
    # ================================================================

    def GetSystemoption(self, config_key: str) -> dict:
        """
        获取系统配置

        Args:
            config_key: 配置项名称，如 "Mysql"

        Returns:
            JSON 格式的配置数据
        """
        return ConfigService.get_by_key(config_key)

    def GetSystemLog(self, log_type: str, limit: int = 100) -> list:
        """
        获取系统日志

        Args:
            log_type: 日志类型，如 "操作日志" / "运行日志"
            limit: 返回数量

        Returns:
            日志列表
        """
        type_map = {
            '操作日志': 'operation',
            '运行日志': 'runtime',
            '错误日志': 'error',
            '安全日志': 'security',
        }
        db_type = type_map.get(log_type, log_type)
        return LogService.query(log_type=db_type, limit=limit)

    def GetSystemPlugins(self, status: Optional[str] = None) -> list:
        """
        获取已安装的插件

        Args:
            status: 插件状态过滤，如 "enabled" / "disabled"

        Returns:
            插件信息列表
        """
        qs = Plugin.objects.all()
        if status:
            qs = qs.filter(status=status)

        return list(
            qs.values('plugin_id', 'name', 'title', 'version', 'status', 'config')
        )

    def GetSystemLabels(self) -> list:
        """
        获取所有系统标签

        Returns:
            标签信息列表
        """
        return LabelService.get_all_serialized()

    def GetSystemTemplate(self) -> list:
        """
        获取所有模板

        Returns:
            模板信息列表
        """
        return TemplateService.get_all_serialized()

    def GetSystemPermission(self, username: Optional[str] = None) -> Any:
        """
        获取后台人员权限

        Args:
            username: 用户名，为空返回全部后台用户权限

        Returns:
            权限信息
        """
        return PermissionService.get_admin_permissions(username)

    def GetUserPermission(self, username: str) -> dict:
        """
        获取前台用户权限（不允许为空）

        Args:
            username: 用户名

        Returns:
            权限信息
        """
        if not username:
            return {"error": "用户名不能为空"}
        return PermissionService.get_user_permissions(username)

    def UsePluginAPI(self, plugin_id: str, api_name: str, **params) -> Any:
        """
        调用指定插件的 API

        Args:
            plugin_id: 插件编号
            api_name: API 名称
            **params: API 参数

        Returns:
            被调用插件的返回结果
        """
        if self._plugin_caller is None:
            return {"error": "插件系统未初始化"}

        # 校验插件状态
        plugin = Plugin.objects.filter(plugin_id=plugin_id).first()
        if not plugin:
            return {"error": f"插件不存在: {plugin_id}"}
        if plugin.status != 'enabled':
            return {"error": f"插件 {plugin_id} 未启用"}

        try:
            return self._plugin_caller(plugin_id, api_name, **params)
        except Exception as e:
            logger.error(f'插件 API 调用失败 [{plugin_id}.{api_name}]: {e}')
            return {"error": f"调用失败: {str(e)}"}
