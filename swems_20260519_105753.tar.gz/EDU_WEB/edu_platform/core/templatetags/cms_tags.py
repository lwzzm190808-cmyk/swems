# core/templatetags/cms_tags.py
"""
CMS 模板标签引擎

提供自定义 Django 模板标签，在前台模板中解析和渲染 CMS 标签。

使用方式（在模板文件中）：
    {% load cms_tags %}

    <!-- 直接输出 -->
    {% cms_tag "site.title" %}

    <!-- 存储到变量 -->
    {% cms_tag "course.latest" as courses %}
    {% for course in courses %}
        {{ course.name }}
    {% endfor %}

    <!-- 区块渲染：解析数据 + 填充子模板 -->
    {% cms_block "course.latest" "partials/course_cards.html" %}
"""

import logging
from django import template
from django.utils.safestring import mark_safe

from core.services.label_service import LabelService
from shared.cache.service import CacheService

logger = logging.getLogger(__name__)

register = template.Library()


@register.simple_tag
def cms_tag(tag_code):
    """
    CMS 数据标签

    解析标签代码，返回对应的数据值。
    支持缓存，相同 tag_code 5 分钟内不重复解析。

    用法：
        {% cms_tag "article.title" %}
        {% cms_tag "course.latest" as courses %}
    """
    return _resolve_with_cache(tag_code)


@register.simple_tag
def cms_block(tag_code, template_path=None):
    """
    CMS 区块标签

    解析标签代码获取数据，然后用数据渲染指定的子模板。

    用法：
        {% cms_block "course.latest" "partials/course_cards.html" %}

    子模板中通过 {{ data }} 访问解析后的数据。
    """
    data = _resolve_with_cache(tag_code)

    if template_path:
        try:
            from django.template.loader import render_to_string
            html = render_to_string(template_path, {'data': data})
            return mark_safe(html)
        except Exception as e:
            logger.error(f'CMS 区块渲染失败 [{tag_code} -> {template_path}]: {e}')
            return f'<!-- 区块渲染错误 [{template_path}]: {e} -->'  # ← 显示具体错误

    return data


@register.simple_tag
def cms_config(key):
    """
    CMS 配置标签

    从系统配置中读取值并输出。

    用法：
        {% cms_config "site_name" %}
    """
    from core.services.config_service import ConfigService

    value = ConfigService.get_by_key(key)
    if isinstance(value, dict) and 'value' in value:
        return value['value']
    return value


@register.simple_tag
def cms_unread_count(user):
    """
    未读通知数标签

    用法：
        {% cms_unread_count request.user %}
    """
    if not user or not user.is_authenticated:
        return 0
    from shared.notification.service import NotificationService
    return NotificationService.get_unread_count(user)


# ----------------------------------------------------------------
# 内部辅助函数
# ----------------------------------------------------------------

def _resolve_with_cache(tag_code: str):
    """
    带缓存的标签解析

    缓存策略：
    - 先查 CacheService（5 分钟 TTL）
    - 未命中则调用 LabelService.resolve()
    - 结果写入缓存
    - 自动简化单字段查询结果
    """
    if not tag_code:
        return ''

    # 查缓存
    cached = CacheService.get_label(tag_code)
    if cached is not None:
        return cached

    # 解析
    value = LabelService.resolve(tag_code)

    # 自动简化: [{'rate': 0}] → 0, [{'count': 42}] → 42
    value = _simplify_value(value)

    # 写缓存（错误信息不缓存）
    if not (isinstance(value, str) and value.startswith('[')):
        CacheService.set_label(tag_code, value)

    return value


def _simplify_value(value):
    """
    自动简化标签解析结果

    - [{'rate': 0}] → 0
    - [{'count': 42}] → 42
    - [{'title': 'x', 'desc': 'y'}] → 保持原样（多字段不简化）
    """
    if isinstance(value, list) and len(value) == 1:
        item = value[0]
        if isinstance(item, dict) and len(item) == 1:
            return list(item.values())[0]
    return value

