# core/models.py
"""
核心数据模型 — 系统所有持久化数据的定义

设计原则：
- 所有系统级模型集中定义，供 core/services、core/api、modules 共同引用
- 模型之间允许互相引用（同属 core app）
- 与 Notification 模型通过 source_module 字符串字段关联（避免跨 app ForeignKey）
"""

from django.contrib.auth.models import AbstractUser
from django.db import models


# =====================================================================
# 用户模型
# =====================================================================
class User(AbstractUser):
    """统一用户模型：后台管理员和前台用户共用"""

    USER_TYPE_CHOICES = [
        ('admin', '后台管理员'),
        ('frontend', '前台用户'),
    ]

    user_type = models.CharField(
        max_length=10,
        choices=USER_TYPE_CHOICES,
        default='frontend',
        verbose_name='用户类型',
    )
    phone = models.CharField(
        max_length=20,
        blank=True,
        default='',
        verbose_name='手机号',
    )
    avatar = models.ImageField(
        upload_to='avatars/',
        blank=True,
        default='',
        verbose_name='头像',
    )

    class Meta:
        db_table = 'sys_user'
        verbose_name = '用户'
        verbose_name_plural = verbose_name
        ordering = ['-date_joined']

    def __str__(self):
        return f'[{self.get_user_type_display()}] {self.username}'


# =====================================================================
# 权限组
# =====================================================================
class PermissionGroup(models.Model):
    """
    权限组：对用户进行分组管理，统一授权

    permissions 字段为 JSON 结构，示例：
    {
        "tag": ["view", "add", "edit", "delete"],
        "template": ["view", "edit"],
        "plugin": ["view"],
        "config": ["view"],
        "log": ["view"]
    }
    """

    SCOPE_CHOICES = [
        ('admin', '后台权限组'),
        ('frontend', '前台权限组'),
    ]

    name = models.CharField(
        max_length=100,
        verbose_name='组名',
    )
    scope = models.CharField(
        max_length=10,
        choices=SCOPE_CHOICES,
        verbose_name='权限范围',
    )
    description = models.TextField(
        blank=True,
        default='',
        verbose_name='描述',
    )
    permissions = models.JSONField(
        default=dict,
        verbose_name='权限配置',
    )
    users = models.ManyToManyField(
        User,
        related_name='permission_groups',
        blank=True,
        verbose_name='组内用户',
    )
    is_default = models.BooleanField(
        default=False,
        verbose_name='是否默认组',
        help_text='新用户注册时自动加入默认组',
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        db_table = 'sys_permission_group'
        verbose_name = '权限组'
        verbose_name_plural = verbose_name
        ordering = ['scope', 'name']
        unique_together = ['name', 'scope']

    def __str__(self):
        return f'[{self.get_scope_display()}] {self.name}'


# =====================================================================
# CMS 标签
# =====================================================================
class Label(models.Model):
    """
    CMS 模板标签：将数据库字段映射为可在模板中使用的标签

    使用方式：
    模板中写 {% cms_tag "article.title" %}，系统查到该标签的 source_config，
    自动从对应模型中取值并渲染。

    source_type 类型：
    - model_field: 从 Django Model 字段取值
    - custom_query: 执行自定义 SQL（仅 SELECT）
    - plugin_data: 通过插件 API 获取数据
    """

    SOURCE_TYPE_CHOICES = [
        ('model_field', '模型字段'),
        ('custom_query', '自定义查询'),
        ('plugin_data', '插件数据'),
    ]

    name = models.CharField(
        max_length=100,
        verbose_name='标签名称',
        help_text='人类可读的标签名，如"文章标题"',
    )
    tag_code = models.CharField(
        max_length=200,
        unique=True,
        verbose_name='标签代码',
        help_text='模板中引用的代码，如 "article.title"',
    )
    source_type = models.CharField(
        max_length=20,
        choices=SOURCE_TYPE_CHOICES,
        default='model_field',
        verbose_name='数据源类型',
    )
    source_config = models.JSONField(
        default=dict,
        verbose_name='数据源配置',
        help_text='根据 source_type 填写对应配置',
    )
    description = models.TextField(
        blank=True,
        default='',
        verbose_name='描述',
    )
    plugin_id = models.CharField(
        max_length=50,
        null=True,
        blank=True,
        db_index=True,
        verbose_name='所属插件编号',
        help_text='为空表示系统标签，非空表示插件标签',
    )
    is_system = models.BooleanField(
        default=True,
        verbose_name='是否系统标签',
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')

    class Meta:
        db_table = 'sys_label'
        verbose_name = '标签'
        verbose_name_plural = verbose_name
        ordering = ['name']

    def __str__(self):
        return f'{{tag:{self.tag_code}}} — {self.name}'


# =====================================================================
# 模板管理
# =====================================================================
class Template(models.Model):
    """
    CMS 模板文件管理

    管理 templates/ 目录下的前台页面模板文件。
    支持通过后台上传新模板、在线编辑、预览。
    """

    TYPE_CHOICES = [
        ('page', '页面模板'),
        ('partial', '局部模板'),
        ('email', '邮件模板'),
        ('plugin', '插件模板'),
    ]

    name = models.CharField(
        max_length=200,
        verbose_name='模板名称',
    )
    file_path = models.CharField(
        max_length=255, 
        unique=True,
        verbose_name='文件路径',
        help_text='相对于 templates/ 目录，如 "home.html"、"course/detail.html"',
    )
    content = models.TextField(
        blank=True,
        default='',
        verbose_name='模板内容',
    )
    template_type = models.CharField(
        max_length=20,
        choices=TYPE_CHOICES,
        default='page',
        verbose_name='模板类型',
    )
    plugin_id = models.CharField(
        max_length=50,
        null=True,
        blank=True,
        db_index=True,
        verbose_name='所属插件编号',
    )
    is_system = models.BooleanField(
        default=True,
        verbose_name='是否系统模板',
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        db_table = 'sys_template'
        verbose_name = '模板'
        verbose_name_plural = verbose_name
        ordering = ['template_type', 'name']

    def __str__(self):
        return f'{self.name} ({self.file_path})'


# =====================================================================
# 系统配置
# =====================================================================
class SystemConfig(models.Model):
    """
    系统配置项：键值对存储

    按分组管理不同类别的配置（站点、数据库、Redis、备份等）。
    敏感字段加密存储（is_encrypted=True）。
    """

    GROUP_CHOICES = [
        ('site', '站点配置'),
        ('database', '数据库配置'),
        ('redis', 'Redis 配置'),
        ('backup', '备份配置'),
        ('email', '邮件配置'),
        ('custom', '自定义配置'),
    ]

    group = models.CharField(
        max_length=20,
        choices=GROUP_CHOICES,
        verbose_name='配置分组',
    )
    key = models.CharField(
        max_length=100,
        verbose_name='配置键',
    )
    value = models.JSONField(
        default=dict,
        verbose_name='配置值',
    )
    description = models.CharField(
        max_length=500,
        blank=True,
        default='',
        verbose_name='描述',
    )
    is_encrypted = models.BooleanField(
        default=False,
        verbose_name='是否加密存储',
    )
    updated_at = models.DateTimeField(auto_now=True, verbose_name='更新时间')

    class Meta:
        db_table = 'sys_config'
        verbose_name = '系统配置'
        verbose_name_plural = verbose_name
        unique_together = ['group', 'key']
        ordering = ['group', 'key']

    def __str__(self):
        return f'{self.group}.{self.key}'


# =====================================================================
# 插件
# =====================================================================
class Plugin(models.Model):
    """
    已安装的插件记录

    plugin_id 由系统自动分配（格式: PLG-YYYYMMDD-NNN），
    安装时生成，卸载时清除，用于标识插件的唯一性。
    """

    STATUS_CHOICES = [
        ('installed', '已安装'),
        ('enabled', '已启用'),
        ('disabled', '已停用'),
    ]

    plugin_id = models.CharField(
        max_length=50,
        unique=True,
        verbose_name='插件编号',
    )
    name = models.CharField(
        max_length=100,
        verbose_name='插件标识名',
        help_text='插件包名，如 content_manager',
    )
    title = models.CharField(
        max_length=200,
        verbose_name='插件标题',
    )
    version = models.CharField(
        max_length=20,
        verbose_name='版本号',
    )
    author = models.CharField(
        max_length=100,
        blank=True,
        default='',
        verbose_name='作者',
    )
    description = models.TextField(
        blank=True,
        default='',
        verbose_name='描述',
    )
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='installed',
        verbose_name='状态',
    )
    config = models.JSONField(
        default=dict,
        verbose_name='插件配置',
        help_text='当前生效的配置值',
    )
    config_schema = models.JSONField(
        default=dict,
        verbose_name='配置项定义',
        help_text='描述插件需要哪些配置项及其类型，供后台配置表单使用',
    )
    install_path = models.CharField(
        max_length=500,
        verbose_name='安装路径',
    )
    installed_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name='安装时间',
    )
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name='更新时间',
    )

    class Meta:
        db_table = 'sys_plugin'
        verbose_name = '插件'
        verbose_name_plural = verbose_name
        ordering = ['-installed_at']

    def __str__(self):
        return f'[{self.plugin_id}] {self.title} v{self.version}'


# =====================================================================
# 操作日志
# =====================================================================
class OperationLog(models.Model):
    """
    系统操作日志与运行日志

    自动记录所有写操作和后台访问，同时支持手动写入运行日志。
    通过中间件自动采集（Layer 3 实现），此处仅定义数据结构。
    """

    LOG_TYPE_CHOICES = [
        ('operation', '操作日志'),
        ('runtime', '运行日志'),
        ('error', '错误日志'),
        ('security', '安全日志'),
    ]

    LEVEL_CHOICES = [
        ('info', 'INFO'),
        ('warning', 'WARNING'),
        ('error', 'ERROR'),
        ('critical', 'CRITICAL'),
    ]

    log_type = models.CharField(
        max_length=20,
        choices=LOG_TYPE_CHOICES,
        default='operation',
        db_index=True,
        verbose_name='日志类型',
    )
    level = models.CharField(
        max_length=10,
        choices=LEVEL_CHOICES,
        default='info',
        verbose_name='级别',
    )
    user = models.ForeignKey(
        User,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        verbose_name='操作用户',
    )
    module = models.CharField(
        max_length=50,
        blank=True,
        default='',
        db_index=True,
        verbose_name='模块',
    )
    action = models.CharField(
        max_length=200,
        verbose_name='操作',
    )
    detail = models.TextField(
        blank=True,
        default='',
        verbose_name='详情',
    )
    ip_address = models.GenericIPAddressField(
        null=True,
        blank=True,
        verbose_name='IP 地址',
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        db_index=True,
        verbose_name='时间',
    )

    class Meta:
        db_table = 'sys_log'
        verbose_name = '日志'
        verbose_name_plural = verbose_name
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['log_type', '-created_at']),
            models.Index(fields=['user', '-created_at']),
            models.Index(fields=['module', '-created_at']),
        ]

    def __str__(self):
        user_str = self.user.username if self.user else 'system'
        return f'[{self.log_type}] {user_str} — {self.action}'
