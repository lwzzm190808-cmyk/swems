
from django.core.management.base import BaseCommand
from core.models import User, Label, Template, SystemConfig, PermissionGroup


class Command(BaseCommand):
    help = '初始化站点基础数据'

    def handle(self, *args, **options):
        self.stdout.write('=== 初始化站点基础数据 ===\n')

        self._create_configs()
        self._create_default_groups()
        self._create_labels()
        self._create_default_groups()
        self._create_templates()

        self.stdout.write('\n=== 初始化完成 ===')

    def _create_configs(self):
        """创建全部分组的基础配置"""
        self.stdout.write('\n--- 配置 ---')

        configs = [
            # 站点
            {'group': 'site', 'key': 'site_name', 'value': 'SWEMS', 'description': '网站名称'},
            {'group': 'site', 'key': 'site_slogan', 'value': '通用网站扩展管理系统', 'description': '网站标语'},
            {'group': 'site', 'key': 'copyright', 'value': '© 2025 SWEMS. All rights reserved.', 'description': '版权信息'},
            {'group': 'site', 'key': 'domain', 'value': 'localhost', 'description': '网站域名（如 example.com）'},
            {'group': 'site', 'key': 'ip_address', 'value': '0.0.0.0', 'description': '绑定 IP 地址（0.0.0.0 表示所有网卡）'},
            {'group': 'site', 'key': 'port', 'value': '8000', 'description': '应用端口号'},
            {'group': 'site', 'key': 'protocol', 'value': 'http', 'description': '协议（http 或 https）'},
            {'group': 'site', 'key': 'site_url', 'value': 'http://localhost:8000', 'description': '完整站点地址（自动生成，也可手动修改）'},

            # 数据库
            {'group': 'database', 'key': 'db_host', 'value': '127.0.0.1', 'description': '数据库主机地址'},
            {'group': 'database', 'key': 'db_port', 'value': '3306', 'description': '数据库端口'},
            {'group': 'database', 'key': 'db_name', 'value': 'swems_db', 'description': '数据库名称'},
            {'group': 'database', 'key': 'db_user', 'value': 'swems_user', 'description': '数据库用户名'},
            {'group': 'database', 'key': 'db_password', 'value': '', 'description': '数据库密码', 'encrypted': True},

            # Redis
            {'group': 'redis', 'key': 'redis_host', 'value': '127.0.0.1', 'description': 'Redis 主机'},
            {'group': 'redis', 'key': 'redis_port', 'value': '6379', 'description': 'Redis 端口'},
            {'group': 'redis', 'key': 'redis_password', 'value': '', 'description': 'Redis 密码（无密码留空）', 'encrypted': True},
            {'group': 'redis', 'key': 'redis_db', 'value': '1', 'description': 'Redis 数据库编号'},

            # 备份
            {'group': 'backup', 'key': 'backup_enabled', 'value': 'false', 'description': '是否启用自动备份'},
            {'group': 'backup', 'key': 'backup_interval', 'value': '86400', 'description': '备份间隔（秒）'},
            {'group': 'backup', 'key': 'backup_path', 'value': '/opt/swems/backups', 'description': '本地备份目录'},
            {'group': 'backup', 'key': 'backup_remote_url', 'value': '', 'description': '远程备份地址'},

            # 邮件
            {'group': 'email', 'key': 'email_host', 'value': 'smtp.example.com', 'description': 'SMTP 服务器'},
            {'group': 'email', 'key': 'email_port', 'value': '465', 'description': 'SMTP 端口'},
            {'group': 'email', 'key': 'email_user', 'value': '', 'description': 'SMTP 用户名'},
            {'group': 'email', 'key': 'email_password', 'value': '', 'description': 'SMTP 密码', 'encrypted': True},
            {'group': 'email', 'key': 'email_from', 'value': 'noreply@example.com', 'description': '发件人地址'},
        ]

        for c in configs:
            obj, created = SystemConfig.objects.update_or_create(
                group=c['group'], key=c['key'],
                defaults={
                    'value': c['value'],
                    'description': c['description'],
                    'is_encrypted': c.get('encrypted', False),
                },
            )
            status = '已创建' if created else '已更新'
            self.stdout.write(f'  配置 {status}: {c["group"]}.{c["key"]}')

    def _create_default_groups(self):
        """创建三个默认权限组"""
        self.stdout.write('\n--- 默认权限组 ---')

        core_modules = ['users', 'tag', 'template', 'config', 'permission', 'log']
        all_perms = {mod: {'use': True, 'modify': True, 'delete': True} for mod in core_modules}
        view_only = {mod: {'use': True, 'modify': False, 'delete': False} for mod in core_modules}
        log_only = {'log': {'use': True, 'modify': False, 'delete': False}}

        groups = [
            {
                'name': '超级管理员',
                'scope': 'admin',
                'description': '拥有所有后台权限，不可删除',
                'is_default': False,
                'is_system': True,
                'permissions': all_perms,
            },
            {
                'name': '管理员',
                'scope': 'admin',
                'description': '后台管理员，可使用和修改，不可删除数据',
                'is_default': False,
                'is_system': True,
                'permissions': view_only,
            },
            {
                'name': '用户',
                'scope': 'frontend',
                'description': '前台注册用户，默认权限组',
                'is_default': True,
                'is_system': True,
                'permissions': log_only,
            },
        ]

        for g in groups:
            obj, created = PermissionGroup.objects.update_or_create(
                name=g['name'],
                defaults={
                    'scope': g['scope'],
                    'description': g['description'],
                    'is_default': g['is_default'],
                    'permissions': g['permissions'],
                },
            )
            # 给模型加一个临时属性用于标记
            obj._is_system = True
            obj.save()

            status = '已创建' if created else '已更新'
            self.stdout.write(f'  权限组 {status}: {g["name"]}')


    def _create_labels(self):
        """创建基础标签"""
        self.stdout.write('\n--- 标签 ---')

        labels = [
            {'name': '网站名称', 'tag_code': 'site.name', 'source_type': 'custom_query',
             'source_config': {'sql': "SELECT value FROM sys_config WHERE `group`='site' AND `key`='site_name' LIMIT 1"}},
            {'name': '网站标语', 'tag_code': 'site.slogan', 'source_type': 'custom_query',
             'source_config': {'sql': "SELECT value FROM sys_config WHERE `group`='site' AND `key`='site_slogan' LIMIT 1"}},
            {'name': '版权信息', 'tag_code': 'site.copyright', 'source_type': 'custom_query',
             'source_config': {'sql': "SELECT value FROM sys_config WHERE `group`='site' AND `key`='copyright' LIMIT 1"}},
            {'name': '全站用户数', 'tag_code': 'stats.user_count', 'source_type': 'model_field',
             'source_config': {'model': 'core.User', 'count': True, 'filter': {'is_active': True}}},
            {'name': '前台用户数', 'tag_code': 'stats.frontend_count', 'source_type': 'model_field',
             'source_config': {'model': 'core.User', 'count': True, 'filter': {'is_active': True, 'user_type': 'frontend'}}},
            {'name': '后台管理员数', 'tag_code': 'stats.admin_count', 'source_type': 'model_field',
             'source_config': {'model': 'core.User', 'count': True, 'filter': {'is_active': True, 'user_type': 'admin'}}},
            {'name': '启用插件数', 'tag_code': 'stats.plugin_count', 'source_type': 'model_field',
             'source_config': {'model': 'core.Plugin', 'count': True, 'filter': {'status': 'enabled'}}},
        ]

        good_codes = [l['tag_code'] for l in labels]
        deleted = Label.objects.exclude(tag_code__in=good_codes).delete()[0]
        if deleted:
            self.stdout.write(f'  清理残留标签: {deleted} 个')

        for l in labels:
            obj, created = Label.objects.update_or_create(
                tag_code=l['tag_code'],
                defaults={
                    'name': l['name'],
                    'source_type': l['source_type'],
                    'source_config': l['source_config'],
                    'is_system': True,
                },
            )
            status = '已创建' if created else '已更新'
            self.stdout.write(f'  标签 {status}: {l["tag_code"]}')

    def _create_default_groups(self):
        """创建默认权限组"""
        self.stdout.write('\n--- 权限组 ---')

        groups = [
            {
                'name': '超级管理员',
                'scope': 'admin',
                'is_default': False,
                'permissions': {
                    'users': {'view': True, 'add': True, 'change': True, 'delete': True},
                    'tag': {'view': True, 'add': True, 'change': True, 'delete': True},
                    'template': {'view': True, 'add': True, 'change': True, 'delete': True},
                    'config': {'view': True, 'add': True, 'change': True, 'delete': True},
                    'permission': {'view': True, 'add': True, 'change': True, 'delete': True},
                    'plugin': {'view': True, 'add': True, 'change': True, 'delete': True},
                    'log': {'view': True, 'add': True, 'change': True, 'delete': True},
                },
            },
            {
                'name': '默认前台用户',
                'scope': 'frontend',
                'is_default': True,
                'permissions': {},
            },
        ]

        for g in groups:
            obj, created = PermissionGroup.objects.update_or_create(
                name=g['name'],
                defaults={
                    'scope': g['scope'],
                    'is_default': g['is_default'],
                    'permissions': g['permissions'],
                },
            )
            status = '已创建' if created else '已更新'
            self.stdout.write(f'  权限组 {status}: {g["name"]}')

    def _create_templates(self):
        """扫描模板文件并同步到数据库"""
        self.stdout.write('\n--- 模板 ---')

        from django.conf import settings

        template_dir = settings.CMS_TEMPLATE_DIR
        if not template_dir.exists():
            self.stdout.write(f'  模板目录不存在: {template_dir}')
            return

        created_count = 0
        updated_count = 0
        total_count = 0

        for filepath in template_dir.rglob('*.html'):
            relative = filepath.relative_to(settings.BASE_DIR)
            file_path = str(relative).replace('\\', '/')
            content = filepath.read_text(encoding='utf-8')
            name = filepath.stem  # 文件名不含扩展名

            obj, created = Template.objects.update_or_create(
                file_path=file_path,
                defaults={
                    'name': name,
                    'content': content,
                    'template_type': 'page',
                    'is_system': True,
                },
            )

            total_count += 1
            if created:
                created_count += 1
                self.stdout.write(f'  新增模板: {file_path}')
            else:
                updated_count += 1

        self.stdout.write(f'  扫描完成: 新增 {created_count}, 更新 {updated_count}, 总计 {total_count}')
