#!/usr/bin/env bash
# ============================================================
# SWEMS 服务管理脚本 v3.0
#
# 用法：
#   sudo ./swems.sh --package               # 打包
#   sudo ./swems.sh --deploy                # 部署
#   sudo ./swems.sh --start                 # 启动所有服务
#   sudo ./swems.sh --stop                  # 停止所有服务
#   sudo ./swems.sh --restart               # 重启所有服务
#   sudo ./swems.sh --status                # 查看运行状态
#   sudo ./swems.sh --logs [service]        # 查看日志
#   sudo ./swems.sh --health                # 健康检查
#   sudo ./swems.sh --health-daemon         # 启动健康监控守护进程
#   sudo ./swems.sh --sandbox               # 沙盒报告
#   sudo ./swems.sh --install-service       # 安装为 systemd 服务
#   sudo ./swems.sh --uninstall-service     # 卸载 systemd 服务
#   sudo ./swems.sh --reset                 # 还原至初始状态
#   sudo ./swems.sh --check                 # 环境检查
# ============================================================

set -euo pipefail

# ============================================================
# 配置
# ============================================================

PROJECT_NAME="swems"
INSTALL_DIR="/opt/${PROJECT_NAME}"
DB_NAME="swems_db"
DB_USER="swems_user"
DB_PASS=""
ADMIN_USER="admin"
ADMIN_EMAIL="admin@example.com"
ADMIN_PASS=""
DOMAIN="localhost"
PYTHON_VERSION="3.10"
CELERY_WORKERS="2"
HEALTH_INTERVAL=60
HEALTH_LOG="${INSTALL_DIR}/logs/health.log"

SUPERVISOR_CONF="/etc/supervisor/conf.d/${PROJECT_NAME}.conf"
NGINX_CONF="/etc/nginx/sites-available/${PROJECT_NAME}"
SYSTEMD_SERVICE="/etc/systemd/system/${PROJECT_NAME}.service"
SYSTEMD_HEALTH="/etc/systemd/system/${PROJECT_NAME}-health.service"
SYSTEMD_TIMER="/etc/systemd/system/${PROJECT_NAME}-health.timer"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
PACKAGE_NAME="${PROJECT_NAME}_${TIMESTAMP}.tar.gz"

# ============================================================
# 颜色 & 工具
# ============================================================

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'
log_info()    { echo -e "${GREEN}[INFO]${NC}    $1"; }
log_warn()    { echo -e "${YELLOW}[WARN]${NC}    $1"; }
log_error()   { echo -e "${RED}[ERROR]${NC}   $1"; }
log_step()    { echo -e "\n${BLUE}━━━ $1 ━━━${NC}\n"; }
log_success() { echo -e "${GREEN}  ✔ $1${NC}"; }
confirm()     { read -p "$(echo -e "${YELLOW}$1 [y/N]: ${NC}")" -n 1 -r; echo; [[ $REPLY =~ ^[Yy]$ ]] || { echo "已取消"; exit 0; }; }
check_root()  { [[ $EUID -ne 0 ]] && { log_error "请使用 sudo 运行"; exit 1; }; }
generate_password() { openssl rand -base64 16 | tr -d '/+=' | head -c 20; }

# ============================================================
# 打包
# ============================================================

do_package() {
    log_step "打包 SWEMS 项目"

    local src_dir="${SCRIPT_DIR}"
    local out_dir="${SCRIPT_DIR}/dist"
    local pkg_file="${out_dir}/${PACKAGE_NAME}"

    mkdir -p "${out_dir}"

    log_info "源目录: ${src_dir}"
    log_info "输出文件: ${pkg_file}"

    # 计算文件数量
    local file_count
    file_count=$(find "${src_dir}" -type f \
        ! -path "*/.venv/*" \
        ! -path "*/__pycache__/*" \
        ! -path "*/.git/*" \
        ! -path "*/node_modules/*" \
        ! -path "*/dist/*" \
        ! -path "*/staticfiles/*" \
        ! -path "*/media/*" \
        ! -path "*/logs/*" \
        ! -path "*.pyc" \
        ! -path "*/.env" \
        | wc -l)

    log_info "文件数量: ${file_count}"

    # 打包
    tar -czf "${pkg_file}" \
        --exclude='.venv' \
        --exclude='__pycache__' \
        --exclude='.git' \
        --exclude='node_modules' \
        --exclude='dist' \
        --exclude='staticfiles' \
        --exclude='media' \
        --exclude='logs' \
        --exclude='*.pyc' \
        --exclude='.env' \
        -C "$(dirname "${src_dir}")" \
        "$(basename "${src_dir}")"

    local size
    size=$(du -sh "${pkg_file}" | cut -f1)

    log_success "打包完成"
    echo ""
    echo "  文件: ${pkg_file}"
    echo "  大小: ${size}"
    echo "  文件数: ${file_count}"
    echo ""
    log_info "部署命令: sudo ./swems.sh --deploy"
}

# ============================================================
# 环境检查
# ============================================================

do_check() {
    log_step "SWEMS 环境检查"

    local all_ok=true
    local warnings=0

    # Python
    if command -v python3 &>/dev/null; then
        local py_ver
        py_ver=$(python3 --version 2>&1 | awk '{print $2}')
        log_success "Python: ${py_ver}"
    else
        log_error "Python3 未安装"
        all_ok=false
    fi

    # pip
    if command -v pip3 &>/dev/null || command -v pip &>/dev/null; then
        log_success "pip: 已安装"
    else
        log_error "pip 未安装"
        all_ok=false
    fi

    # MySQL
    if command -v mysql &>/dev/null; then
        local mysql_ver
        mysql_ver=$(mysql --version 2>&1 | awk '{print $6}' | tr -d ',')
        log_success "MySQL: ${mysql_ver}"
        if mysqladmin ping -u root --silent 2>/dev/null; then
            log_success "MySQL 连接: 正常"
        else
            log_warn "MySQL 服务: 未运行或无法连接"
            ((warnings++))
        fi
    else
        log_error "MySQL 未安装"
        all_ok=false
    fi

    # Redis
    if command -v redis-cli &>/dev/null; then
        local redis_ver
        redis_ver=$(redis-cli --version 2>&1 | awk '{print $2}')
        log_success "Redis: ${redis_ver}"
        if redis-cli ping 2>/dev/null | grep -q PONG; then
            log_success "Redis 连接: 正常"
        else
            log_warn "Redis 服务: 未运行"
            ((warnings++))
        fi
    else
        log_error "Redis 未安装"
        all_ok=false
    fi

    # Nginx
    if command -v nginx &>/dev/null; then
        local nginx_ver
        nginx_ver=$(nginx -v 2>&1 | awk -F/ '{print $2}')
        log_success "Nginx: ${nginx_ver}"
    else
        log_warn "Nginx 未安装（开发环境可忽略）"
        ((warnings++))
    fi

    # Supervisor
    if command -v supervisorctl &>/dev/null; then
        log_success "Supervisor: 已安装"
    else
        log_warn "Supervisor 未安装（开发环境可忽略）"
        ((warnings++))
    fi

    # Node.js（可选）
    if command -v node &>/dev/null; then
        local node_ver
        node_ver=$(node --version)
        log_success "Node.js: ${node_ver}"
    else
        log_info "Node.js: 未安装（可选）"
    fi

    # 磁盘空间
    local free_disk
    free_disk=$(df -BG / | awk 'NR==2 {print $4}' | tr -d 'G')
    if [[ ${free_disk} -gt 5 ]]; then
        log_success "磁盘空间: ${free_disk}G 可用"
    else
        log_warn "磁盘空间不足: ${free_disk}G 可用（建议 > 5G）"
        ((warnings++))
    fi

    # 内存
    local free_mem
    free_mem=$(free -m | awk 'Mem: {print $7}')
    if [[ ${free_mem} -gt 512 ]]; then
        log_success "可用内存: ${free_mem}MB"
    else
        log_warn "可用内存偏低: ${free_mem}MB"
        ((warnings++))
    fi

    # 项目目录检查
    echo ""
    echo -e "${CYAN}项目目录${NC}"
    local project_dir="${SCRIPT_DIR}"
    for f in manage.py requirements.txt config/settings.py; do
        if [[ -f "${project_dir}/$f" ]]; then
            log_success "$f: 存在"
        else
            log_error "$f: 缺失"
            all_ok=false
        fi
    done

    # 依赖文件检查
    if [[ -f "${project_dir}/requirements.txt" ]]; then
        local dep_count
        dep_count=$(wc -l < "${project_dir}/requirements.txt")
        log_info "依赖包数: ${dep_count}"
    fi

    # 结果
    echo ""
    if [[ "${all_ok}" == "true" ]]; then
        if [[ ${warnings} -gt 0 ]]; then
            log_warn "检查完成，有 ${warnings} 个警告"
        else
            log_success "检查通过，环境就绪"
        fi
    else
        log_error "检查未通过，请安装缺失组件后重试"
        exit 1
    fi
}

# ============================================================
# 部署
# ============================================================

do_deploy() {
    log_step "部署 SWEMS"

    local src_dir="${SCRIPT_DIR}"

    # 检查源文件
    if [[ ! -f "${src_dir}/manage.py" ]]; then
        log_error "未找到 manage.py，请在项目目录中运行"
        exit 1
    fi

    # 环境检查
    log_info "检查部署环境..."
    local missing=()
    command -v python3 &>/dev/null || missing+=("python3")
    command -v mysql &>/dev/null || missing+=("mysql-client")
    command -v redis-cli &>/dev/null || missing+=("redis-tools")

    if [[ ${#missing[@]} -gt 0 ]]; then
        log_error "缺少依赖: ${missing[*]}"
        log_info "安装命令: sudo apt install -y ${missing[*]}"
        exit 1
    fi

    # 确认
    echo ""
    echo "  目标目录: ${INSTALL_DIR}"
    echo "  数据库:   ${DB_NAME}"
    echo "  域名:     ${DOMAIN}"
    echo ""
    confirm "确认部署？"

    # 创建目录
    log_info "创建目录结构..."
    mkdir -p "${INSTALL_DIR}"
    mkdir -p "${INSTALL_DIR}/logs"
    mkdir -p "${INSTALL_DIR}/backups"
    mkdir -p "${INSTALL_DIR}/media"
    mkdir -p "${INSTALL_DIR}/plugins"

    # 复制文件
    log_info "复制项目文件..."
    rsync -av \
        --exclude='.venv' \
        --exclude='__pycache__' \
        --exclude='.git' \
        --exclude='node_modules' \
        --exclude='dist' \
        --exclude='staticfiles' \
        --exclude='logs' \
        --exclude='*.pyc' \
        "${src_dir}/" "${INSTALL_DIR}/"

    # 虚拟环境
    log_info "创建 Python 虚拟环境..."
    if [[ ! -d "${INSTALL_DIR}/.venv" ]]; then
        python3 -m venv "${INSTALL_DIR}/.venv"
    fi

    source "${INSTALL_DIR}/.venv/bin/activate"

    # 安装依赖
    log_info "安装 Python 依赖..."
    pip install --upgrade pip -q
    pip install -r "${INSTALL_DIR}/requirements.txt" -q
    pip install gunicorn celery mysqlclient psutil django-redis redis -q
    log_success "依赖安装完成"

    # 生成密码
    if [[ -z "${DB_PASS}" ]]; then
        DB_PASS=$(generate_password)
        log_info "数据库密码已生成"
    fi
    if [[ -z "${ADMIN_PASS}" ]]; then
        ADMIN_PASS=$(generate_password)
        log_info "管理员密码已生成"
    fi

    # 数据库
    log_info "配置数据库..."
    mysql -u root -e "
        CREATE DATABASE IF NOT EXISTS ${DB_NAME} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
        CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';
        GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_USER}'@'localhost';
        FLUSH PRIVILEGES;
    " 2>/dev/null || {
        log_warn "数据库创建失败，可能已存在"
    }

    # 更新 settings.py 中的数据库配置
    if [[ -f "${INSTALL_DIR}/config/settings.py" ]]; then
        sed -i "s/'NAME': 'edu_platform'/'NAME': '${DB_NAME}'/" "${INSTALL_DIR}/config/settings.py"
        sed -i "s/'USER': 'edu_user'/'USER': '${DB_USER}'/" "${INSTALL_DIR}/config/settings.py"
        sed -i "s/'PASSWORD': '[^']*'/'PASSWORD': '${DB_PASS}'/" "${INSTALL_DIR}/config/settings.py"
    fi

    # 数据库迁移
    log_info "执行数据库迁移..."
    cd "${INSTALL_DIR}"
    python manage.py makemigrations core --noinput 2>/dev/null || true
    python manage.py migrate --noinput

    # 初始化
    log_info "初始化基础数据..."
    python manage.py init_site --no-input 2>/dev/null || python manage.py init_site 2>/dev/null || true

    # 创建超级管理员
    log_info "创建管理员账户..."
    python manage.py shell -c "
from core.models import User
if not User.objects.filter(username='${ADMIN_USER}').exists():
    User.objects.create_superuser(
        username='${ADMIN_USER}',
        email='${ADMIN_EMAIL}',
        password='${ADMIN_PASS}',
        user_type='admin',
    )
    print('创建成功')
else:
    print('已存在，跳过')
" 2>/dev/null || true

    # 收集静态文件
    log_info "收集静态文件..."
    python manage.py collectstatic --noinput 2>/dev/null || true

    deactivate

    # Supervisor
    log_info "配置 Supervisor..."
    cat > "${SUPERVISOR_CONF}" <<EOF
[program:${PROJECT_NAME}]
command=${INSTALL_DIR}/.venv/bin/gunicorn config.wsgi:application --bind 127.0.0.1:8000 --workers 4 --timeout 120 --access-logfile ${INSTALL_DIR}/logs/access.log --error-logfile ${INSTALL_DIR}/logs/error.log
directory=${INSTALL_DIR}
user=root
environment=DJANGO_SETTINGS_MODULE="config.settings",PYTHONPATH="${INSTALL_DIR}"
autostart=true
autorestart=true
redirect_stderr=true
stdout_logfile=${INSTALL_DIR}/logs/supervisor_app.log
stdout_logfile_maxbytes=10MB
stdout_logfile_backups=5

[program:${PROJECT_NAME}-celery]
command=${INSTALL_DIR}/.venv/bin/celery -A config worker -l info -c ${CELERY_WORKERS}
directory=${INSTALL_DIR}
user=root
environment=DJANGO_SETTINGS_MODULE="config.settings",PYTHONPATH="${INSTALL_DIR}"
autostart=true
autorestart=true
redirect_stderr=true
stdout_logfile=${INSTALL_DIR}/logs/supervisor_celery.log
stdout_logfile_maxbytes=10MB
stdout_logfile_backups=5

[group:${PROJECT_NAME}]
programs=${PROJECT_NAME},${PROJECT_NAME}-celery
priority=999
EOF

    supervisorctl reread 2>/dev/null || true
    supervisorctl update 2>/dev/null || true

    # Nginx
    log_info "配置 Nginx..."
    cat > "${NGINX_CONF}" <<EOF
server {
    listen 80;
    server_name ${DOMAIN};

    client_max_body_size 50M;

    location /static/ {
        alias ${INSTALL_DIR}/staticfiles/;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    location /media/ {
        alias ${INSTALL_DIR}/media/;
        expires 7d;
    }

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_connect_timeout 60s;
        proxy_read_timeout 120s;
        proxy_send_timeout 120s;
    }

    # 安全头
    add_header X-Content-Type-Options nosniff always;
    add_header X-Frame-Options SAMEORIGIN always;
    add_header X-XSS-Protection "1; mode=block" always;
}
EOF

    ln -sf "${NGINX_CONF}" /etc/nginx/sites-enabled/${PROJECT_NAME}
    rm -f /etc/nginx/sites-enabled/default 2>/dev/null || true

    nginx -t 2>/dev/null && systemctl reload nginx 2>/dev/null || {
        log_warn "Nginx 配置测试失败，请手动检查"
    }

    # 权限
    log_info "设置文件权限..."
    chown -R root:root "${INSTALL_DIR}"
    chmod -R 755 "${INSTALL_DIR}"
    chmod -R 777 "${INSTALL_DIR}/logs"
    chmod -R 777 "${INSTALL_DIR}/media"

    # 结果
    echo ""
    echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${GREEN}  SWEMS 部署完成${NC}"
    echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    echo "  项目目录:  ${INSTALL_DIR}"
    echo "  访问地址:  http://${DOMAIN}/"
    echo "  后台地址:  http://${DOMAIN}/admin-panel/"
    echo ""
    echo "  管理员:    ${ADMIN_USER}"
    echo "  密码:      ${ADMIN_PASS}"
    echo ""
    echo "  数据库:    ${DB_NAME}"
    echo "  数据库用户: ${DB_USER}"
    echo "  数据库密码: ${DB_PASS}"
    echo ""
    echo -e "  ${YELLOW}请妥善保管以上密码信息！${NC}"
    echo ""
    echo "  启动服务:  sudo ./swems.sh --start"
    echo "  查看状态:  sudo ./swems.sh --status"
    echo "  安装服务:  sudo ./swems.sh --install-service"
    echo ""

    # 保存凭据
    cat > "${INSTALL_DIR}/.deploy_info" <<EOF
部署时间: $(date)
项目目录: ${INSTALL_DIR}
访问地址: http://${DOMAIN}/
管理员:   ${ADMIN_USER}
密码:     ${ADMIN_PASS}
数据库:   ${DB_NAME}
DB用户:   ${DB_USER}
DB密码:   ${DB_PASS}
EOF
    chmod 600 "${INSTALL_DIR}/.deploy_info"
    log_info "凭据已保存至 ${INSTALL_DIR}/.deploy_info"
}

# ============================================================
# 服务管理
# ============================================================

do_start() {
    log_step "启动 SWEMS 服务"
    supervisorctl start "${PROJECT_NAME}:*" 2>/dev/null || true
    systemctl start nginx 2>/dev/null || true
    sleep 2

    local ok=0
    supervisorctl status "${PROJECT_NAME}" 2>/dev/null | grep -q RUNNING && ((ok++)) && log_success "Gunicorn: 运行中" || log_error "Gunicorn: 未运行"
    supervisorctl status "${PROJECT_NAME}-celery" 2>/dev/null | grep -q RUNNING && ((ok++)) && log_success "Celery: 运行中" || log_error "Celery: 未运行"
    systemctl is-active --quiet nginx && ((ok++)) && log_success "Nginx: 运行中" || log_error "Nginx: 未运行"
    mysqladmin ping -u root --silent 2>/dev/null && ((ok++)) && log_success "MySQL: 运行中" || log_error "MySQL: 未运行"
    redis-cli ping 2>/dev/null | grep -q PONG && ((ok++)) && log_success "Redis: 运行中" || log_error "Redis: 未运行"

    log_info "启动完成 (${ok}/5)"
}

do_stop() {
    log_step "停止 SWEMS 服务"
    supervisorctl stop "${PROJECT_NAME}:*" 2>/dev/null || true
    log_success "已停止 Gunicorn 和 Celery"
    log_info "Nginx/MySQL/Redis 保持运行"
}

do_restart() {
    log_step "重启 SWEMS 服务"
    supervisorctl restart "${PROJECT_NAME}:*" 2>/dev/null || true
    systemctl reload nginx 2>/dev/null || true
    sleep 2
    supervisorctl status "${PROJECT_NAME}" 2>/dev/null | grep -q RUNNING && log_success "Gunicorn: 已重启" || log_error "Gunicorn: 启动失败"
    supervisorctl status "${PROJECT_NAME}-celery" 2>/dev/null | grep -q RUNNING && log_success "Celery: 已重启" || log_error "Celery: 启动失败"
    log_success "重启完成"
}

do_status() {
    echo ""
    echo -e "${CYAN}━━━ SWEMS 运行状态 ━━━${NC}"
    echo ""

    echo -e "${CYAN}服务${NC}"
    for svc in "${PROJECT_NAME}" "${PROJECT_NAME}-celery"; do
        local status
        status=$(supervisorctl status "${svc}" 2>/dev/null || echo "${svc} 未配置")
        if echo "${status}" | grep -q RUNNING; then
            echo -e "  ${GREEN}●${NC} ${status}"
        else
            echo -e "  ${RED}●${NC} ${status}"
        fi
    done

    for svc in nginx mysql redis-server; do
        if systemctl is-active --quiet "${svc}" 2>/dev/null; then
            echo -e "  ${GREEN}●${NC} ${svc}: 运行中"
        else
            echo -e "  ${RED}●${NC} ${svc}: 未运行"
        fi
    done

    echo ""
    echo -e "${CYAN}资源${NC}"
    if [[ -d "${INSTALL_DIR}/.venv" ]]; then
        source "${INSTALL_DIR}/.venv/bin/activate" 2>/dev/null
        cd "${INSTALL_DIR}" 2>/dev/null
        DJANGO_SETTINGS_MODULE=config.settings python manage.py shell -c "
from core.services.log_service import LogService
s = LogService.get_server_status()
print(f'  CPU:   {s[\"cpu\"][\"percent\"]}%  ({s[\"cpu\"][\"count\"]} 核)')
print(f'  内存:  {s[\"memory\"][\"used_gb\"]}/{s[\"memory\"][\"total_gb\"]} GB  ({s[\"memory\"][\"percent\"]}%)')
print(f'  磁盘:  {s[\"disk\"][\"used_gb\"]}/{s[\"disk\"][\"total_gb\"]} GB  ({s[\"disk\"][\"percent\"]}%)')
" 2>/dev/null || echo "  无法获取（应用未运行）"
        deactivate 2>/dev/null || true
    else
        echo "  项目未部署"
    fi

    echo ""
    echo -e "${CYAN}磁盘${NC}"
    echo "  项目:  $(du -sh "${INSTALL_DIR}" 2>/dev/null | cut -f1 || echo '无')"
    echo "  日志:  $(du -sh "${INSTALL_DIR}/logs" 2>/dev/null | cut -f1 || echo '无')"

    if [[ -f "${HEALTH_LOG}" ]]; then
        echo ""
        echo -e "${CYAN}最近健康检查${NC}"
        tail -3 "${HEALTH_LOG}"
    fi
    echo ""
}

# ============================================================
# 健康检查
# ============================================================

do_health() {
    local all_ok=true
    local timestamp
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')

    echo -e "${CYAN}━━━ SWEMS 健康检查 (${timestamp}) ━━━${NC}"
    echo ""

    if supervisorctl status "${PROJECT_NAME}" 2>/dev/null | grep -q RUNNING; then
        log_success "Gunicorn: 正常"
    else
        log_error "Gunicorn: 异常 — 尝试重启"
        supervisorctl restart "${PROJECT_NAME}" 2>/dev/null
        all_ok=false
    fi

    if supervisorctl status "${PROJECT_NAME}-celery" 2>/dev/null | grep -q RUNNING; then
        log_success "Celery: 正常"
    else
        log_error "Celery: 异常 — 尝试重启"
        supervisorctl restart "${PROJECT_NAME}-celery" 2>/dev/null
        all_ok=false
    fi

    if systemctl is-active --quiet nginx; then
        log_success "Nginx: 正常"
    else
        log_error "Nginx: 异常 — 尝试重启"
        systemctl restart nginx 2>/dev/null
        all_ok=false
    fi

    if mysqladmin ping -u root --silent 2>/dev/null; then
        log_success "MySQL: 正常"
    else
        log_error "MySQL: 异常"
        all_ok=false
    fi

    if redis-cli ping 2>/dev/null | grep -q PONG; then
        log_success "Redis: 正常"
    else
        log_error "Redis: 异常"
        all_ok=false
    fi

    local http_code
    http_code=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost/" 2>/dev/null || echo "000")
    if [[ "${http_code}" =~ ^(200|301|302)$ ]]; then
        log_success "HTTP: 正常 (${http_code})"
    else
        log_error "HTTP: 异常 (${http_code})"
        all_ok=false
    fi

    local disk_pct
    disk_pct=$(df / | awk 'NR==2 {gsub(/%/,"",$5); print $5}')
    if [[ ${disk_pct} -gt 90 ]]; then
        log_error "磁盘: ${disk_pct}% — 空间不足"
        all_ok=false
    else
        log_success "磁盘: ${disk_pct}%"
    fi

    mkdir -p "$(dirname "${HEALTH_LOG}")"
    if [[ "${all_ok}" == "true" ]]; then
        echo "${timestamp} [OK] 所有服务正常" >> "${HEALTH_LOG}"
    else
        echo "${timestamp} [WARN] 部分服务异常，已尝试自动恢复" >> "${HEALTH_LOG}"
    fi

    if [[ -f "${HEALTH_LOG}" ]] && [[ $(wc -l < "${HEALTH_LOG}") -gt 500 ]]; then
        tail -500 "${HEALTH_LOG}" > "${HEALTH_LOG}.tmp"
        mv "${HEALTH_LOG}.tmp" "${HEALTH_LOG}"
    fi

    echo ""
    [[ "${all_ok}" == "true" ]] && log_info "系统健康" || log_warn "存在问题，请检查日志"
}

do_health_daemon() {
    log_step "启动健康监控守护进程"
    log_info "检查间隔: ${HEALTH_INTERVAL} 秒"
    log_info "日志: ${HEALTH_LOG}"
    log_info "按 Ctrl+C 停止"
    echo ""

    while true; do
        do_health
        sleep "${HEALTH_INTERVAL}"
    done
}

# ============================================================
# 沙盒报告
# ============================================================

do_sandbox() {
    log_step "插件沙盒报告"

    if [[ ! -d "${INSTALL_DIR}/.venv" ]]; then
        log_error "项目未部署"
        exit 1
    fi

    source "${INSTALL_DIR}/.venv/bin/activate"
    cd "${INSTALL_DIR}"

    DJANGO_SETTINGS_MODULE=config.settings python manage.py shell -c "
from core.models import OperationLog, Plugin
import json

sandbox_logs = OperationLog.objects.filter(module='sandbox').order_by('-created_at')[:20]
total = OperationLog.objects.filter(module='sandbox').count()
violations = OperationLog.objects.filter(module='sandbox', level='warning').count()

print(f'沙盒日志总数: {total}')
print(f'违规事件: {violations}')
print()
print('最近 10 条沙盒事件:')
print('-' * 80)
for log in sandbox_logs[:10]:
    details = {}
    if log.detail:
        try:
            details = json.loads(log.detail)
        except: pass
    pid = details.get('plugin_id', '-')
    dur = details.get('duration', '-')
    net = details.get('network', {}).get('total', 0)
    db = details.get('database', {}).get('total', 0)
    viol = len(details.get('violations', []))
    level = log.level.upper()
    print(f'  {log.created_at}  [{level:7s}]  {pid:20s}  耗时:{dur}s  网络:{net}  SQL:{db}  违规:{viol}')

print()
print('已安装插件沙盒配置:')
print('-' * 80)
for p in Plugin.objects.all():
    sandbox_cfg = (p.config or {}).get('sandbox', {})
    level = sandbox_cfg.get('security_level', 'moderate (默认)')
    whitelist = sandbox_cfg.get('network_whitelist', [])
    wl = ', '.join(whitelist) if whitelist else '无限制'
    print(f'  {p.plugin_id:20s}  {p.title:15s}  级别:{level:12s}  白名单:{wl}')
" 2>/dev/null

    deactivate
}

# ============================================================
# 日志查看
# ============================================================

do_logs() {
    local service="${1:-app}"
    local log_dir="${INSTALL_DIR}/logs"

    if [[ ! -d "${log_dir}" ]]; then
        log_error "日志目录不存在: ${log_dir}"
        exit 1
    fi

    case "${service}" in
        app|gunicorn)     tail -f "${log_dir}/supervisor_app.log" ;;
        celery)           tail -f "${log_dir}/supervisor_celery.log" ;;
        django)           tail -f "${log_dir}/django.log" ;;
        access)           tail -f "${log_dir}/access.log" ;;
        error)            tail -f "${log_dir}/error.log" ;;
        health)           tail -f "${HEALTH_LOG}" ;;
        nginx)            tail -f /var/log/nginx/access.log ;;
        all)
            echo "最近 20 行各服务日志:"
            echo ""
            for logfile in "${log_dir}"/*.log; do
                if [[ -f "${logfile}" ]]; then
                    echo -e "${CYAN}━━━ $(basename "${logfile}") ━━━${NC}"
                    tail -5 "${logfile}"
                    echo ""
                fi
            done
            ;;
        *)
            echo "用法: sudo ./swems.sh --logs [app|celery|django|access|error|health|nginx|all]"
            ;;
    esac
}

# ============================================================
# Systemd 服务
# ============================================================

do_install_service() {
    log_step "安装 Systemd 服务"

    cat > "${SYSTEMD_SERVICE}" <<EOF
[Unit]
Description=SWEMS Web Application
After=network.target mysql.service redis-server.service
Requires=supervisor.service

[Service]
Type=forking
ExecStart=/usr/bin/supervisorctl start ${PROJECT_NAME}:*
ExecStop=/usr/bin/supervisorctl stop ${PROJECT_NAME}:*
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

    cat > "${SYSTEMD_HEALTH}" <<EOF
[Unit]
Description=SWEMS Health Check
After=network.target

[Service]
Type=oneshot
ExecStart=${SCRIPT_DIR}/swems.sh --health
EOF

    cat > "${SYSTEMD_TIMER}" <<EOF
[Unit]
Description=SWEMS Health Check Timer

[Timer]
OnBootSec=60
OnUnitActiveSec=${HEALTH_INTERVAL}
Persistent=true

[Install]
WantedBy=timers.target
EOF

    systemctl daemon-reload
    systemctl enable "${PROJECT_NAME}" 2>/dev/null
    systemctl enable "${PROJECT_NAME}-health.timer" 2>/dev/null
    systemctl start "${PROJECT_NAME}-health.timer" 2>/dev/null

    log_success "Systemd 服务已安装"
    echo ""
    echo "  systemctl start ${PROJECT_NAME}       # 启动"
    echo "  systemctl stop ${PROJECT_NAME}        # 停止"
    echo "  systemctl restart ${PROJECT_NAME}     # 重启"
    echo "  systemctl status ${PROJECT_NAME}      # 状态"
    echo "  systemctl list-timers ${PROJECT_NAME} # 健康检查定时器"
}

do_uninstall_service() {
    log_step "卸载 Systemd 服务"

    systemctl stop "${PROJECT_NAME}-health.timer" 2>/dev/null || true
    systemctl disable "${PROJECT_NAME}" 2>/dev/null || true
    systemctl disable "${PROJECT_NAME}-health.timer" 2>/dev/null || true

    rm -f "${SYSTEMD_SERVICE}" "${SYSTEMD_HEALTH}" "${SYSTEMD_TIMER}"
    systemctl daemon-reload

    log_success "Systemd 服务已卸载"
}

# ============================================================
# 还原
# ============================================================

do_reset() {
    log_step "还原 SWEMS 至初始状态"

    echo ""
    echo -e "${RED}  警告：此操作将清除以下内容：${NC}"
    echo "  - 数据库 ${DB_NAME}（所有数据将丢失）"
    echo "  - 项目目录 ${INSTALL_DIR}"
    echo "  - Supervisor 和 Nginx 配置"
    echo "  - Systemd 服务"
    echo ""
    confirm "确认还原？此操作不可恢复"

    # 停止服务
    log_info "停止服务..."
    supervisorctl stop "${PROJECT_NAME}:*" 2>/dev/null || true

    # 卸载 Systemd
    log_info "卸载 Systemd 服务..."
    do_uninstall_service

    # 删除 Nginx 配置
    log_info "删除 Nginx 配置..."
    rm -f "/etc/nginx/sites-enabled/${PROJECT_NAME}"
    rm -f "${NGINX_CONF}"
    systemctl reload nginx 2>/dev/null || true

    # 删除 Supervisor 配置
    log_info "删除 Supervisor 配置..."
    rm -f "${SUPERVISOR_CONF}"
    supervisorctl reread 2>/dev/null || true
    supervisorctl update 2>/dev/null || true

    # 删除数据库
    log_info "删除数据库..."
    mysql -u root -e "
        DROP DATABASE IF EXISTS ${DB_NAME};
        DROP USER IF EXISTS '${DB_USER}'@'localhost';
        FLUSH PRIVILEGES;
    " 2>/dev/null || log_warn "数据库删除失败"

    # 备份并删除项目目录
    if [[ -d "${INSTALL_DIR}" ]]; then
        local backup_path="${INSTALL_DIR}_backup_${TIMESTAMP}"
        log_info "备份项目目录至 ${backup_path}..."
        mv "${INSTALL_DIR}" "${backup_path}"
        log_success "项目目录已备份"
        echo "  如需彻底删除: sudo rm -rf ${backup_path}"
    fi

    echo ""
    log_success "还原完成"
    echo ""
    echo "  如需重新部署: sudo ./swems.sh --deploy"
}

# ============================================================
# 入口
# ============================================================

main() {
    case "${1:-}" in
        --package)            do_package ;;
        --deploy)             check_root; do_deploy ;;
        --start)              check_root; do_start ;;
        --stop)               check_root; do_stop ;;
        --restart)            check_root; do_restart ;;
        --status)             do_status ;;
        --health)             do_health ;;
        --health-daemon)      check_root; do_health_daemon ;;
        --sandbox)            do_sandbox ;;
        --logs)               do_logs "${2:-all}" ;;
        --install-service)    check_root; do_install_service ;;
        --uninstall-service)  check_root; do_uninstall_service ;;
        --reset)              check_root; do_reset ;;
        --check)              do_check ;;
        --help|-h)
            echo ""
            echo "SWEMS 服务管理脚本 v3.0"
            echo ""
            echo "部署:"
            echo "  --package               打包项目"
            echo "  --deploy                部署项目"
            echo "  --reset                 还原至初始状态"
            echo "  --check                 环境检查"
            echo ""
            echo "服务:"
            echo "  --start                 启动所有服务"
            echo "  --stop                  停止所有服务"
            echo "  --restart               重启所有服务"
            echo "  --status                查看运行状态"
            echo "  --logs [service]        查看日志 (app|celery|django|access|error|health|nginx|all)"
            echo ""
            echo "监控:"
            echo "  --health                执行健康检查"
            echo "  --health-daemon         启动健康监控守护进程"
            echo "  --sandbox               插件沙盒报告"
            echo ""
            echo "Systemd:"
            echo "  --install-service       安装为 systemd 服务"
            echo "  --uninstall-service     卸载 systemd 服务"
            echo ""
            ;;
        *)
            echo "用法: sudo ./swems.sh [操作] | --help 查看帮助"
            exit 1
            ;;
    esac
}

main "$@"
